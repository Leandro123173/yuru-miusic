YORU Music - cómo compilar el APK en GitHub

1. Crea un repositorio nuevo en GitHub y sube TODO el contenido de esta carpeta
   (incluida la carpeta oculta .github).
2. Ve a la pestaña Actions -> "Build YORU Music APK" -> Run workflow.
3. Cuando termine (puede tardar 15-30 min la primera vez), entra a la ejecución
   y descarga el APK en "Artifacts" (YORU-Music-debug-apk).

Nota: los workflows originales de ArchiveTune (build.yml, release.yml, etc.) necesitan
claves y servicios del proyecto original. Puedes ignorarlos o borrarlos.
