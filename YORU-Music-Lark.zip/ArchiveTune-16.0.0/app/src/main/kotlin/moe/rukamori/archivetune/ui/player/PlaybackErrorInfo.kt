/*
 * ArchiveTune (2026)
 * © Rukamori — github.com/rukamori
 * GPL-3.0 License | Contributors: see git history
 * Do not remove or alter this notice. - Per GPL-3.0 Section 4 & Section 5
 */

package moe.rukamori.archivetune.ui.player

import androidx.media3.common.PlaybackException
import androidx.media3.datasource.HttpDataSource
import moe.rukamori.archivetune.morideobfuscator.youtubei.YoutubeiException
import moe.rukamori.archivetune.morideobfuscator.youtubei.YoutubeiFailureKind
import moe.rukamori.archivetune.utils.YTPlayerUtils
import moe.rukamori.archivetune.utils.potoken.BrokenWebViewException
import moe.rukamori.archivetune.utils.potoken.PoTokenException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

internal enum class PlaybackErrorKind {
    LoginRefreshRequired,
    ConfirmationRequired,
    NoInternet,
    Timeout,
    NoStream,
    MalformedStream,
    Decoder,
    Http,
    Unknown,
}

internal data class PlaybackErrorInfo(
    val kind: PlaybackErrorKind,
    val httpCode: Int?,
    val loginRecoveryUrl: String?,
)

internal fun PlaybackException.toPlaybackErrorInfo(): PlaybackErrorInfo {
    val httpCode = httpStatusCodeOrNull()
    val invalidPlaybackLoginContextUrl = invalidPlaybackLoginContextUrl()
    val externalLoginRecoveryUrl = loginRecoveryUrl()
    val loginRecoveryUrl = invalidPlaybackLoginContextUrl ?: externalLoginRecoveryUrl
    val resolutionFailure = findCause<YoutubeiException>()
    val kind =
        when {
            invalidPlaybackLoginContextUrl != null -> PlaybackErrorKind.LoginRefreshRequired

            externalLoginRecoveryUrl != null -> PlaybackErrorKind.ConfirmationRequired

            findCause<SocketTimeoutException>() != null -> PlaybackErrorKind.Timeout

            resolutionFailure?.kind == YoutubeiFailureKind.TIMEOUT -> PlaybackErrorKind.Timeout

            findCause<PoTokenException>() != null || findCause<BrokenWebViewException>() != null -> PlaybackErrorKind.NoStream

            resolutionFailure?.kind in
                setOf(YoutubeiFailureKind.NO_FORMAT, YoutubeiFailureKind.UNAVAILABLE, YoutubeiFailureKind.PO_TOKEN)
            -> PlaybackErrorKind.NoStream

            resolutionFailure?.kind in
                setOf(YoutubeiFailureKind.DECIPHER, YoutubeiFailureKind.INVALID_RESPONSE)
            -> PlaybackErrorKind.MalformedStream

            errorCode == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED &&
                hasNetworkConnectionFailureCause() -> PlaybackErrorKind.NoInternet

            errorCode == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT -> PlaybackErrorKind.Timeout

            YTPlayerUtils.isBotDetectionException(this) -> PlaybackErrorKind.NoStream

            YTPlayerUtils.isBadStreamPlayerResponseException(this) -> PlaybackErrorKind.NoStream

            httpCode in setOf(403, 404, 410, 416) -> PlaybackErrorKind.NoStream

            errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED -> PlaybackErrorKind.MalformedStream

            errorCode in
                setOf(
                    PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED,
                    PlaybackException.ERROR_CODE_DECODING_FAILED,
                    PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED,
                )
            -> PlaybackErrorKind.Decoder

            httpCode != null -> PlaybackErrorKind.Http

            else -> PlaybackErrorKind.Unknown
        }

    return PlaybackErrorInfo(
        kind = kind,
        httpCode = httpCode,
        loginRecoveryUrl = loginRecoveryUrl,
    )
}

internal fun PlaybackException.httpStatusCodeOrNull(): Int? {
    var throwable: Throwable? = cause
    while (throwable != null) {
        if (throwable is HttpDataSource.InvalidResponseCodeException) return throwable.responseCode
        if (throwable is YoutubeiException && throwable.httpStatus != null) return throwable.httpStatus
        throwable = throwable.cause
    }
    return null
}

internal fun PlaybackException.invalidPlaybackLoginContextUrl(): String? =
    findCause<YTPlayerUtils.InvalidPlaybackLoginContextException>()?.targetUrl

internal fun PlaybackException.loginRecoveryUrl(): String? {
    findCause<YTPlayerUtils.LoginRequiredForPlaybackException>()?.let { return it.targetUrl }

    return null
}

private inline fun <reified T : Throwable> Throwable.findCause(): T? {
    var throwable: Throwable? = this
    while (throwable != null) {
        if (throwable is T) return throwable
        throwable = throwable.cause
    }
    return null
}

private fun PlaybackException.hasNetworkConnectionFailureCause(): Boolean =
    findCause<ConnectException>() != null || findCause<UnknownHostException>() != null
