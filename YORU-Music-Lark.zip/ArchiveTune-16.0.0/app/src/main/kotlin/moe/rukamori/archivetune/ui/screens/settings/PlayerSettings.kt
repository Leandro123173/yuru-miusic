/*
 * ArchiveTune (2026)
 * © Rukamori — github.com/rukamori
 * GPL-3.0 License | Contributors: see git history
 * Do not remove or alter this notice. - Per GPL-3.0 Section 4 & Section 5
 */

package moe.rukamori.archivetune.ui.screens.settings

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Usb
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.google.common.collect.ImmutableList
import moe.rukamori.archivetune.LocalPlayerAwareWindowInsets
import moe.rukamori.archivetune.LocalPlayerConnection
import moe.rukamori.archivetune.R
import moe.rukamori.archivetune.constants.ArtistSeparatorsKey
import moe.rukamori.archivetune.constants.AudioNormalizationKey
import moe.rukamori.archivetune.constants.AudioOffload
import moe.rukamori.archivetune.constants.AudioQuality
import moe.rukamori.archivetune.constants.AudioQualityKey
import moe.rukamori.archivetune.constants.AutoDownloadOnLikeKey
import moe.rukamori.archivetune.constants.AutoSkipNextOnErrorKey
import moe.rukamori.archivetune.constants.AutoStartOnBluetoothKey
import moe.rukamori.archivetune.constants.CrossfadeDurationKey
import moe.rukamori.archivetune.constants.CrossfadeEnabledKey
import moe.rukamori.archivetune.constants.DEFAULT_USB_DAC_VOLUME_PERCENT
import moe.rukamori.archivetune.constants.CrossfadeGaplessKey
import moe.rukamori.archivetune.constants.DeviceMutePlaybackRecoveryVolumeKey
import moe.rukamori.archivetune.constants.ExternalDownloaderEnabledKey
import moe.rukamori.archivetune.constants.ExternalDownloaderPackageKey
import moe.rukamori.archivetune.constants.HISTORY_DURATION_DEFAULT
import moe.rukamori.archivetune.constants.HistoryDuration
import moe.rukamori.archivetune.constants.PauseOnDeviceMuteKey
import moe.rukamori.archivetune.constants.PermanentShuffleKey
import moe.rukamori.archivetune.constants.PersistentQueueKey
import moe.rukamori.archivetune.constants.SeekExtraSeconds
import moe.rukamori.archivetune.constants.SkipSilenceKey
import moe.rukamori.archivetune.constants.StopMusicOnTaskClearKey
import moe.rukamori.archivetune.constants.UsbBitPerfectDriver
import moe.rukamori.archivetune.constants.UsbBitPerfectDriverKey
import moe.rukamori.archivetune.constants.UsbBitPerfectFixedVolumeKey
import moe.rukamori.archivetune.constants.UsbBitPerfectKey
import moe.rukamori.archivetune.constants.UsbDacVolumeKey
import moe.rukamori.archivetune.constants.WakelockKey
import moe.rukamori.archivetune.playback.bitperfect.BitPerfectFallback
import moe.rukamori.archivetune.playback.bitperfect.BitPerfectOutput
import moe.rukamori.archivetune.playback.bitperfect.BitPerfectStatus
import moe.rukamori.archivetune.sponsorblock.DEFAULT_SPONSOR_BLOCK_API_URL
import moe.rukamori.archivetune.ui.component.ArtistSeparatorsDialog
import moe.rukamori.archivetune.ui.component.CrossfadeSliderPreference
import moe.rukamori.archivetune.ui.component.EnumListPreference
import moe.rukamori.archivetune.ui.component.IconButton
import moe.rukamori.archivetune.ui.component.MultiSelectListPreference
import moe.rukamori.archivetune.ui.component.NumberPickerPreference
import moe.rukamori.archivetune.ui.component.PreferenceEntry
import moe.rukamori.archivetune.ui.component.PreferenceGroup
import moe.rukamori.archivetune.ui.component.PreferenceGroupScope
import moe.rukamori.archivetune.ui.component.SliderPreference
import moe.rukamori.archivetune.ui.component.SwitchPreference
import moe.rukamori.archivetune.ui.component.TextFieldDialog
import moe.rukamori.archivetune.ui.utils.backToMain
import moe.rukamori.archivetune.utils.rememberEnumPreference
import moe.rukamori.archivetune.utils.rememberPreference
import moe.rukamori.archivetune.viewmodels.PlaybackPerformanceSettingsUiState
import moe.rukamori.archivetune.viewmodels.PlaybackPerformanceSettingsViewModel
import moe.rukamori.archivetune.viewmodels.SponsorBlockCategoryUiModel
import moe.rukamori.archivetune.viewmodels.SponsorBlockSettingsScreenState
import moe.rukamori.archivetune.viewmodels.SponsorBlockSettingsViewModel
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlayerSettings(navController: NavController) {
    val playbackPerformanceSettingsViewModel: PlaybackPerformanceSettingsViewModel =
        hiltViewModel()
    val playbackPerformanceSettingsState by
        playbackPerformanceSettingsViewModel.uiState.collectAsStateWithLifecycle()
    val onLowDataModeChange =
        remember(playbackPerformanceSettingsViewModel) {
            playbackPerformanceSettingsViewModel::onLowDataModeChange
        }
    val onPreloadNextSongChange =
        remember(playbackPerformanceSettingsViewModel) {
            playbackPerformanceSettingsViewModel::onPreloadNextSongChange
        }
    val onPlaybackPerformanceRetry =
        remember(playbackPerformanceSettingsViewModel) {
            playbackPerformanceSettingsViewModel::retry
        }
    val sponsorBlockSettingsViewModel: SponsorBlockSettingsViewModel = hiltViewModel()
    val sponsorBlockSettingsState by
        sponsorBlockSettingsViewModel.uiState.collectAsStateWithLifecycle()
    val onSponsorBlockEnabledChange =
        remember(sponsorBlockSettingsViewModel) {
            sponsorBlockSettingsViewModel::onEnabledChange
        }
    val onSponsorBlockCategorySheetOpen =
        remember(sponsorBlockSettingsViewModel) {
            sponsorBlockSettingsViewModel::onCategorySheetOpen
        }
    val onSponsorBlockCategorySheetDismiss =
        remember(sponsorBlockSettingsViewModel) {
            sponsorBlockSettingsViewModel::onCategorySheetDismiss
        }
    val onSponsorBlockCategoryCheckedChange =
        remember(sponsorBlockSettingsViewModel) {
            sponsorBlockSettingsViewModel::onCategoryOptionCheckedChange
        }
    val onSponsorBlockCategorySelectionConfirm =
        remember(sponsorBlockSettingsViewModel) {
            sponsorBlockSettingsViewModel::onCategorySelectionConfirm
        }
    val onSponsorBlockApiUrlEditorOpen =
        remember(sponsorBlockSettingsViewModel) {
            sponsorBlockSettingsViewModel::onApiUrlEditorOpen
        }
    val onSponsorBlockApiUrlEditorDismiss =
        remember(sponsorBlockSettingsViewModel) {
            sponsorBlockSettingsViewModel::onApiUrlEditorDismiss
        }
    val onSponsorBlockApiUrlDraftChange =
        remember(sponsorBlockSettingsViewModel) {
            sponsorBlockSettingsViewModel::onApiUrlDraftChange
        }
    val onSponsorBlockApiUrlConfirm =
        remember(sponsorBlockSettingsViewModel) {
            sponsorBlockSettingsViewModel::onApiUrlConfirm
        }
    val onSponsorBlockRetry =
        remember(sponsorBlockSettingsViewModel) {
            sponsorBlockSettingsViewModel::retry
        }
    val (audioQuality, onAudioQualityChange) =
        rememberEnumPreference(
            AudioQualityKey,
            defaultValue = AudioQuality.AUTO,
        )
    val (persistentQueue, onPersistentQueueChange) =
        rememberPreference(
            PersistentQueueKey,
            defaultValue = true,
        )
    val (permanentShuffle, onPermanentShuffleChange) =
        rememberPreference(
            PermanentShuffleKey,
            defaultValue = false,
        )
    val (skipSilence, onSkipSilenceChange) =
        rememberPreference(
            SkipSilenceKey,
            defaultValue = false,
        )
    val (audioNormalization, onAudioNormalizationChange) =
        rememberPreference(
            AudioNormalizationKey,
            defaultValue = true,
        )
    val (audioOffload, onAudioOffloadChange) =
        rememberPreference(
            AudioOffload,
            defaultValue = false,
        )
    val (usbBitPerfect, onUsbBitPerfectChange) =
        rememberPreference(
            UsbBitPerfectKey,
            defaultValue = false,
        )
    val (usbBitPerfectDriver, onUsbBitPerfectDriverChange) =
        rememberEnumPreference(
            UsbBitPerfectDriverKey,
            defaultValue = UsbBitPerfectDriver.ANDROID,
        )
    val (usbBitPerfectFixedVolume, onUsbBitPerfectFixedVolumeChange) =
        rememberPreference(
            UsbBitPerfectFixedVolumeKey,
            defaultValue = false,
        )
    val (usbDacVolume, onUsbDacVolumeChange) =
        rememberPreference(
            UsbDacVolumeKey,
            defaultValue = DEFAULT_USB_DAC_VOLUME_PERCENT,
        )
    val usbDirectDriverActive =
        usbBitPerfect && (!BitPerfectOutput.isMixerSupported || usbBitPerfectDriver == UsbBitPerfectDriver.DIRECT)

    val (seekExtraSeconds, onSeekExtraSeconds) =
        rememberPreference(
            SeekExtraSeconds,
            defaultValue = false,
        )

    val (autoDownloadOnLike, onAutoDownloadOnLikeChange) =
        rememberPreference(
            AutoDownloadOnLikeKey,
            defaultValue = false,
        )
    val (autoSkipNextOnError, onAutoSkipNextOnErrorChange) =
        rememberPreference(
            AutoSkipNextOnErrorKey,
            defaultValue = false,
        )
    val (pauseOnDeviceMute, onPauseOnDeviceMuteChange) =
        rememberPreference(
            PauseOnDeviceMuteKey,
            defaultValue = false,
        )
    val (
        deviceMutePlaybackRecoveryVolume,
        onDeviceMutePlaybackRecoveryVolumeChange,
    ) =
        rememberPreference(
            DeviceMutePlaybackRecoveryVolumeKey,
            defaultValue = 0,
        )
    val (autoStartOnBluetooth, onAutoStartOnBluetoothChange) =
        rememberPreference(
            AutoStartOnBluetoothKey,
            defaultValue = false,
        )
    val (stopMusicOnTaskClear, onStopMusicOnTaskClearChange) =
        rememberPreference(
            StopMusicOnTaskClearKey,
            defaultValue = false,
        )
    val (historyDuration, onHistoryDurationChange) =
        rememberPreference(
            HistoryDuration,
            defaultValue = HISTORY_DURATION_DEFAULT,
        )

    val (crossfadeEnabled, onCrossfadeEnabledChange) =
        rememberPreference(
            CrossfadeEnabledKey,
            defaultValue = false,
        )
    val (crossfadeDurationSeconds, onCrossfadeDurationSecondsChange) =
        rememberPreference(
            CrossfadeDurationKey,
            defaultValue = 5f,
        )
    val (crossfadeGapless, onCrossfadeGaplessChange) =
        rememberPreference(
            CrossfadeGaplessKey,
            defaultValue = true,
        )

    val (artistSeparators, onArtistSeparatorsChange) =
        rememberPreference(
            ArtistSeparatorsKey,
            defaultValue = ",;/&",
        )
    val (externalDownloaderEnabled, onExternalDownloaderEnabledChange) =
        rememberPreference(
            ExternalDownloaderEnabledKey,
            defaultValue = false,
        )
    val (externalDownloaderPackage, onExternalDownloaderPackageChange) =
        rememberPreference(
            ExternalDownloaderPackageKey,
            defaultValue = "",
        )

    val (wakelockEnabled, onWakelockChange) =
        rememberPreference(
            WakelockKey,
            defaultValue = false,
        )
    var showArtistSeparatorsDialog by remember { mutableStateOf(false) }
    var showExternalDownloaderPackageDialog by remember { mutableStateOf(false) }

    if (showArtistSeparatorsDialog) {
        ArtistSeparatorsDialog(
            currentSeparators = artistSeparators,
            onDismiss = { showArtistSeparatorsDialog = false },
            onSave = { newSeparators ->
                onArtistSeparatorsChange(newSeparators)
                showArtistSeparatorsDialog = false
            },
        )
    }

    if (showExternalDownloaderPackageDialog) {
        TextFieldDialog(
            initialTextFieldValue =
                androidx.compose.ui.text.input
                    .TextFieldValue(externalDownloaderPackage),
            onDone = { pkg ->
                onExternalDownloaderPackageChange(pkg.trim())
                showExternalDownloaderPackageDialog = false
            },
            onDismiss = { showExternalDownloaderPackageDialog = false },
            singleLine = true,
            maxLines = 1,
        )
    }

    SponsorBlockApiUrlDialog(
        state = sponsorBlockSettingsState,
        onValueChange = onSponsorBlockApiUrlDraftChange,
        onConfirm = onSponsorBlockApiUrlConfirm,
        onDismiss = onSponsorBlockApiUrlEditorDismiss,
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.player_and_audio)) },
                navigationIcon = {
                    IconButton(
                        onClick = navController::navigateUp,
                        onLongClick = navController::backToMain,
                    ) {
                        Icon(
                            painterResource(R.drawable.arrow_back),
                            contentDescription = null,
                        )
                    }
                },
            )
        },
    ) { innerPadding ->
        val topPadding = innerPadding.calculateTopPadding()

        Column(
            Modifier
                .padding(top = topPadding)
                .windowInsetsPadding(LocalPlayerAwareWindowInsets.current.only(WindowInsetsSides.Horizontal + WindowInsetsSides.Bottom))
                .verticalScroll(rememberScrollState())
                .padding(bottom = SettingsDimensions.ScreenBottomPadding),
        ) {
            PreferenceGroup(title = stringResource(R.string.player)) {
                item {
                    EnumListPreference(
                        title = { Text(stringResource(R.string.modules_youtube_quality)) },
                        description = stringResource(R.string.modules_youtube_quality_description),
                        icon = { Icon(painterResource(R.drawable.graphic_eq), null) },
                        selectedValue = audioQuality,
                        onValueSelected = onAudioQualityChange,
                        valueText = {
                            when (it) {
                                AudioQuality.HIGHEST -> stringResource(R.string.audio_quality_max)
                                AudioQuality.HIGH -> stringResource(R.string.audio_quality_high)
                                AudioQuality.AUTO -> stringResource(R.string.audio_quality_auto)
                                AudioQuality.LOW -> stringResource(R.string.audio_quality_low)
                            }
                        },
                    )
                }

                playbackPerformancePreferences(
                    state = playbackPerformanceSettingsState,
                    onLowDataModeChange = onLowDataModeChange,
                    onPreloadNextSongChange = onPreloadNextSongChange,
                    onRetry = onPlaybackPerformanceRetry,
                )

                item {
                    SliderPreference(
                        title = { Text(stringResource(R.string.history_duration)) },
                        icon = { Icon(painterResource(R.drawable.history), null) },
                        value = historyDuration,
                        onValueChange = onHistoryDurationChange,
                    )
                }

                item {
                    SwitchPreference(
                        title = { Text(stringResource(R.string.audio_crossfade_title)) },
                        description = stringResource(R.string.audio_crossfade_description),
                        icon = { Icon(painterResource(R.drawable.animation), null) },
                        checked = crossfadeEnabled,
                        onCheckedChange = { enabled ->
                            if (enabled) {
                                onAudioOffloadChange(false)
                                onUsbBitPerfectChange(false)
                            }
                            onCrossfadeEnabledChange(enabled)
                        },
                    )
                }

                item {
                    CrossfadeSliderPreference(
                        valueSeconds = crossfadeDurationSeconds,
                        onValueChange = onCrossfadeDurationSecondsChange,
                        isEnabled = crossfadeEnabled,
                    )
                }

                item {
                    SwitchPreference(
                        title = { Text(stringResource(R.string.crossfade_gapless_title)) },
                        description = stringResource(R.string.crossfade_gapless_description),
                        icon = { Icon(painterResource(R.drawable.fast_forward), null) },
                        checked = crossfadeGapless,
                        onCheckedChange = onCrossfadeGaplessChange,
                        isEnabled = crossfadeEnabled,
                    )
                }

                item {
                    SwitchPreference(
                        title = { Text(stringResource(R.string.skip_silence)) },
                        icon = { Icon(painterResource(R.drawable.fast_forward), null) },
                        checked = skipSilence,
                        onCheckedChange = onSkipSilenceChange,
                        isEnabled = !audioOffload && !usbBitPerfect,
                    )
                }

                item {
                    SwitchPreference(
                        title = { Text(stringResource(R.string.audio_normalization)) },
                        icon = { Icon(painterResource(R.drawable.volume_up), null) },
                        checked = audioNormalization,
                        onCheckedChange = onAudioNormalizationChange,
                    )
                }

                item {
                    SwitchPreference(
                        title = { Text(stringResource(R.string.audio_offload)) },
                        description = stringResource(R.string.audio_offload_desc),
                        icon = { Icon(painterResource(R.drawable.speed), null) },
                        checked = audioOffload,
                        onCheckedChange = { enabled ->
                            onAudioOffloadChange(enabled)
                            if (enabled) {
                                onSkipSilenceChange(false)
                                onCrossfadeEnabledChange(false)
                                onUsbBitPerfectChange(false)
                            }
                        },
                    )
                }

                item {
                    SwitchPreference(
                        title = { Text(stringResource(R.string.usb_bit_perfect)) },
                        description = stringResource(R.string.usb_bit_perfect_desc),
                        icon = { Icon(Icons.Rounded.Usb, null) },
                        checked = usbBitPerfect,
                        onCheckedChange = { enabled ->
                            onUsbBitPerfectChange(enabled)
                            if (enabled) {
                                onAudioOffloadChange(false)
                                onSkipSilenceChange(false)
                                onCrossfadeEnabledChange(false)
                            }
                        },
                    )
                }

                item(visible = usbBitPerfect && BitPerfectOutput.isMixerSupported) {
                    EnumListPreference(
                        title = { Text(stringResource(R.string.usb_bit_perfect_driver)) },
                        description = stringResource(R.string.usb_bit_perfect_driver_desc),
                        icon = { Icon(painterResource(R.drawable.tune), null) },
                        selectedValue = usbBitPerfectDriver,
                        onValueSelected = onUsbBitPerfectDriverChange,
                        valueText = {
                            when (it) {
                                UsbBitPerfectDriver.ANDROID -> stringResource(R.string.usb_bit_perfect_driver_android)
                                UsbBitPerfectDriver.DIRECT -> stringResource(R.string.usb_bit_perfect_driver_direct)
                            }
                        },
                    )
                }

                item(visible = usbDirectDriverActive) {
                    val context = LocalContext.current
                    val volumeText =
                        remember(context) {
                            { value: Int -> context.getString(R.string.percentage_format, value) }
                        }
                    NumberPickerPreference(
                        title = { Text(stringResource(R.string.usb_dac_volume)) },
                        icon = { Icon(painterResource(R.drawable.volume_up), null) },
                        value = usbDacVolume,
                        onValueChange = onUsbDacVolumeChange,
                        minValue = 0,
                        maxValue = 100,
                        valueText = volumeText,
                    )
                }

                item(visible = usbDirectDriverActive) {
                    SwitchPreference(
                        title = { Text(stringResource(R.string.usb_bit_perfect_fixed_volume)) },
                        description = stringResource(R.string.usb_bit_perfect_fixed_volume_desc),
                        icon = { Icon(painterResource(R.drawable.volume_off), null) },
                        checked = usbBitPerfectFixedVolume,
                        onCheckedChange = onUsbBitPerfectFixedVolumeChange,
                    )
                }

                item(visible = usbBitPerfect) {
                    UsbBitPerfectStatusPreference()
                }

                item {
                    SwitchPreference(
                        title = { Text(stringResource(R.string.seek_seconds_addup)) },
                        description = stringResource(R.string.seek_seconds_addup_description),
                        icon = { Icon(painterResource(R.drawable.arrow_forward), null) },
                        checked = seekExtraSeconds,
                        onCheckedChange = onSeekExtraSeconds,
                    )
                }

                item {
                    SwitchPreference(
                        title = { Text(stringResource(R.string.pause_on_device_mute)) },
                        description = stringResource(R.string.pause_on_device_mute_desc),
                        icon = { Icon(painterResource(R.drawable.volume_off), null) },
                        checked = pauseOnDeviceMute,
                        onCheckedChange = onPauseOnDeviceMuteChange,
                    )
                }

                item(visible = pauseOnDeviceMute) {
                    val context = LocalContext.current
                    val disabledLabel = stringResource(R.string.device_mute_recovery_volume_disabled)
                    val recoveryVolumeText =
                        remember(context, disabledLabel) {
                            { value: Int ->
                                if (value == 0) {
                                    disabledLabel
                                } else {
                                    context.getString(R.string.percentage_format, value)
                                }
                            }
                        }
                    NumberPickerPreference(
                        title = { Text(stringResource(R.string.device_mute_recovery_volume)) },
                        icon = { Icon(painterResource(R.drawable.volume_up), null) },
                        value = deviceMutePlaybackRecoveryVolume,
                        onValueChange = onDeviceMutePlaybackRecoveryVolumeChange,
                        minValue = 0,
                        maxValue = 100,
                        valueText = recoveryVolumeText,
                        isEnabled = pauseOnDeviceMute,
                    )
                }

                item {
                    SwitchPreference(
                        title = { Text(stringResource(R.string.auto_start_on_bluetooth)) },
                        description = stringResource(R.string.auto_start_on_bluetooth_desc),
                        icon = { Icon(painterResource(R.drawable.bluetooth), null) },
                        checked = autoStartOnBluetooth,
                        onCheckedChange = onAutoStartOnBluetoothChange,
                    )
                }
            }

            PreferenceGroup(title = stringResource(R.string.sponsor_block_group)) {
                sponsorBlockPreferences(
                    state = sponsorBlockSettingsState,
                    onEnabledChange = onSponsorBlockEnabledChange,
                    onCategorySheetOpen = onSponsorBlockCategorySheetOpen,
                    onCategorySheetDismiss = onSponsorBlockCategorySheetDismiss,
                    onCategoryCheckedChange = onSponsorBlockCategoryCheckedChange,
                    onCategorySelectionConfirm = onSponsorBlockCategorySelectionConfirm,
                    onApiUrlEditorOpen = onSponsorBlockApiUrlEditorOpen,
                    onRetry = onSponsorBlockRetry,
                )
            }

            PreferenceGroup(title = stringResource(R.string.queue)) {
                item {
                    SwitchPreference(
                        title = { Text(stringResource(R.string.persistent_queue)) },
                        description = stringResource(R.string.persistent_queue_desc),
                        icon = { Icon(painterResource(R.drawable.queue_music), null) },
                        checked = persistentQueue,
                        onCheckedChange = onPersistentQueueChange,
                    )
                }

                item {
                    SwitchPreference(
                        title = { Text(stringResource(R.string.permanent_shuffle)) },
                        description = stringResource(R.string.permanent_shuffle_desc),
                        icon = { Icon(painterResource(R.drawable.shuffle), null) },
                        checked = permanentShuffle,
                        onCheckedChange = onPermanentShuffleChange,
                    )
                }

                item {
                    SwitchPreference(
                        title = { Text(stringResource(R.string.auto_download_on_like)) },
                        description = stringResource(R.string.auto_download_on_like_desc),
                        icon = { Icon(painterResource(R.drawable.download), null) },
                        checked = autoDownloadOnLike,
                        onCheckedChange = onAutoDownloadOnLikeChange,
                    )
                }

                item {
                    SwitchPreference(
                        title = { Text(stringResource(R.string.auto_skip_next_on_error)) },
                        description = stringResource(R.string.auto_skip_next_on_error_desc),
                        icon = { Icon(painterResource(R.drawable.skip_next), null) },
                        checked = autoSkipNextOnError,
                        onCheckedChange = onAutoSkipNextOnErrorChange,
                    )
                }
            }

            PreferenceGroup(title = stringResource(R.string.misc)) {
                item {
                    SwitchPreference(
                        title = { Text(stringResource(R.string.stop_music_on_task_clear)) },
                        icon = { Icon(painterResource(R.drawable.clear_all), null) },
                        checked = stopMusicOnTaskClear,
                        onCheckedChange = onStopMusicOnTaskClearChange,
                    )
                }

                item {
                    SwitchPreference(
                        title = { Text(stringResource(R.string.wakelock)) },
                        description = stringResource(R.string.wakelock_desc),
                        icon = { Icon(painterResource(R.drawable.bolt), null) },
                        checked = wakelockEnabled,
                        onCheckedChange = onWakelockChange,
                    )
                }

                item {
                    PreferenceEntry(
                        title = { Text(stringResource(R.string.artist_separators)) },
                        description = artistSeparators.map { "\"$it\"" }.joinToString("  "),
                        icon = { Icon(painterResource(R.drawable.artist), null) },
                        onClick = { showArtistSeparatorsDialog = true },
                    )
                }

                item {
                    SwitchPreference(
                        title = { Text(stringResource(R.string.external_downloader)) },
                        description = stringResource(R.string.external_downloader_desc),
                        icon = { Icon(painterResource(R.drawable.download), null) },
                        checked = externalDownloaderEnabled,
                        onCheckedChange = onExternalDownloaderEnabledChange,
                    )
                }

                item {
                    PreferenceEntry(
                        title = { Text(stringResource(R.string.external_downloader_package)) },
                        description = externalDownloaderPackage.ifEmpty { stringResource(R.string.external_downloader_package_desc) },
                        icon = { Icon(painterResource(R.drawable.integration), null) },
                        onClick = { showExternalDownloaderPackageDialog = true },
                        isEnabled = externalDownloaderEnabled,
                    )
                }
            }
        }
    }
}

@Composable
private fun UsbBitPerfectStatusPreference() {
    val service = LocalPlayerConnection.current?.service
    val status = service?.bitPerfectStatus?.collectAsStateWithLifecycle()?.value ?: BitPerfectStatus()
    val dacName = status.dacName
    val description =
        when {
            dacName == null -> stringResource(R.string.usb_bit_perfect_status_no_dac)
            status.permissionRequired -> stringResource(R.string.usb_bit_perfect_status_permission, dacName)
            status.active -> {
                val sampleRate =
                    if (status.sampleRateHz % 1000 == 0) {
                        (status.sampleRateHz / 1000).toString()
                    } else {
                        String.format(Locale.getDefault(), "%.1f", status.sampleRateHz / 1000f)
                    }
                stringResource(
                    if (status.exact) R.string.usb_bit_perfect_status_active else R.string.usb_bit_perfect_status_inexact,
                    dacName,
                    sampleRate,
                    status.outputBits,
                )
            }
            status.fallback == BitPerfectFallback.NO_HARDWARE_VOLUME ->
                stringResource(R.string.usb_bit_perfect_status_no_volume, dacName)
            status.fallback == BitPerfectFallback.UNAVAILABLE ->
                stringResource(R.string.usb_bit_perfect_status_fallback, dacName)
            else -> stringResource(R.string.usb_bit_perfect_status_ready, dacName)
        }
    val onRequestPermission =
        if (status.permissionRequired && service != null) {
            service::requestBitPerfectUsbPermission
        } else {
            null
        }

    PreferenceEntry(
        title = { Text(stringResource(R.string.usb_bit_perfect_status)) },
        description = description,
        icon = { Icon(painterResource(R.drawable.graphic_eq), null) },
        onClick = onRequestPermission,
    )
}

@Composable
private fun SponsorBlockApiUrlDialog(
    state: SponsorBlockSettingsScreenState,
    onValueChange: (String) -> Unit,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
) {
    val data = (state as? SponsorBlockSettingsScreenState.Success)?.data ?: return
    if (!data.isApiUrlEditorVisible) return
    val isInputValid =
        remember(data.isApiUrlDraftValid) {
            { _: String -> data.isApiUrlDraftValid }
        }
    val confirmValue =
        remember(onConfirm) {
            { _: String -> onConfirm() }
        }

    TextFieldDialog(
        title = { Text(stringResource(R.string.sponsor_block_api_url)) },
        textFieldValue = data.apiUrlDraft,
        onTextFieldValueChange = onValueChange,
        keyboardOptions =
            KeyboardOptions(
                keyboardType = KeyboardType.Uri,
                imeAction = ImeAction.Done,
            ),
        isInputValid = isInputValid,
        dismissOnDone = false,
        onDone = confirmValue,
        onDismiss = onDismiss,
    )
}

private fun PreferenceGroupScope.sponsorBlockPreferences(
    state: SponsorBlockSettingsScreenState,
    onEnabledChange: (Boolean) -> Unit,
    onCategorySheetOpen: () -> Unit,
    onCategorySheetDismiss: () -> Unit,
    onCategoryCheckedChange: (SponsorBlockCategoryUiModel, Boolean) -> Unit,
    onCategorySelectionConfirm: () -> Unit,
    onApiUrlEditorOpen: () -> Unit,
    onRetry: () -> Unit,
) {
    val data = (state as? SponsorBlockSettingsScreenState.Success)?.data
    val controlsEnabled = data != null
    val configurationEnabled = controlsEnabled && data?.enabled == true
    val categoryOptions = data?.categoryOptions ?: EMPTY_SPONSOR_BLOCK_CATEGORY_OPTIONS
    val draftCategoryOptions = data?.draftCategoryOptions ?: EMPTY_SPONSOR_BLOCK_CATEGORY_OPTIONS

    item {
        SwitchPreference(
            title = { Text(stringResource(R.string.sponsor_block_use)) },
            icon = { Icon(painterResource(R.drawable.block), null) },
            checked = data?.enabled ?: false,
            onCheckedChange = onEnabledChange,
            isEnabled = controlsEnabled,
        )
    }

    item {
        val selectedCount = data?.selectedCategoryOptions?.size ?: 0
        MultiSelectListPreference(
            title = { Text(stringResource(R.string.sponsor_block_categories)) },
            description = stringResource(R.string.sponsor_block_categories_desc),
            icon = { Icon(painterResource(R.drawable.fast_forward), null) },
            values = categoryOptions,
            checkedValues = draftCategoryOptions,
            selectionText =
                androidx.compose.ui.res.pluralStringResource(
                    R.plurals.n_selected,
                    selectedCount,
                    selectedCount,
                ),
            valueText = { option -> stringResource(option.labelRes) },
            isBottomSheetVisible = data?.isCategorySheetVisible == true,
            onOpen = onCategorySheetOpen,
            onDismiss = onCategorySheetDismiss,
            onValueCheckedChange = onCategoryCheckedChange,
            onConfirm = onCategorySelectionConfirm,
            isEnabled = configurationEnabled,
        )
    }

    item {
        PreferenceEntry(
            title = { Text(stringResource(R.string.sponsor_block_api_url)) },
            description = data?.apiUrl ?: DEFAULT_SPONSOR_BLOCK_API_URL,
            icon = { Icon(painterResource(R.drawable.link), null) },
            onClick = onApiUrlEditorOpen,
            isEnabled = configurationEnabled,
        )
    }

    if (state is SponsorBlockSettingsScreenState.Error) {
        item {
            PreferenceEntry(
                title = { Text(stringResource(R.string.retry)) },
                description = stringResource(state.messageRes),
                onClick = onRetry,
            )
        }
    }
}

private val EMPTY_SPONSOR_BLOCK_CATEGORY_OPTIONS: ImmutableList<SponsorBlockCategoryUiModel> =
    ImmutableList.of()

private fun PreferenceGroupScope.playbackPerformancePreferences(
    state: PlaybackPerformanceSettingsUiState,
    onLowDataModeChange: (Boolean) -> Unit,
    onPreloadNextSongChange: (Boolean) -> Unit,
    onRetry: () -> Unit,
) {
    val data = (state as? PlaybackPerformanceSettingsUiState.Success)?.data

    val lowDataModeEnabled = data?.lowDataModeEnabled ?: false
    val preloadNextSongEnabled = data?.preloadNextSongEnabled ?: false
    val lowDataModeControlEnabled =
        when (state) {
            PlaybackPerformanceSettingsUiState.Loading,
            is PlaybackPerformanceSettingsUiState.Error -> false
            PlaybackPerformanceSettingsUiState.Empty,
            is PlaybackPerformanceSettingsUiState.Success -> true
        }
    val preloadNextSongControlEnabled =
        lowDataModeControlEnabled && (data?.preloadNextSongAvailable ?: true)

    item {
        SwitchPreference(
            title = { Text(stringResource(R.string.low_data_mode_title)) },
            description = stringResource(R.string.low_data_mode_description),
            icon = { Icon(painterResource(R.drawable.android_cell), null) },
            checked = lowDataModeEnabled,
            onCheckedChange = onLowDataModeChange,
            isEnabled = lowDataModeControlEnabled,
        )
    }

    item {
        SwitchPreference(
            title = { Text(stringResource(R.string.preload_next_song_title)) },
            description = stringResource(R.string.preload_next_song_warning),
            icon = { Icon(painterResource(R.drawable.error), null) },
            checked = preloadNextSongEnabled,
            onCheckedChange = onPreloadNextSongChange,
            isEnabled = preloadNextSongControlEnabled,
        )
    }

    if (state is PlaybackPerformanceSettingsUiState.Error) {
        item {
            PreferenceEntry(
                title = { Text(stringResource(R.string.retry)) },
                description = stringResource(R.string.error_unknown),
                onClick = onRetry,
            )
        }
    }
}
