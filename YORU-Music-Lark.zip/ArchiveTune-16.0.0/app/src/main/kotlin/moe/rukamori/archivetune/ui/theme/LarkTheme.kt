/*
 * ArchiveTune (2026)
 * © Rukamori — github.com/rukamori
 * GPL-3.0 License | Contributors: see git history
 * Do not remove or alter this notice. - Per GPL-3.0 Section 4 & Section 5
 */

package moe.rukamori.archivetune.ui.theme

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color

/**
 * Paleta inspirada en Lark Player:
 *  - Ajustes / inicio: verde azulado muy oscuro, chips teal, texto blanco.
 *  - Reproductor: morado profundo con rosa pastel.
 *  - Mini reproductor: píldora rosa.
 */
object LarkColors {
    // Fondos teal oscuros (pantallas de inicio y ajustes)
    val TealBackground = Color(0xFF0F1D1E)
    val TealLowest = Color(0xFF0A1516)
    val TealLow = Color(0xFF142425)
    val TealContainer = Color(0xFF1A2F30)
    val TealHigh = Color(0xFF1F3839)
    val TealHighest = Color(0xFF264344)
    val TealChipSelected = Color(0xFF5B9F99)

    // Reproductor
    val PlayerPurple = Color(0xFF38174F)
    val PlayerPurpleDeep = Color(0xFF2A0F3D)
    val PlayerPink = Color(0xFFFFB6CB)
    val PlayerTrack = Color(0xFF6B3F6E)

    val Pink = Color(0xFFFFB6CB)
    val OnPink = Color(0xFF2B0A1B)
}

val LarkDarkColorScheme: ColorScheme =
    darkColorScheme(
        primary = LarkColors.Pink,
        onPrimary = LarkColors.OnPink,
        primaryContainer = LarkColors.Pink,
        onPrimaryContainer = LarkColors.OnPink,
        inversePrimary = Color(0xFFB0366B),
        secondary = LarkColors.TealChipSelected,
        onSecondary = Color.White,
        secondaryContainer = LarkColors.TealChipSelected,
        onSecondaryContainer = Color.White,
        tertiary = Color(0xFFD9B8FF),
        onTertiary = Color(0xFF2A0F3D),
        tertiaryContainer = LarkColors.PlayerPurple,
        onTertiaryContainer = LarkColors.PlayerPink,
        background = LarkColors.TealBackground,
        onBackground = Color(0xFFF1F7F6),
        surface = LarkColors.TealBackground,
        onSurface = Color(0xFFF1F7F6),
        surfaceVariant = LarkColors.TealHigh,
        onSurfaceVariant = Color(0xFFB9CBC9),
        surfaceTint = LarkColors.Pink,
        inverseSurface = Color(0xFFE3EEEC),
        inverseOnSurface = Color(0xFF142425),
        outline = Color(0xFF6E8886),
        outlineVariant = Color(0xFF2E4746),
        surfaceBright = LarkColors.TealHighest,
        surfaceDim = LarkColors.TealLowest,
        surfaceContainerLowest = LarkColors.TealLowest,
        surfaceContainerLow = LarkColors.TealLow,
        surfaceContainer = LarkColors.TealContainer,
        surfaceContainerHigh = LarkColors.TealHigh,
        surfaceContainerHighest = LarkColors.TealHighest,
    )

val LarkLightColorScheme: ColorScheme =
    lightColorScheme(
        primary = Color(0xFFB0366B),
        onPrimary = Color.White,
        primaryContainer = LarkColors.Pink,
        onPrimaryContainer = LarkColors.OnPink,
        inversePrimary = LarkColors.Pink,
        secondary = Color(0xFF3F7F79),
        onSecondary = Color.White,
        secondaryContainer = Color(0xFFB7E3DE),
        onSecondaryContainer = Color(0xFF05201E),
        tertiary = Color(0xFF6A3A8F),
        onTertiary = Color.White,
        tertiaryContainer = Color(0xFFEBD6FF),
        onTertiaryContainer = Color(0xFF2A0F3D),
        background = Color(0xFFF2F8F7),
        onBackground = Color(0xFF0F1D1E),
        surface = Color(0xFFF2F8F7),
        onSurface = Color(0xFF0F1D1E),
        surfaceVariant = Color(0xFFDCE8E6),
        onSurfaceVariant = Color(0xFF3F5654),
        surfaceTint = Color(0xFFB0366B),
        inverseSurface = LarkColors.TealContainer,
        inverseOnSurface = Color(0xFFE3EEEC),
        outline = Color(0xFF6E8886),
        outlineVariant = Color(0xFFC1D3D1),
        surfaceBright = Color(0xFFF8FDFC),
        surfaceDim = Color(0xFFD6E2E0),
        surfaceContainerLowest = Color.White,
        surfaceContainerLow = Color(0xFFEBF3F2),
        surfaceContainer = Color(0xFFE4EEEC),
        surfaceContainerHigh = Color(0xFFDCE8E6),
        surfaceContainerHighest = Color(0xFFD3E1DF),
    )

fun larkColorScheme(isDark: Boolean): ColorScheme = if (isDark) LarkDarkColorScheme else LarkLightColorScheme
