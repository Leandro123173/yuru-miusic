/*
 * ArchiveTune (2026)
 * © Rukamori — github.com/rukamori
 * GPL-3.0 License | Contributors: see git history
 * Do not remove or alter this notice. - Per GPL-3.0 Section 4 & Section 5
 */

@file:Suppress("DEPRECATION")

package moe.rukamori.archivetune.playback

import android.app.ActivityManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.bluetooth.BluetoothClass
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.database.ContentObserver
import android.database.SQLException
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaCodecList
import android.media.audiofx.AudioEffect
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.Virtualizer
import android.net.ConnectivityManager
import android.net.Uri
import android.os.Binder
import android.os.Build
import android.os.Handler
import android.os.PowerManager
import android.util.LruCache
import android.widget.Toast
import androidx.annotation.DrawableRes
import androidx.compose.runtime.snapshotFlow
import androidx.core.app.NotificationCompat
import androidx.core.content.getSystemService
import androidx.core.net.toUri
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.ParserException
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.Player.EVENT_POSITION_DISCONTINUITY
import androidx.media3.common.Player.EVENT_TIMELINE_CHANGED
import androidx.media3.common.Player.REPEAT_MODE_ALL
import androidx.media3.common.Player.REPEAT_MODE_OFF
import androidx.media3.common.Player.REPEAT_MODE_ONE
import androidx.media3.common.Player.STATE_IDLE
import androidx.media3.common.Timeline
import androidx.media3.common.Tracks
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSourceException
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.HttpDataSource
import androidx.media3.datasource.ResolvingDataSource
import androidx.media3.datasource.TransferListener
import androidx.media3.datasource.cache.Cache
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.datasource.cache.CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR
import androidx.media3.datasource.cache.ContentMetadata
import androidx.media3.datasource.cache.ContentMetadataMutations
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.analytics.AnalyticsListener
import androidx.media3.exoplayer.offline.Download
import androidx.media3.exoplayer.offline.DownloadService
import androidx.media3.exoplayer.analytics.PlaybackStats
import androidx.media3.exoplayer.analytics.PlaybackStatsListener
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.exoplayer.audio.SilenceSkippingAudioProcessor
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.ShuffleOrder.DefaultShuffleOrder
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.session.CommandButton
import androidx.media3.session.MediaLibraryService
import androidx.media3.session.MediaSession
import androidx.media3.session.SessionCommand
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.distinctUntilChangedBy
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.plus
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import moe.rukamori.archivetune.MainActivity
import moe.rukamori.archivetune.R
import moe.rukamori.archivetune.BuildConfig
import moe.rukamori.archivetune.androidauto.AndroidAutoConfiguration
import moe.rukamori.archivetune.androidauto.AndroidAutoCustomAction
import moe.rukamori.archivetune.androidauto.AndroidAutoSettingsUseCases
import moe.rukamori.archivetune.cast.CastMediaItemResolver
import moe.rukamori.archivetune.cast.CastPlaybackRepository
import moe.rukamori.archivetune.cast.CastPlaybackRepositoryLocator
import moe.rukamori.archivetune.constants.AudioNormalizationKey
import moe.rukamori.archivetune.constants.AudioOffload
import moe.rukamori.archivetune.constants.AudioQuality
import moe.rukamori.archivetune.constants.AudioQualityKey
import moe.rukamori.archivetune.constants.AutoDownloadOnLikeKey
import moe.rukamori.archivetune.constants.AutoLoadMoreKey
import moe.rukamori.archivetune.constants.AutoSkipNextOnErrorKey
import moe.rukamori.archivetune.constants.AutoStartOnBluetoothKey
import moe.rukamori.archivetune.constants.CrossfadeDurationKey
import moe.rukamori.archivetune.constants.CrossfadeEnabledKey
import moe.rukamori.archivetune.constants.DEFAULT_USB_DAC_VOLUME_PERCENT
import moe.rukamori.archivetune.constants.CrossfadeGaplessKey
import moe.rukamori.archivetune.constants.DeviceMutePlaybackRecoveryVolumeKey
import moe.rukamori.archivetune.constants.DiscordShowWhenPausedKey
import moe.rukamori.archivetune.constants.DiscordTokenKey
import moe.rukamori.archivetune.constants.EnableDiscordRPCKey
import moe.rukamori.archivetune.constants.EnableLastFMScrobblingKey
import moe.rukamori.archivetune.constants.EqualizerAutoHeadroomEnabledKey
import moe.rukamori.archivetune.constants.EqualizerBandLevelsMbKey
import moe.rukamori.archivetune.constants.EqualizerBassBoostEnabledKey
import moe.rukamori.archivetune.constants.EqualizerBassBoostStrengthKey
import moe.rukamori.archivetune.constants.EqualizerEnabledKey
import moe.rukamori.archivetune.constants.EqualizerOutputGainEnabledKey
import moe.rukamori.archivetune.constants.EqualizerOutputGainMbKey
import moe.rukamori.archivetune.constants.EqualizerSelectedProfileIdKey
import moe.rukamori.archivetune.constants.EqualizerVirtualizerEnabledKey
import moe.rukamori.archivetune.constants.EqualizerVirtualizerStrengthKey
import moe.rukamori.archivetune.constants.HISTORY_DURATION_DEFAULT
import moe.rukamori.archivetune.constants.HISTORY_DURATION_MAX
import moe.rukamori.archivetune.constants.HISTORY_DURATION_MIN
import moe.rukamori.archivetune.constants.HideExplicitKey
import moe.rukamori.archivetune.constants.HideVideoKey
import moe.rukamori.archivetune.constants.HistoryDuration
import moe.rukamori.archivetune.constants.LastFMSessionKey
import moe.rukamori.archivetune.constants.LastFMUseNowPlaying
import moe.rukamori.archivetune.constants.ListenBrainzEnabledKey
import moe.rukamori.archivetune.constants.ListenBrainzTokenKey
import moe.rukamori.archivetune.constants.MaxSongCacheSizeKey
import moe.rukamori.archivetune.constants.MediaSessionConstants.CommandClosePlayback
import moe.rukamori.archivetune.constants.MediaSessionConstants.CommandSeekBackIncrement
import moe.rukamori.archivetune.constants.MediaSessionConstants.CommandSeekForwardIncrement
import moe.rukamori.archivetune.constants.MediaSessionConstants.CommandToggleDownload
import moe.rukamori.archivetune.constants.MediaSessionConstants.CommandToggleLibrary
import moe.rukamori.archivetune.constants.MediaSessionConstants.CommandToggleLike
import moe.rukamori.archivetune.constants.MediaSessionConstants.CommandToggleRepeatMode
import moe.rukamori.archivetune.constants.MediaSessionConstants.CommandToggleShuffle
import moe.rukamori.archivetune.constants.MediaSessionConstants.CommandToggleSleepTimer
import moe.rukamori.archivetune.constants.MediaSessionConstants.CommandToggleStartRadio
import moe.rukamori.archivetune.constants.PauseListenHistoryKey
import moe.rukamori.archivetune.constants.PauseOnDeviceMuteKey
import moe.rukamori.archivetune.constants.PermanentShuffleKey
import moe.rukamori.archivetune.constants.PersistentQueueKey
import moe.rukamori.archivetune.constants.PlayerVolumeKey
import moe.rukamori.archivetune.constants.RepeatModeKey
import moe.rukamori.archivetune.constants.ScrobbleDelayPercentKey
import moe.rukamori.archivetune.constants.ScrobbleDelaySecondsKey
import moe.rukamori.archivetune.constants.ScrobbleMinSongDurationKey
import moe.rukamori.archivetune.constants.ShowLyricsKey
import moe.rukamori.archivetune.constants.SkipSilenceKey
import moe.rukamori.archivetune.constants.SleepTimerFadeOutKey
import moe.rukamori.archivetune.constants.SleepTimerFinishSongKey
import moe.rukamori.archivetune.constants.SmartTrimmerKey
import moe.rukamori.archivetune.constants.StopMusicOnTaskClearKey
import moe.rukamori.archivetune.constants.TogetherClientIdKey
import moe.rukamori.archivetune.constants.UsbBitPerfectDriver
import moe.rukamori.archivetune.constants.UsbBitPerfectDriverKey
import moe.rukamori.archivetune.constants.UsbBitPerfectFixedVolumeKey
import moe.rukamori.archivetune.constants.UsbBitPerfectKey
import moe.rukamori.archivetune.constants.UsbDacVolumeKey
import moe.rukamori.archivetune.constants.WakelockKey
import moe.rukamori.archivetune.db.MusicDatabase
import moe.rukamori.archivetune.db.entities.AlbumEntity
import moe.rukamori.archivetune.db.entities.ArtistEntity
import moe.rukamori.archivetune.db.entities.Event
import moe.rukamori.archivetune.db.entities.FormatEntity
import moe.rukamori.archivetune.db.entities.RelatedSongMap
import moe.rukamori.archivetune.db.entities.Song
import moe.rukamori.archivetune.db.entities.SongEntity
import moe.rukamori.archivetune.db.entities.needsRemoteFetch
import moe.rukamori.archivetune.di.DownloadCache
import moe.rukamori.archivetune.di.PlayerCache
import moe.rukamori.archivetune.extensions.SilentHandler
import moe.rukamori.archivetune.extensions.collect
import moe.rukamori.archivetune.extensions.collectLatest
import moe.rukamori.archivetune.extensions.currentMetadata
import moe.rukamori.archivetune.extensions.directorySizeBytes
import moe.rukamori.archivetune.extensions.findNextMediaItemById
import moe.rukamori.archivetune.extensions.getCurrentQueueIndex
import moe.rukamori.archivetune.extensions.getQueueWindows
import moe.rukamori.archivetune.extensions.mediaItems
import moe.rukamori.archivetune.extensions.metadata
import moe.rukamori.archivetune.extensions.move
import moe.rukamori.archivetune.extensions.setOffloadEnabled
import moe.rukamori.archivetune.extensions.toContinuationQueue
import moe.rukamori.archivetune.extensions.toEnum
import moe.rukamori.archivetune.extensions.toMediaItem
import moe.rukamori.archivetune.extensions.toPersistQueue
import moe.rukamori.archivetune.extensions.toQueue
import moe.rukamori.archivetune.innertube.YouTube
import moe.rukamori.archivetune.innertube.models.SongItem
import moe.rukamori.archivetune.innertube.models.WatchEndpoint
import moe.rukamori.archivetune.innertube.models.response.PlayerResponse
import moe.rukamori.archivetune.lastfm.LastFM
import moe.rukamori.archivetune.lyrics.LyricsHelper
import moe.rukamori.archivetune.models.MediaMetadata
import moe.rukamori.archivetune.modules.ModuleAudioSelection
import moe.rukamori.archivetune.modules.ModuleDownloadRepository
import moe.rukamori.archivetune.modules.ModuleMediaStorage
import moe.rukamori.archivetune.modules.ResolveModuleAudioUseCase
import moe.rukamori.archivetune.modules.moduleMatchMetadata
import moe.rukamori.archivetune.models.PersistPlayerState
import moe.rukamori.archivetune.models.PersistQueue
import moe.rukamori.archivetune.models.toMediaMetadata
import moe.rukamori.archivetune.morideobfuscator.youtubei.YoutubeiException
import moe.rukamori.archivetune.morideobfuscator.youtubei.YoutubeiFailureKind
import moe.rukamori.archivetune.playback.bitperfect.BitPerfectAudioSink
import moe.rukamori.archivetune.playback.notification.MediaNotificationAction
import moe.rukamori.archivetune.playback.notification.MediaNotificationConfiguration
import moe.rukamori.archivetune.playback.notification.MediaNotificationNavigation
import moe.rukamori.archivetune.playback.notification.MediaNotificationSettingsRepository
import moe.rukamori.archivetune.playback.bitperfect.BitPerfectEvent
import moe.rukamori.archivetune.playback.bitperfect.BitPerfectOutput
import moe.rukamori.archivetune.playback.bitperfect.BitPerfectRoutingSink
import moe.rukamori.archivetune.playback.preload.NextStreamPreloader
import moe.rukamori.archivetune.playback.preload.ObservePlaybackPreloadConfigurationUseCase
import moe.rukamori.archivetune.playback.preload.PlaybackPreloadConfiguration
import moe.rukamori.archivetune.playback.stream.AudioStreamRequest
import moe.rukamori.archivetune.playback.stream.PlaybackHttpClient
import moe.rukamori.archivetune.playback.stream.ResolveAudioStreamUseCase
import moe.rukamori.archivetune.playback.stream.ResolvedAudioStream
import moe.rukamori.archivetune.playback.stream.StreamPurpose
import moe.rukamori.archivetune.playback.queues.EmptyQueue
import moe.rukamori.archivetune.playback.queues.ListQueue
import moe.rukamori.archivetune.playback.queues.Queue
import moe.rukamori.archivetune.playback.queues.YouTubeQueue
import moe.rukamori.archivetune.playback.queues.filterBlockedArtists
import moe.rukamori.archivetune.playback.queues.filterExplicit
import moe.rukamori.archivetune.playback.queues.filterVideo
import moe.rukamori.archivetune.playback.queues.hasBlockedArtist
import moe.rukamori.archivetune.scrobbling.LastFmServiceConfig
import moe.rukamori.archivetune.sponsorblock.SponsorBlockPlaybackController
import moe.rukamori.archivetune.storage.StorageFolderKind
import moe.rukamori.archivetune.storage.StorageLocationRepository
import moe.rukamori.archivetune.together.TogetherPlaybackSync
import moe.rukamori.archivetune.ui.screens.settings.DiscordPresenceManager
import moe.rukamori.archivetune.ui.screens.settings.ListenBrainzManager
import moe.rukamori.archivetune.utils.CoilBitmapLoader
import moe.rukamori.archivetune.utils.NetworkConnectivityObserver
import moe.rukamori.archivetune.utils.StreamClientUtils
import moe.rukamori.archivetune.utils.SyncUtils
import moe.rukamori.archivetune.utils.YTPlayerUtils
import moe.rukamori.archivetune.utils.dataStore
import moe.rukamori.archivetune.utils.enumPreference
import moe.rukamori.archivetune.utils.get
import moe.rukamori.archivetune.utils.getAsync
import moe.rukamori.archivetune.utils.isLocalMediaId
import moe.rukamori.archivetune.utils.isLowDataModeActive
import moe.rukamori.archivetune.utils.reportException
import moe.rukamori.archivetune.utils.retryWithoutPlaybackLoginContext
import moe.rukamori.archivetune.widget.LoadWidgetInsightsUseCase
import moe.rukamori.archivetune.widget.LoadWidgetRecentSongsUseCase
import moe.rukamori.archivetune.widget.WidgetServiceActions
import okhttp3.OkHttpClient
import timber.log.Timber
import java.io.EOFException
import java.io.FileOutputStream
import java.io.IOException
import java.io.ObjectInputStream
import java.io.ObjectOutputStream
import java.io.Serializable
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.time.LocalDateTime
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong
import javax.inject.Inject
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.pow
import kotlin.math.roundToLong
import kotlin.time.Duration.Companion.seconds

@OptIn(ExperimentalCoroutinesApi::class, FlowPreview::class, UnstableApi::class)
@AndroidEntryPoint
class MusicService :
    MediaLibraryService(),
    Player.Listener,
    PlaybackStatsListener.Callback {
    @Inject
    lateinit var canvasPlaybackUseCase: moe.rukamori.archivetune.canvas.CanvasPlaybackUseCase

    @Inject
    lateinit var database: MusicDatabase

    @Inject
    lateinit var lyricsHelper: LyricsHelper

    @Inject
    lateinit var syncUtils: SyncUtils

    @Inject
    lateinit var mediaLibrarySessionCallback: MediaLibrarySessionCallback

    @Inject
    lateinit var androidAutoSettings: AndroidAutoSettingsUseCases

    @Inject
    lateinit var mediaNotificationSettings: MediaNotificationSettingsRepository

    @Volatile
    private var notificationConfiguration = MediaNotificationConfiguration()

    private var currentDownloadState: Int? = null

    @Inject
    internal lateinit var loadWidgetInsightsUseCase: LoadWidgetInsightsUseCase

    @Inject
    internal lateinit var loadWidgetRecentSongsUseCase: LoadWidgetRecentSongsUseCase

    @Inject
    lateinit var equalizerPlaybackController: EqualizerPlaybackController

    @Inject
    lateinit var resolveAudioStream: ResolveAudioStreamUseCase

    @Inject
    lateinit var moduleAudio: ResolveModuleAudioUseCase

    @Inject
    lateinit var moduleBindings: ModuleDownloadRepository

    @Inject
    lateinit var moduleStorage: ModuleMediaStorage

    @Inject
    lateinit var moduleDownloadUtil: DownloadUtil

    private val activeModuleAudio = ConcurrentHashMap<String, ModuleAudioSelection>()

    @Inject
    lateinit var observePlaybackPreloadConfiguration: ObservePlaybackPreloadConfigurationUseCase

    @Inject
    lateinit var nextStreamPreloader: NextStreamPreloader

    @Inject
    lateinit var sponsorBlockPlaybackController: SponsorBlockPlaybackController

    @Inject
    lateinit var bitPerfectOutput: BitPerfectOutput

    private var playbackPreloadConfiguration: PlaybackPreloadConfiguration? = null

    private lateinit var audioManager: AudioManager
    private var audioFocusRequest: AudioFocusRequest? = null
    private var lastAudioFocusState = AudioManager.AUDIOFOCUS_NONE
    private var wasPlayingBeforeAudioFocusLoss = false
    private var pauseOnDeviceMuteEnabled = false
    private var deviceMutePlaybackRecoveryVolumePercent = 0
    private var wasAutoPausedByDeviceMute = false
    private var muteRecoveryObserver: ContentObserver? = null
    private var lastDeviceMutePlaybackNoticeAtElapsedMs = 0L
    private var hasAudioFocus = false
    private var autoStartOnBluetoothEnabled = false
    private var bluetoothReceiverRegistered = false
    private var wakeLock: PowerManager.WakeLock? = null
    private var wakelockEnabled = false
    private var audioDeviceCallbackRegistered = false
    private var audioRouteRecoveryJob: Job? = null
    private var audiblePlaybackRecoveryJob: Job? = null
    private var lastAudioOutputDeviceSignature: String? = null
    private var lastAudioRouteRecoveryRealtimeMs = 0L
    private lateinit var audioOutputResolver: AudioOutputResolver

    val activeAudioDevice get() = audioOutputResolver.activeAudioDevice

    val bitPerfectStatus get() = bitPerfectOutput.status

    fun requestBitPerfectUsbPermission() = bitPerfectOutput.requestUsbPermission()

    fun refreshActiveDevice() = audioOutputResolver.refresh()

    private val audioDeviceCallback =
        object : AudioDeviceCallback() {
            override fun onAudioDevicesAdded(addedDevices: Array<AudioDeviceInfo>) {
                if (addedDevices.any { it.isSink }) onAudioOutputDeviceChanged()
            }

            override fun onAudioDevicesRemoved(removedDevices: Array<AudioDeviceInfo>) {
                if (removedDevices.any { it.isSink }) onAudioOutputDeviceChanged()
            }
        }

    private var scopeJob = SupervisorJob()
    private var scope = CoroutineScope(Dispatchers.Main + scopeJob)
    private var ioScope = CoroutineScope(Dispatchers.IO + scopeJob)
    private val binder = MusicBinder(this)
    private var boundClientCount = 0
    private val hasBoundClients: Boolean
        get() = boundClientCount > 0
    private var isPlaybackServiceStarted = false
    private var idleStopJob: Job? = null
    private lateinit var mediaNotificationProvider: ArchiveTuneMediaNotificationProvider

    private lateinit var connectivityManager: ConnectivityManager
    lateinit var connectivityObserver: NetworkConnectivityObserver
    val waitingForNetworkConnection = MutableStateFlow(false)
    private val _unrecoveredPlaybackError = MutableStateFlow<PlaybackException?>(null)
    val unrecoveredPlaybackError = _unrecoveredPlaybackError.asStateFlow()
    private val isNetworkConnected = MutableStateFlow(false)

    private val audioQuality by enumPreference(
        this,
        AudioQualityKey,
        moe.rukamori.archivetune.constants.AudioQuality.AUTO,
    )
    private val remotePlaybackTrackingUrlCache = ConcurrentHashMap<String, String>()
    private val cacheBypassMediaIds = ConcurrentHashMap.newKeySet<String>()
    private val castMimeTypeCache = LruCache<String, String>(128)
    private val mediaOkHttpClient: OkHttpClient by lazy {
        OkHttpClient
            .Builder()
            .followRedirects(true)
            .followSslRedirects(true)
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .addInterceptor { chain ->
                val request = chain.request()
                val host = request.url.host
                val isYouTubeMediaHost =
                    host.endsWith("googlevideo.com") ||
                        host.endsWith("googleusercontent.com") ||
                        host.endsWith("youtube.com") ||
                        host.endsWith("youtube-nocookie.com") ||
                        host.endsWith("ytimg.com")

                if (!isYouTubeMediaHost) return@addInterceptor chain.proceed(request)

                val requestProfile = StreamClientUtils.resolveRequestProfile(request.url)
                val requestBuilder = request.newBuilder()
                if (request.header("User-Agent") == null) {
                    requestBuilder.header("User-Agent", requestProfile.userAgent)
                }
                if (request.header("Origin") == null && requestProfile.origin != null) {
                    requestBuilder.header("Origin", requestProfile.origin)
                }
                if (request.header("Referer") == null && requestProfile.referer != null) {
                    requestBuilder.header("Referer", requestProfile.referer)
                }
                chain.proceed(
                    requestBuilder.build(),
                )
            }.addNetworkInterceptor { chain ->
                val request = chain.request()
                val response = chain.proceed(request)
                if (response.code == 403 &&
                    (request.url.host == "googlevideo.com" || request.url.host.endsWith(".googlevideo.com"))
                ) {
                    Timber.tag("YoutubeiResolver").w(
                        "Media HTTP 403 tokenPresent=%s nPresent=%s nError=%s userAgentPresent=%s " +
                            "rangePresent=%s redirected=%s routeProxy=%s",
                        !request.url.queryParameter("pot").isNullOrBlank(),
                        !request.url.queryParameter("n").isNullOrBlank(),
                        request.url.queryParameter("n")?.startsWith("enhanced_except_") == true,
                        !request.header("User-Agent").isNullOrBlank(),
                        request.header("Range") != null,
                        request.url.host != chain.call().request().url.host,
                        chain.connection()?.route()?.proxy?.type()?.name ?: "UNKNOWN",
                    )
                    resolveAudioStream.reportRejectedStream(chain.call().request().url.toString())
                }
                response
            }.build()
    }

    private var currentQueue: Queue = EmptyQueue
        set(value) {
            if (field !== value && value !== recapAudioQueue) {
                recapAudioQueue = null
                recapQueueActive.value = false
                setRecapMuted(false)
            }
            field = value
        }
    private var recommendationQueue: YouTubeQueue? = null
    private var recommendationRequest: Job? = null
    private var recommendationGeneration = 0L
    private var recommendationSeed: String? = null
    private var recommendationBuffer: List<MediaItem> = emptyList()
    private var failedRecommendation: Triple<WatchEndpoint, Boolean, String?>? = null
    private var queuePageJob: Job? = null
    private var initialQueueJob: Job? = null
    val queueRecommendations = MutableStateFlow(QueueRecommendations())
    var queueTitle: String? = null
    private var blockedArtistIds: Set<String> = emptySet()
    private var hideMusicVideos = false
    private var infiniteQueueJob: Job? = null
    private var infiniteQueueGeneration = 0L
    private val persistentStateLock = Any()
    private val persistentSaveGeneration = AtomicLong(0L)

    @Volatile
    private var isRestoringPersistentState = false

    @Volatile
    private var isHydratingRestoredQueue = false
    private val restoredQueueHydrationGeneration = AtomicLong(0L)

    @Volatile
    private var suppressAutoPlayback = false
    private var lastPresenceToken: String? = null

    @Volatile
    private var pausedPresenceGate = PausedPresenceGate.FollowPreference

    @Volatile
    private var discordServiceStopping = false

    @Volatile
    private var lastDiscordPresenceDecision: DiscordPresenceDecision? = null

    @Volatile
    private var activeDiscordHoldState: ActiveHoldState? = null

    private var activeDiscordHoldTimeoutJob: Job? = null

    @Volatile
    private var lastAppliedVisiblePresence: LastAppliedVisiblePresence? = null

    private val discordSyncEpoch = AtomicLong(0L)
    private val discordSyncRequests = Channel<DiscordSyncRequest>(Channel.CONFLATED)
    private var discordSyncWorkerJob: Job? = null
    private val pendingDiscordRefreshWaiters = mutableListOf<CompletableDeferred<Boolean>>()
    private val discordRefreshWaitersMutex = Mutex()
    private val toggleLikeMutex = Mutex()

    @Volatile
    private var lastLoginRecoveryPrompt: Pair<String, Long>? = null
    private val playbackStreamRecoveryTracker = PlaybackStreamRecoveryTracker()
    private var playbackErrorRecoveryJob: Job? = null
    private var nextHistorySessionToken = 0L
    private var currentHistorySessionToken = 0L
    private var currentHistoryMediaId: String? = null
    private var currentHistoryAccumulatedPlayMs = 0L
    private var currentHistoryStartedAtElapsedMs: Long? = null
    private var currentHistoryEventId: Long? = null
    private var currentHistoryRemoteRegistered = false
    private var currentHistoryImmediateAttempted = false
    private var currentHistorySessionQueued = false
    private var historyThresholdJob: Job? = null
    private val pendingHistoryFinalizations = mutableMapOf<String, MutableList<PendingHistoryFinalization>>()
    private val historyRecordingJobs = ConcurrentHashMap<Long, kotlinx.coroutines.Deferred<ImmediateHistoryResult>>()

    val currentMediaMetadata = MutableStateFlow<moe.rukamori.archivetune.models.MediaMetadata?>(null)
    val queueRestoreCompleted = MutableStateFlow(false)
    val infiniteQueueLoading = MutableStateFlow(false)
    private val playerInitialized = MutableStateFlow(false)
    private val currentSong =
        currentMediaMetadata
            .flatMapLatest { mediaMetadata ->
                database.song(mediaMetadata?.id)
            }.flowOn(Dispatchers.IO)
            .stateIn(scope, SharingStarted.Lazily, null)
    private val currentFormat =
        currentMediaMetadata
            .flatMapLatest { mediaMetadata ->
                database.format(mediaMetadata?.id)
            }.flowOn(Dispatchers.IO)

    private val normalizeFactor = MutableStateFlow(1f)
    private val audioNormalizationFactorCache = ConcurrentHashMap<String, Float>()
    private var audioNormalizationEnabled = true
    var playerVolume = MutableStateFlow(1f)
    private val audioFocusVolumeFactor = MutableStateFlow(1f)
    private val sleepTimerVolumeFactor = MutableStateFlow(1f)
    val recapAudioMuted = MutableStateFlow(false)
    val recapQueueActive = MutableStateFlow(false)
    private var recapAudioQueue: Queue? = null
    private var effectiveVolumeRampJob: Job? = null
    private var crossfadeEnabled = false
    private var crossfadeDurationMs = 0L
    private var crossfadeGapless = false
    private var crossfadeSuppressedMediaId: String? = null
    private var crossfadeHandler: CrossfadeHandler? = null

    private data class CrossfadeConfig(
        val enabled: Boolean,
        val durationSeconds: Float,
        val gapless: Boolean,
    )

    private data class DiscordSyncRequest(
        val epoch: Long,
        val reason: String,
        val force: Boolean,
    )

    private data class Quadruple<A, B, C, D>(
        val first: A,
        val second: B,
        val third: C,
        val fourth: D,
    )

    private class StaleDiscordSyncException : CancellationException("Stale Discord sync request")

    private data class PlaybackRecoverySnapshot(
        val mediaId: String,
        val positionMs: Long,
        val playWhenReady: Boolean,
    )

    private data class PendingHistoryFinalization(
        val sessionToken: Long,
        val eventId: Long?,
        val remoteRegistered: Boolean,
    )

    private data class ImmediateHistoryResult(
        val eventId: Long?,
        val remoteRegistered: Boolean,
    )

    private fun PlayerResponse.PlaybackTracking.remotePlaybackTrackingUrl(): String? =
        videostatsPlaybackUrl
            ?.baseUrl
            ?.trim()
            ?.takeIf { it.isNotEmpty() }

    private fun ResolvedAudioStream.toPlaybackData(mediaId: String): YTPlayerUtils.PlaybackData {
        val resolvedMimeType =
            if (codecs.isBlank()) {
                mimeType
            } else {
                "$mimeType; codecs=\"$codecs\""
            }
        val tracking =
            playbackTrackingUrl?.let { url ->
                PlayerResponse.PlaybackTracking(
                    videostatsPlaybackUrl = PlayerResponse.PlaybackTracking.VideostatsPlaybackUrl(url),
                    videostatsWatchtimeUrl = null,
                    atrUrl = null,
                )
            }
        return YTPlayerUtils.PlaybackData(
            audioConfig =
                PlayerResponse.PlayerConfig.AudioConfig(
                    loudnessDb = loudnessDb,
                    perceptualLoudnessDb = perceptualLoudnessDb,
                ),
            videoDetails =
                PlayerResponse.VideoDetails(
                    videoId = mediaId,
                    title = title,
                    lengthSeconds = durationSeconds?.toString(),
                ),
            playbackTracking = tracking,
            format =
                PlayerResponse.StreamingData.Format(
                    itag = formatId,
                    url = url,
                    mimeType = resolvedMimeType,
                    bitrate = bitrate,
                    width = null,
                    height = null,
                    contentLength = contentLength.takeIf { it > 0L },
                    quality = "",
                    fps = null,
                    qualityLabel = null,
                    averageBitrate = bitrate,
                    audioQuality = null,
                    approxDurationMs = durationSeconds?.times(1_000L)?.toString(),
                    audioSampleRate = sampleRate,
                    audioChannels = null,
                    loudnessDb = loudnessDb,
                    lastModified = null,
                    signatureCipher = null,
                    cipher = null,
                ),
            streamUrl = url,
            streamExpiresInSeconds =
                ((expiresAtMs - System.currentTimeMillis()) / 1_000L)
                    .coerceIn(1L, Int.MAX_VALUE.toLong())
                    .toInt(),
            authFingerprint = authFingerprint,
        )
    }

    private fun isAppInForeground(): Boolean {
        val activityManager = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val appProcesses = activityManager.runningAppProcesses ?: return false
        return appProcesses.any { processInfo ->
            processInfo.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND &&
                processInfo.processName == packageName
        }
    }

    private fun promptLoginRecovery(
        mediaId: String,
        targetUrl: String,
    ) {
        if (!isAppInForeground()) return

        val now = System.currentTimeMillis()
        val lastPrompt = lastLoginRecoveryPrompt
        if (lastPrompt?.first == mediaId && now - lastPrompt.second < 10000L) return
        lastLoginRecoveryPrompt = mediaId to now

        val deepLink = Uri.parse("archivetune://login?url=${Uri.encode(targetUrl)}")
        val intent =
            Intent(Intent.ACTION_VIEW, deepLink, this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
                addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            }

        runCatching {
            startActivity(intent)
        }.onFailure {
            Timber.e(it, "Failed to open login recovery for %s", mediaId)
        }
    }

    private fun Throwable.isRequestTimeout(): Boolean {
        var current: Throwable? = this
        while (current != null) {
            if (current is SocketTimeoutException) return true
            if (current is YoutubeiException && current.kind == YoutubeiFailureKind.TIMEOUT) return true
            if (current.message?.contains("Request timeout has expired", ignoreCase = true) == true) return true
            current = current.cause
        }
        return false
    }

    private fun Throwable.isNetworkConnectionFailure(): Boolean {
        var current: Throwable? = this
        while (current != null) {
            if (current is ConnectException || current is UnknownHostException) return true
            current = current.cause
        }
        return false
    }

    private fun isNetworkCurrentlyConnected(): Boolean =
        isNetworkConnected.value ||
            (::connectivityObserver.isInitialized && connectivityObserver.isCurrentlyConnected())

    private fun Throwable.isTransientNetworkFailure(): Boolean =
        isRequestTimeout() || isNetworkConnectionFailure()

    lateinit var sleepTimer: SleepTimer

    @Inject
    @PlayerCache
    lateinit var playerCache: Cache

    @Inject
    @DownloadCache
    lateinit var downloadCache: Cache

    private lateinit var localPlaybackPlayer: SwappableLocalPlayer
    val localPlayer: ExoPlayer
        get() = localPlaybackPlayer.exoPlayer
    lateinit var player: Player
        private set
    private var pendingQueueRemoval: QueueRemoval? = null
    private lateinit var castPlaybackRepository: CastPlaybackRepository
    private lateinit var mediaSession: MediaLibrarySession

    private var isAudioEffectSessionOpened = false
    private var openedAudioSessionId: Int? = null
    val eqCapabilities = MutableStateFlow<EqCapabilities?>(null)
    private val desiredEqSettings =
        MutableStateFlow(
            EqSettings(
                enabled = false,
                bandLevelsMb = emptyList(),
                outputGainEnabled = false,
                outputGainMb = 0,
                bassBoostEnabled = false,
                bassBoostStrength = 0,
                virtualizerEnabled = false,
                virtualizerStrength = 0,
                autoHeadroomEnabled = false,
            ),
        )

    private var audioEffectsSessionId: Int? = null
    private var audioEffectsInitializationJob: Job? = null
    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var virtualizer: Virtualizer? = null
    private var loudnessEnhancer: LoudnessEnhancer? = null
    private val audioEffectPlayerListener =
        object : Player.Listener {
            override fun onEvents(
                player: Player,
                events: Player.Events,
            ) {
                if (events.containsAny(
                        Player.EVENT_AUDIO_SESSION_ID,
                        Player.EVENT_PLAYBACK_STATE_CHANGED,
                        Player.EVENT_IS_PLAYING_CHANGED,
                    )
                ) {
                    reconcileAudioEffectSession()
                }
            }
        }

    private var lastDiscordUpdateTime = 0L

    private var scrobbleManager: moe.rukamori.archivetune.utils.ScrobbleManager? = null

    private lateinit var widgetUpdater: MusicServiceWidgetUpdater

    private var consecutivePlaybackErr = 0

    val maxSafeGainFactor = MAX_AUDIO_NORMALIZATION_FACTOR

    val togetherSessionState =
        MutableStateFlow<moe.rukamori.archivetune.together.TogetherSessionState>(
            moe.rukamori.archivetune.together.TogetherSessionState.Idle,
        )
    private var togetherServer: moe.rukamori.archivetune.together.TogetherServer? = null
    private var togetherOnlineHost: moe.rukamori.archivetune.together.TogetherOnlineHost? = null
    private var togetherClient: moe.rukamori.archivetune.together.TogetherClient? = null
    private var togetherBroadcastJob: Job? = null
    private var togetherOnlineConnectJob: Job? = null
    private var togetherClientEventsJob: Job? = null
    private var togetherHeartbeatJob: Job? = null
    private var togetherHostInactivityJob: Job? = null
    private var togetherHostInactivityEndSession: (suspend () -> Unit)? = null
    private var togetherClock: moe.rukamori.archivetune.together.TogetherClock? = null
    private var togetherSelfParticipantId: String? = null
    private var togetherAuthorityParticipantId: String? = null
    private var togetherLastAppliedQueueHash: String? = null
    private var togetherIsOnlineSession: Boolean = false

    @Volatile
    private var togetherApplyingRemote: Boolean = false

    @Volatile
    private var togetherSuppressEchoUntilElapsedMs: Long = 0L

    @Volatile
    private var togetherLastAppliedRoomStateSentAtElapsedMs: Long = 0L

    @Volatile
    private var togetherLastRemoteAppliedPlayWhenReady: Boolean? = null

    @Volatile
    private var togetherLastRemoteAppliedIndex: Int = -1

    @Volatile
    private var togetherLastSentControlAtElapsedMs: Long = 0L

    @Volatile
    private var togetherLastSentControlAction: moe.rukamori.archivetune.together.ControlAction? = null

    @Volatile
    private var togetherPendingGuestControl: TogetherPendingGuestControl? = null

    private fun isTogetherApplyingRemote(): Boolean = togetherApplyingRemote

    private val togetherHostId: String = "host"
    private val togetherParticipantNames = ConcurrentHashMap<String, String>()
    private var lastTogetherNoticeAtElapsedMs: Long = 0L
    private var lastTogetherNoticeKey: String? = null

    private data class TogetherPendingGuestControl(
        val desiredIsPlaying: Boolean? = null,
        val desiredIndex: Int? = null,
        val desiredTrackId: String? = null,
        val requestedAtElapsedMs: Long,
        val expiresAtElapsedMs: Long,
    )

    private fun showTogetherNotice(
        message: String,
        key: String? = null,
    ) {
        val now = android.os.SystemClock.elapsedRealtime()
        val normalizedKey = key ?: message
        if (normalizedKey == lastTogetherNoticeKey && now - lastTogetherNoticeAtElapsedMs < 1200L) return
        lastTogetherNoticeKey = normalizedKey
        lastTogetherNoticeAtElapsedMs = now
        scope.launch(SilentHandler) {
            Toast.makeText(this@MusicService, message, Toast.LENGTH_SHORT).show()
        }
    }

    private fun showTogetherParticipantNotification(
        participantName: String,
        joined: Boolean,
    ) {
        val normalizedName = participantName.trim().ifBlank { getString(R.string.together_unknown_participant) }
        val contentText =
            getString(
                if (joined) {
                    R.string.together_participant_joined_notification
                } else {
                    R.string.together_participant_left_notification
                },
                normalizedName,
            )
        val contentIntent =
            PendingIntent.getActivity(
                this,
                0,
                Intent(this, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
            )
        val notification =
            NotificationCompat
                .Builder(this, TOGETHER_NOTIFICATION_CHANNEL_ID)
                .setSmallIcon(R.drawable.small_icon)
                .setContentTitle(getString(R.string.music_together))
                .setContentText(contentText)
                .setContentIntent(contentIntent)
                .setCategory(Notification.CATEGORY_STATUS)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true)
                .build()

        runCatching {
            getSystemService(NotificationManager::class.java)
                ?.notify(TOGETHER_PARTICIPANT_NOTIFICATION_ID, notification)
        }.onFailure { error ->
            Timber.tag("Together").v(error, "Unable to show participant notification")
        }
    }

    private fun showTogetherInactivityNotification() {
        val contentIntent =
            PendingIntent.getActivity(
                this,
                0,
                Intent(this, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
            )
        val notification =
            NotificationCompat
                .Builder(this, TOGETHER_NOTIFICATION_CHANNEL_ID)
                .setSmallIcon(R.drawable.small_icon)
                .setContentTitle(getString(R.string.music_together))
                .setContentText(getString(R.string.together_room_closed_inactivity_notification))
                .setContentIntent(contentIntent)
                .setCategory(Notification.CATEGORY_STATUS)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true)
                .build()

        runCatching {
            getSystemService(NotificationManager::class.java)
                ?.notify(TOGETHER_INACTIVITY_NOTIFICATION_ID, notification)
        }.onFailure { error ->
            Timber.tag("Together").v(error, "Unable to show inactivity notification")
        }
    }

    private fun cancelTogetherHostInactivityTimeout() {
        togetherHostInactivityJob?.cancel()
        togetherHostInactivityJob = null
    }

    private fun scheduleTogetherHostInactivityTimeout(
        sessionId: String,
        endOnlineSession: (suspend () -> Unit)? = togetherHostInactivityEndSession,
    ) {
        cancelTogetherHostInactivityTimeout()
        togetherHostInactivityEndSession = endOnlineSession
        togetherHostInactivityJob =
            ioScope.launch(SilentHandler) {
                delay(TOGETHER_HOST_INACTIVITY_TIMEOUT_MS)

                val currentState = togetherSessionState.value
                val isCurrentHostSession =
                    when (currentState) {
                        is moe.rukamori.archivetune.together.TogetherSessionState.Hosting -> {
                            currentState.sessionId == sessionId
                        }

                        is moe.rukamori.archivetune.together.TogetherSessionState.HostingOnline -> {
                            currentState.sessionId == sessionId
                        }

                        is moe.rukamori.archivetune.together.TogetherSessionState.Joined -> {
                            currentState.sessionId == sessionId &&
                                currentState.role is moe.rukamori.archivetune.together.TogetherRole.Host
                        }

                        else -> {
                            false
                        }
                    }
                val isLocalAuthority =
                    togetherAuthorityParticipantId == null ||
                        togetherAuthorityParticipantId == togetherHostId
                val participants =
                    togetherServer?.currentParticipants()
                        ?: togetherOnlineHost?.currentParticipants()
                        ?: emptyList()
                val hasConnectedGuest =
                    participants.any { participant ->
                        participant.id != togetherHostId &&
                            participant.isConnected &&
                            !participant.isPending
                    }
                if (!isCurrentHostSession ||
                    !isLocalAuthority ||
                    togetherParticipantNames.isNotEmpty() ||
                    hasConnectedGuest
                ) {
                    togetherHostInactivityJob = null
                    return@launch
                }

                togetherHostInactivityJob = null
                runCatching { endOnlineSession?.invoke() }
                    .onFailure { error ->
                        Timber.tag("Together").w(error, "Unable to end inactive online room")
                    }
                stopTogetherInternal()
                togetherSessionState.value = moe.rukamori.archivetune.together.TogetherSessionState.Idle
                showTogetherInactivityNotification()
                scheduleStopIfIdle()
            }
    }

    private suspend fun getOrCreateTogetherClientId(): String {
        val existing = dataStore.getAsync(TogetherClientIdKey)?.trim().orEmpty()
        if (existing.isNotBlank()) return existing
        val generated =
            java.util.UUID
                .randomUUID()
                .toString()
        dataStore.edit { prefs -> prefs[TogetherClientIdKey] = generated }
        return generated
    }

    private fun buildStartupNotification(): Notification {
        val contentIntent =
            PendingIntent.getActivity(
                this,
                0,
                Intent(this, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
            )

        return NotificationCompat
            .Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.small_icon)
            .setContentTitle(getString(R.string.music_player))
            .setContentText(getString(R.string.app_name))
            .setContentIntent(contentIntent)
            .setCategory(Notification.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
    }

    private fun enterForegroundForStartCommand() {
        val mediaNotification =
            if (hasResumablePlaybackNotification()) mediaNotificationProvider.latestNotification else null
        val notificationId = mediaNotification?.notificationId ?: NOTIFICATION_ID
        val notification =
            mediaNotification?.notification
                ?: runCatching { buildStartupNotification() }
                    .onFailure { reportException(it) }
                    .getOrNull()
                ?: return

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                    notificationId,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK,
                )
            } else {
                startForeground(notificationId, notification)
            }
        } catch (e: Exception) {
            reportException(e)
        }
    }

    private fun ensureForegroundPlaybackService() {
        if (!isPlaybackServiceStarted) {
            try {
                isPlaybackServiceStarted =
                    startService(Intent(this, MusicService::class.java)) != null
            } catch (exception: Exception) {
                reportException(exception)
                return
            }
        }
        enterForegroundForStartCommand()
    }

    private fun cancelIdleStop() {
        idleStopJob?.cancel()
        idleStopJob = null
    }

    private fun hasResumablePlaybackNotification(): Boolean {
        val state = player.playbackState
        return player.mediaItemCount > 0 &&
            player.currentMediaItem != null &&
            state != Player.STATE_IDLE &&
            state != Player.STATE_ENDED
    }

    private fun stopForegroundAndSelf() {
        cancelIdleStop()
        isPlaybackServiceStarted = false
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                stopForeground(STOP_FOREGROUND_REMOVE)
            } else {
                stopForeground(true)
            }
        }
        mediaNotificationProvider.clearLatestNotification()
        stopSelf()
    }

    private fun scheduleStopIfIdle() {
        if (hasBoundClients) return
        if (hasResumablePlaybackNotification()) {
            cancelIdleStop()
            return
        }
        val togetherIdle = togetherSessionState.value is moe.rukamori.archivetune.together.TogetherSessionState.Idle
        if (!togetherIdle) {
            cancelIdleStop()
            return
        }

        val state = player.playbackState
        val delayMs =
            when (state) {
                Player.STATE_ENDED, Player.STATE_IDLE -> 30_000L
                else -> 60_000L
            }

        cancelIdleStop()
        idleStopJob =
            scope.launch {
                delay(delayMs)
                if (hasBoundClients) return@launch
                if (hasResumablePlaybackNotification()) return@launch
                if (togetherSessionState.value !is moe.rukamori.archivetune.together.TogetherSessionState.Idle) return@launch
                stopForegroundAndSelf()
            }
    }

    override fun onCreate() {
        super.onCreate()
        equalizerPlaybackController.attach(this)
        ensureScopesActive()

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val nm = getSystemService(NotificationManager::class.java)
                nm?.createNotificationChannel(
                    NotificationChannel(
                        CHANNEL_ID,
                        getString(R.string.music_player),
                        NotificationManager.IMPORTANCE_LOW,
                    ),
                )
                nm?.createNotificationChannel(
                    NotificationChannel(
                        TOGETHER_NOTIFICATION_CHANNEL_ID,
                        getString(R.string.music_together),
                        NotificationManager.IMPORTANCE_DEFAULT,
                    ),
                )
            }
        } catch (e: Exception) {
            reportException(e)
        }

        bitPerfectOutput.setDeviceVolume(dataStore.get(UsbDacVolumeKey, DEFAULT_USB_DAC_VOLUME_PERCENT) / 100f)
        bitPerfectOutput.configure(
            enabled = dataStore.get(UsbBitPerfectKey, false),
            driver = dataStore[UsbBitPerfectDriverKey].toEnum(UsbBitPerfectDriver.ANDROID),
            allowFixedVolume = dataStore.get(UsbBitPerfectFixedVolumeKey, false),
        )
        localPlaybackPlayer =
            SwappableLocalPlayer(
                buildLocalExoPlayer().apply {
                    addAnalyticsListener(PlaybackStatsListener(false, this@MusicService))
                },
            ).apply {
                addListener(audioEffectPlayerListener)
            }
        castPlaybackRepository = CastPlaybackRepositoryLocator.get(this)
        player =
            castPlaybackRepository
                .createPlayer(
                    context = this,
                    localPlayer = localPlaybackPlayer,
                    mediaItemResolver =
                        object : CastMediaItemResolver {
                            override fun resolveForCast(mediaItem: MediaItem): MediaItem =
                                resolveMediaItemForCast(mediaItem, blocking = false)

                            override fun resolveForCastBlocking(mediaItem: MediaItem): MediaItem =
                                resolveMediaItemForCast(mediaItem, blocking = true)

                            override fun mimeTypeForCast(mediaItem: MediaItem): String? =
                                mediaItem.localConfiguration?.mimeType
                                    ?.toCastMimeType()
                                    ?: mediaItem.localConfiguration
                                        ?.customCacheKey
                                        ?.let(castMimeTypeCache::get)
                                    ?: castMimeTypeCache.get(mediaItem.mediaId)
                        },
                ).apply {
                    addListener(this@MusicService)
                    sleepTimer = SleepTimer(scope, this, this@MusicService)
                    addListener(sleepTimer)
                }
        crossfadeHandler =
            CrossfadeHandler(
                scope = { scope },
                host = localPlaybackPlayer,
                isLocalPlayback = ::isLocalPlaybackActive,
                canStart = { crossfadeEnabled && !sleepTimer.pauseWhenSongEnd && !bitPerfectOutput.status.value.active },
                createPlayer = ::createCrossfadePlayer,
                activatePlayer = ::activateCrossfadePlayer,
                releasePlayer = ::releaseCrossfadePlayer,
                volumeFor = { mediaId -> currentEffectivePlayerVolumeForMediaId(mediaId).coerceIn(0f, maxSafeGainFactor) },
                onFadeFinished = ::onCrossfadeFinished,
                onAbandoned = ::onCrossfadeAbandoned,
            )
        sponsorBlockPlaybackController.attach(player, scope)
        playerInitialized.value = true
        observePlaybackPreloadConfiguration()
            .collect(scope) { configuration ->
                playbackPreloadConfiguration = configuration
                updateNextStreamPreload()
            }
        database
            .blockedArtistIds()
            .map { ids -> ids.toSet() }
            .distinctUntilChanged()
            .flowOn(Dispatchers.IO)
            .collect(scope) { updatedBlockedArtistIds ->
                blockedArtistIds = updatedBlockedArtistIds
                removeBlockedArtistItems(updatedBlockedArtistIds)
            }
        dataStore.data
            .map { preferences -> preferences[HideVideoKey] ?: false }
            .distinctUntilChanged()
            .collect(scope) { shouldHideMusicVideos ->
                hideMusicVideos = shouldHideMusicVideos
                if (shouldHideMusicVideos) {
                    removeMusicVideoItems()
                }
            }
        widgetUpdater =
            MusicServiceWidgetUpdater(
                service = this,
                player = player,
                scope = scope,
                loadWidgetInsights = loadWidgetInsightsUseCase,
                loadWidgetRecentSongs = loadWidgetRecentSongsUseCase,
            )

        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        audioOutputResolver = AudioOutputResolver(audioManager)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            audioManager.setAllowedCapturePolicy(android.media.AudioAttributes.ALLOW_CAPTURE_BY_ALL)
        }
        wakeLock =
            (getSystemService(Context.POWER_SERVICE) as PowerManager)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ArchiveTune:Playback")
                .also { it.setReferenceCounted(false) }
        setupAudioFocusRequest()
        audioManager.registerAudioDeviceCallback(audioDeviceCallback, android.os.Handler(mainLooper))
        audioDeviceCallbackRegistered = true
        lastAudioOutputDeviceSignature = currentAudioOutputDeviceSignature()
        audioOutputResolver.refresh()
        bitPerfectOutput.refreshDevice()
        updateAudioBecomingNoisyHandling()

        mediaLibrarySessionCallback.apply {
            toggleLike = ::toggleLike
            toggleStartRadio = ::toggleStartRadio
            toggleLibrary = ::toggleLibrary
            toggleDownload = ::toggleCurrentDownload
            toggleSleepTimer = ::toggleSleepTimerFromNotification
            closePlayback = ::closePlaybackFromNotification
            seekByIncrement = ::seekByNotificationIncrement
            carMediaButtonPreferences = ::buildAndroidAutoButtons
            adoptQueueContinuation = ::adoptQueueContinuation
        }
        val mediaSessionBuilder = MediaLibrarySession.Builder(this, player, mediaLibrarySessionCallback)
            .setBitmapLoader(CoilBitmapLoader(this, scope))
        if (BuildConfig.DEVICE != "automotive") {
            mediaSessionBuilder.setSessionActivity(
                    PendingIntent.getActivity(
                        this,
                        0,
                        Intent(this, MainActivity::class.java),
                        PendingIntent.FLAG_IMMUTABLE,
                    ),
                )
        }
        mediaSession = mediaSessionBuilder.build()
        mediaNotificationProvider =
            ArchiveTuneMediaNotificationProvider(
                context = this,
                smallIconResId = R.drawable.small_icon,
            )
        setMediaNotificationProvider(mediaNotificationProvider)
        addSession(mediaSession)

        notificationConfiguration = mediaNotificationSettings.currentConfiguration()
        updateNotification()
        mediaNotificationSettings.configuration.collect(scope) { configuration ->
            notificationConfiguration = configuration
            updateNotification()
        }
        snapshotFlow { sleepTimer.isActive }
            .distinctUntilChanged()
            .collect(scope) { updateNotification() }
        currentMediaMetadata
            .flatMapLatest { mediaMetadata ->
                if (mediaMetadata == null) flowOf(null) else moduleDownloadUtil.getDownload(mediaMetadata.id)
            }.map { it?.state }
            .distinctUntilChanged()
            .collect(scope) { state ->
                currentDownloadState = state
                updateNotification()
            }
        scope.launch {
            combine(
                androidAutoSettings.configuration,
                androidAutoSettings.networkState,
            ) { configuration, networkState -> configuration to networkState }
                .collect { (configuration, networkState) ->
                    updateAndroidAutoButtons(configuration)
                    mediaSession.notifyChildrenChanged(ROOT, 4, null)
                    val homeItemCount = if (
                        configuration.onlineRecommendations &&
                        networkState.online &&
                        (configuration.meteredPlayback || !networkState.metered)
                    ) 5 else 4
                    mediaSession.notifyChildrenChanged(HOME, homeItemCount, null)
                    mediaSession.notifyChildrenChanged(LIBRARY, 5, null)
                }
        }
        player.repeatMode = REPEAT_MODE_OFF

        scope.launch(Dispatchers.IO) {
            val prefs = dataStore.data.first()
            val repeatMode = prefs[RepeatModeKey] ?: REPEAT_MODE_OFF
            val volume = (prefs[PlayerVolumeKey] ?: 1f).coerceIn(0f, 1f)
            val offload = prefs[AudioOffload] ?: false
            val crossfadePrefEnabled = prefs[CrossfadeEnabledKey] ?: false
            withContext(Dispatchers.Main) {
                player.repeatMode = repeatMode
                playerVolume.value = volume
                updateAudioOffload(offload && !crossfadePrefEnabled)
            }
        }

        connectivityManager = getSystemService()!!
        connectivityObserver = NetworkConnectivityObserver(this)

        scope.launch {
            connectivityObserver.networkStatus.collect { isConnected ->
                isNetworkConnected.value = isConnected
                if (isConnected && waitingForNetworkConnection.value) {
                    waitingForNetworkConnection.value = false
                    if (player.currentMediaItem != null && player.playWhenReady &&
                        player.playbackState == Player.STATE_IDLE
                    ) {
                        if (!preparePlaybackFromSnapshot(capturePlaybackRecoverySnapshot())) {
                            player.prepare()
                        }
                        player.play()
                    }
                }
            }
        }

        combine(
            playerVolume,
            normalizeFactor,
            audioFocusVolumeFactor,
            recapAudioMuted,
            sleepTimerVolumeFactor,
        ) { playerVolume, normalizeFactor, audioFocusVolumeFactor, _, _ ->
            calculateEffectivePlayerVolume(playerVolume, normalizeFactor, audioFocusVolumeFactor)
        }.collectLatest(scope) { finalVolume ->
            updateEffectiveVolume(finalVolume)
        }

        playerVolume.debounce(1000).collect(ioScope) { volume ->
            dataStore.edit { settings ->
                settings[PlayerVolumeKey] = volume
            }
        }

        currentSong.debounce(300).collect(scope) { song ->
            updateNotification()
            requestDiscordSync(
                reason =
                    if (song == null) {
                        "current_song_cleared"
                    } else {
                        "current_song_changed"
                    },
            )
            if (song != null && player.playWhenReady && player.playbackState == Player.STATE_READY) {
                ensurePresenceManager()
            }
        }

        combine(
            currentMediaMetadata.distinctUntilChangedBy { it?.id },
            dataStore.data.map { it[ShowLyricsKey] ?: false }.distinctUntilChanged(),
        ) { mediaMetadata, showLyrics ->
            mediaMetadata to showLyrics
        }.collectLatest(ioScope) { (mediaMetadata, showLyrics) ->
            if (showLyrics && mediaMetadata != null && !mediaMetadata.isPodcast && database
                    .lyrics(mediaMetadata.id)
                    .first()
                    .needsRemoteFetch()
            ) {
                val fetched = lyricsHelper.getLyrics(mediaMetadata)
                if (fetched.isConclusive) {
                    database.query {
                        saveFetchedLyrics(
                            id = mediaMetadata.id,
                            lyrics = fetched.lyrics,
                            provider = fetched.providerName,
                            providerUrl = fetched.providerUrl,
                            providerAuthor = fetched.author,
                            providerAuthorUrl = fetched.authorUrl,
                        )
                    }
                }
            }
        }

        dataStore.data
            .map { it[SkipSilenceKey] ?: false }
            .distinctUntilChanged()
            .collectLatest(scope) {
                localPlayer.skipSilenceEnabled = it
            }

        dataStore.data
            .map { it[PauseOnDeviceMuteKey] ?: false }
            .distinctUntilChanged()
            .collectLatest(scope) { enabled ->
                pauseOnDeviceMuteEnabled = enabled
                if (!enabled) {
                    wasAutoPausedByDeviceMute = false
                    unregisterMuteRecoveryObserver()
                } else {
                    handleDeviceMuteStateChanged()
                }
            }

        dataStore.data
            .map { (it[DeviceMutePlaybackRecoveryVolumeKey] ?: 0).coerceIn(0, 100) }
            .distinctUntilChanged()
            .collectLatest(scope) { percent ->
                deviceMutePlaybackRecoveryVolumePercent = percent
            }

        dataStore.data
            .map { it[AutoStartOnBluetoothKey] ?: false }
            .distinctUntilChanged()
            .collectLatest(scope) { enabled ->
                autoStartOnBluetoothEnabled = enabled
                if (enabled) {
                    registerBluetoothReceiver()
                } else {
                    unregisterBluetoothReceiver()
                }
            }

        dataStore.data
            .map { prefs ->
                Triple(
                    prefs[UsbBitPerfectKey] ?: false,
                    prefs[UsbBitPerfectDriverKey].toEnum(UsbBitPerfectDriver.ANDROID),
                    prefs[UsbBitPerfectFixedVolumeKey] ?: false,
                )
            }.distinctUntilChanged()
            .collectLatest(scope) { (enabled, driver, allowFixedVolume) ->
                if (bitPerfectOutput.configure(enabled, driver, allowFixedVolume)) {
                    updateAudioBecomingNoisyHandling()
                    reselectAudioSinkOutput()
                }
            }

        dataStore.data
            .map { (it[UsbDacVolumeKey] ?: DEFAULT_USB_DAC_VOLUME_PERCENT).coerceIn(0, 100) }
            .distinctUntilChanged()
            .collectLatest(scope) { percent ->
                bitPerfectOutput.setDeviceVolume(percent / 100f)
            }

        bitPerfectOutput.events.collect(scope) { event ->
            updateAudioBecomingNoisyHandling()
            if (event == BitPerfectEvent.DAC_DETACHED && localPlayer.playWhenReady) {
                localPlayer.pause()
            }
            reselectAudioSinkOutput()
        }

        combine(
            dataStore.data.map { it[AudioOffload] ?: false },
            dataStore.data.map { it[CrossfadeEnabledKey] ?: false },
        ) { offloadEnabled, crossfadeEnabled ->
            offloadEnabled to crossfadeEnabled
        }.distinctUntilChanged()
            .collectLatest(scope) { (offloadEnabled, crossfadeEnabled) ->
                val effectiveOffload = offloadEnabled && !crossfadeEnabled
                updateAudioOffload(effectiveOffload)
                if (effectiveOffload) {
                    val skipSilenceEnabled = dataStore.get(SkipSilenceKey, false)
                    if (skipSilenceEnabled) {
                        dataStore.edit { it[SkipSilenceKey] = false }
                        localPlayer.skipSilenceEnabled = false
                    }
                }
            }

        combine(dataStore.data, togetherSessionState) { prefs, togetherState ->
            val enabled = prefs[CrossfadeEnabledKey] ?: false
            val durationSeconds = prefs[CrossfadeDurationKey] ?: 5f
            val gapless = prefs[CrossfadeGaplessKey] ?: true
            CrossfadeConfig(
                enabled = enabled && togetherState is moe.rukamori.archivetune.together.TogetherSessionState.Idle,
                durationSeconds = durationSeconds,
                gapless = gapless,
            )
        }.distinctUntilChanged()
            .collectLatest(scope) { config ->
                crossfadeEnabled = config.enabled
                if (!config.enabled) {
                    crossfadeSuppressedMediaId = null
                }
                crossfadeDurationMs =
                    (config.durationSeconds.coerceIn(0f, 10f) * 1000f)
                        .roundToLong()
                        .coerceAtLeast(0L)
                crossfadeGapless = config.gapless
                if (crossfadeEnabled && crossfadeDurationMs > 0L) {
                    scheduleCrossfade()
                } else {
                    cancelCrossfade(resetVolume = true)
                }
            }

        dataStore.data
            .map { it[WakelockKey] ?: false }
            .distinctUntilChanged()
            .collectLatest(scope) { enabled ->
                wakelockEnabled = enabled
                updateWakeLock()
            }

        dataStore.data
            .map(::readEqSettingsFromPrefs)
            .distinctUntilChanged()
            .collectLatest(scope) { settings ->
                desiredEqSettings.value = settings
                applyEqSettingsToEffects(settings)
            }

        combine(
            currentMediaMetadata
                .map { it?.id }
                .distinctUntilChanged(),
            currentFormat,
            dataStore.data
                .map { it[AudioNormalizationKey] ?: true }
                .distinctUntilChanged(),
        ) { mediaId, format, normalizeAudio ->
            normalizeAudio to resolveAudioNormalizationFactor(mediaId, format, normalizeAudio)
        }.distinctUntilChanged()
            .collectLatest(scope) { (normalizeAudio, factor) ->
                audioNormalizationEnabled = normalizeAudio
                normalizeFactor.value = factor
            }

        dataStore.data
            .map { it[DiscordTokenKey] to (it[EnableDiscordRPCKey] ?: true) }
            .debounce(300)
            .distinctUntilChanged()
            .collectLatest(scope) { (key, enabled) ->
                requestDiscordSync(
                    reason =
                        when {
                            !enabled -> "discord_rpc_disabled"
                            key.isNullOrBlank() -> "discord_token_missing"
                            else -> "discord_token_or_toggle_changed"
                        },
                    force = !enabled || key.isNullOrBlank(),
                )
                if (!key.isNullOrBlank() && enabled) {
                    if (player.playbackState == Player.STATE_READY && player.playWhenReady) {
                        currentSong.value?.let {
                            ensurePresenceManager()
                        }
                    }
                }
            }

        dataStore.data
            .map { prefs ->
                (prefs[SmartTrimmerKey] ?: false) to (prefs[MaxSongCacheSizeKey] ?: 1024)
            }.debounce(300)
            .distinctUntilChanged()
            .collectLatest(ioScope) { (enabled, maxSongCacheSizeMb) ->
                if (!enabled) return@collectLatest
                if (maxSongCacheSizeMb <= 0 || maxSongCacheSizeMb == -1) return@collectLatest
                val bytesPerMb = 1024L * 1024L
                val safeSizeMb = maxSongCacheSizeMb.toLong().coerceAtMost(Long.MAX_VALUE / bytesPerMb)
                val limitBytes = safeSizeMb * bytesPerMb
                trimPlayerCacheToBytes(limitBytes)
            }

        dataStore.data
            .map { preferences ->
                val serviceConfig = LastFmServiceConfig.fromPreferences(preferences)
                val enabled = preferences[EnableLastFMScrobblingKey] ?: false
                val hasSession = !preferences[LastFMSessionKey].isNullOrBlank()
                val serviceConfigured = serviceConfig.initialized
                val historyPaused = preferences[PauseListenHistoryKey] ?: false
                enabled && hasSession && serviceConfigured && !historyPaused
            }.debounce(300)
            .distinctUntilChanged()
            .collect(scope) { shouldEnable ->
                if (shouldEnable && scrobbleManager == null) {
                    val delayPercent = dataStore.get(ScrobbleDelayPercentKey, LastFM.DEFAULT_SCROBBLE_DELAY_PERCENT)
                    val minSongDuration = dataStore.get(ScrobbleMinSongDurationKey, LastFM.DEFAULT_SCROBBLE_MIN_SONG_DURATION)
                    val delaySeconds = dataStore.get(ScrobbleDelaySecondsKey, LastFM.DEFAULT_SCROBBLE_DELAY_SECONDS)

                    scrobbleManager =
                        moe.rukamori.archivetune.utils.ScrobbleManager(
                            ioScope,
                            minSongDuration = minSongDuration,
                            scrobbleDelayPercent = delayPercent,
                            scrobbleDelaySeconds = delaySeconds,
                        )
                    scrobbleManager?.useNowPlaying = dataStore.get(LastFMUseNowPlaying, false)
                } else if (!shouldEnable && scrobbleManager != null) {
                    scrobbleManager?.destroy()
                    scrobbleManager = null
                }
            }

        dataStore.data
            .map { it[LastFMUseNowPlaying] ?: false }
            .distinctUntilChanged()
            .collectLatest(scope) {
                scrobbleManager?.useNowPlaying = it
            }

        dataStore.data
            .map { prefs ->
                Triple(
                    prefs[ScrobbleDelayPercentKey] ?: LastFM.DEFAULT_SCROBBLE_DELAY_PERCENT,
                    prefs[ScrobbleMinSongDurationKey] ?: LastFM.DEFAULT_SCROBBLE_MIN_SONG_DURATION,
                    prefs[ScrobbleDelaySecondsKey] ?: LastFM.DEFAULT_SCROBBLE_DELAY_SECONDS,
                )
            }.distinctUntilChanged()
            .collect(scope) { (delayPercent, minSongDuration, delaySeconds) ->
                scrobbleManager?.let {
                    it.scrobbleDelayPercent = delayPercent
                    it.minSongDuration = minSongDuration
                    it.scrobbleDelaySeconds = delaySeconds
                }
            }

        scope.launch(Dispatchers.IO) {
            runCatching {
                if (dataStore.get(PersistentQueueKey, true)) {
                    playerInitialized.first { it }
                    val persistedQueue = readPersistentObject<PersistQueue>(PERSISTENT_QUEUE_FILE)
                    val persistedPlayerState = readPersistentObject<PersistPlayerState>(PERSISTENT_PLAYER_STATE_FILE)

                    if (persistedQueue != null || persistedPlayerState != null) {
                        isRestoringPersistentState = true
                    }

                    var restoredQueue = false
                    try {
                        persistedQueue?.let { queue ->
                            restorePersistentQueue(queue)
                            restoredQueue = true
                        }
                        persistedPlayerState?.let { playerState ->
                            restorePersistentPlayerState(playerState, restoredQueue)
                        }
                    } finally {
                        isRestoringPersistentState = false
                    }
                }
            }.onFailure { error ->
                if (error is CancellationException) throw error
                Timber.tag(TAG).w(error, "Failed to restore persisted queue, clearing data")
                isRestoringPersistentState = false
                cancelRestoredQueueHydration()
                clearPersistedQueueFiles()
            }
            withContext(Dispatchers.Main) {
                queueRestoreCompleted.value = true
            }
        }

        scope.launch {
            while (isActive) {
                delay(if (player.isPlaying) 10.seconds else 30.seconds)
                val shouldSave = withContext(Dispatchers.IO) { dataStore.get(PersistentQueueKey, true) }
                if (shouldSave && player.mediaItemCount > 0) {
                    saveQueueToDisk()
                }
            }
        }
    }

    private fun ensureScopesActive() {
        if (!scopeJob.isActive) {
            scopeJob = SupervisorJob()
        }
        if (!scope.isActive) {
            scope = CoroutineScope(Dispatchers.Main + scopeJob)
        }
        if (!ioScope.isActive) {
            ioScope = CoroutineScope(Dispatchers.IO + scopeJob)
        }
        startDiscordSyncWorker()
    }

    private fun startDiscordSyncWorker() {
        if (discordSyncWorkerJob?.isActive == true) return
        discordSyncWorkerJob =
            scope.launch(Dispatchers.IO) {
                for (request in discordSyncRequests) {
                    try {
                        syncDiscordStateInternal(request)
                    } catch (_: StaleDiscordSyncException) {
                        Timber.tag(DISCORD_SYNC_TAG).d(
                            "stale sync aborted epoch=%d reason=%s",
                            request.epoch,
                            request.reason,
                        )
                    } catch (error: CancellationException) {
                        throw error
                    } catch (error: Exception) {
                        Timber.tag(DISCORD_SYNC_TAG).e(
                            error,
                            "sync failed epoch=%d reason=%s",
                            request.epoch,
                            request.reason,
                        )
                    }
                }
            }
    }

    private fun requestDiscordSync(
        reason: String,
        force: Boolean = false,
    ) {
        val request =
            DiscordSyncRequest(
                epoch = discordSyncEpoch.incrementAndGet(),
                reason = reason,
                force = force,
            )
        if (discordSyncRequests.trySend(request).isFailure) {
            Timber.tag(DISCORD_SYNC_TAG).w(
                "failed to enqueue sync epoch=%d reason=%s",
                request.epoch,
                request.reason,
            )
        }
    }

    fun forceDiscordSync(reason: String) {
        requestDiscordSync(
            reason = reason,
            force = true,
        )
    }

    private fun ensureDiscordSyncFresh(epoch: Long) {
        if (epoch != discordSyncEpoch.get()) {
            throw StaleDiscordSyncException()
        }
    }

    private fun updateActiveDiscordHoldState(nextHoldState: ActiveHoldState?) {
        val previousHoldState = activeDiscordHoldState
        activeDiscordHoldState = nextHoldState
        Timber.tag(DISCORD_SYNC_TAG).d(
            "hold state transition previous=%s next=%s",
            previousHoldState,
            nextHoldState,
        )
        reconcileDiscordHoldTimeoutJob(previousHoldState, nextHoldState)
    }

    private fun reconcileDiscordHoldTimeoutJob(
        previousHoldState: ActiveHoldState?,
        nextHoldState: ActiveHoldState?,
    ) {
        if (previousHoldState === nextHoldState) {
            Timber.tag(DISCORD_SYNC_TAG).v("hold timeout job unchanged for holdState=%s", nextHoldState)
            return
        }

        activeDiscordHoldTimeoutJob?.cancel()
        activeDiscordHoldTimeoutJob = null

        if (nextHoldState == null) {
            Timber.tag(DISCORD_SYNC_TAG).d("no active hold state, no timeout job scheduled")
            return
        }

        Timber.tag(DISCORD_SYNC_TAG).d(
            "scheduling hold timeout job state=%s timeoutMs=%d",
            nextHoldState,
            DISCORD_HOLD_TIMEOUT_MS,
        )
        activeDiscordHoldTimeoutJob =
            scope.launch {
                delay(DISCORD_HOLD_TIMEOUT_MS)
                Timber.tag(DISCORD_SYNC_TAG).d(
                    "hold timeout fired state=%s -> enqueue resync",
                    nextHoldState,
                )
                requestDiscordSync(
                    reason = "hold_timeout_check",
                    force = true,
                )
            }
    }

    private fun clearDiscordHoldState() {
        if (activeDiscordHoldState != null) {
            Timber.tag(DISCORD_SYNC_TAG).d("clearing active hold state=%s", activeDiscordHoldState)
        }
        updateActiveDiscordHoldState(null)
    }

    private fun markLastAppliedVisiblePresence(visibleDecision: DiscordPresenceDecision.Visible) {
        lastAppliedVisiblePresence =
            LastAppliedVisiblePresence(
                songId = visibleDecision.songId,
                mode = visibleDecision.mode,
                appliedAtMs = System.currentTimeMillis(),
            )
        Timber.tag(DISCORD_SYNC_TAG).d(
            "marked last applied visible presence songId=%s mode=%s",
            visibleDecision.songId,
            visibleDecision.mode,
        )
    }

    private suspend fun addPendingDiscordRefreshWaiter(waiter: CompletableDeferred<Boolean>) {
        discordRefreshWaitersMutex.withLock {
            pendingDiscordRefreshWaiters += waiter
        }
    }

    private suspend fun takePendingDiscordRefreshWaiters(): List<CompletableDeferred<Boolean>> =
        discordRefreshWaitersMutex.withLock {
            val snapshot = pendingDiscordRefreshWaiters.toList()
            pendingDiscordRefreshWaiters.removeAll(snapshot)
            snapshot
        }

    private suspend fun requeueDiscordRefreshWaiters(waiters: List<CompletableDeferred<Boolean>>) {
        if (waiters.isEmpty()) return
        discordRefreshWaitersMutex.withLock {
            waiters.forEach { waiter ->
                if (!waiter.isCompleted && !waiter.isCancelled) {
                    pendingDiscordRefreshWaiters += waiter
                }
            }
        }
    }

    private fun completeDiscordRefreshWaiters(
        waiters: List<CompletableDeferred<Boolean>>,
        result: Boolean,
    ) {
        waiters.forEach { waiter ->
            if (!waiter.isCompleted && !waiter.isCancelled) {
                waiter.complete(result)
            }
        }
    }

    suspend fun refreshDiscordNow(): Boolean {
        val waiter = CompletableDeferred<Boolean>()
        addPendingDiscordRefreshWaiter(waiter)
        requestDiscordSync(
            reason = "manual_refresh",
            force = true,
        )
        return try {
            withTimeout(15_000L) { waiter.await() }
        } catch (error: CancellationException) {
            false
        } catch (_: Exception) {
            false
        }
    }

    private suspend fun syncDiscordStateInternal(request: DiscordSyncRequest) {
        val refreshWaiters = takePendingDiscordRefreshWaiters()
        try {
            ensureDiscordSyncFresh(request.epoch)

            val enabled = dataStore.get(EnableDiscordRPCKey, true)
            val token = dataStore.get(DiscordTokenKey, "")
            val hasToken = token.isNotBlank()
            val showWhenPaused = dataStore.get(DiscordShowWhenPausedKey, false)
            val (song, isPlaying, playWhenReady, playbackState) =
                withContext(Dispatchers.Main.immediate) {
                    Quadruple(
                        currentPresenceSong(),
                        player.isPlaying,
                        player.playWhenReady,
                        player.playbackState,
                    )
                }

            if (playWhenReady && pausedPresenceGate != PausedPresenceGate.FollowPreference) {
                pausedPresenceGate = PausedPresenceGate.FollowPreference
                Timber.tag(DISCORD_SYNC_TAG).d(
                    "sync epoch=%d reason=%s reset paused gate because playback intent resumed",
                    request.epoch,
                    request.reason,
                )
            }

            val inputs =
                DiscordPresenceInputs(
                    enabled = enabled,
                    hasToken = hasToken,
                    song = song,
                    isPlaying = isPlaying,
                    showWhenPaused = showWhenPaused,
                    pausedPresenceGate = pausedPresenceGate,
                    serviceStopping = discordServiceStopping,
                    playWhenReady = playWhenReady,
                    playbackState = playbackState,
                )
            val holdContext =
                DiscordHoldContext(
                    nowMs = System.currentTimeMillis(),
                    activeHoldState = activeDiscordHoldState,
                    lastAppliedVisiblePresence = lastAppliedVisiblePresence,
                    holdTimeoutMs = DISCORD_HOLD_TIMEOUT_MS,
                )
            val semanticState = derivePlaybackSemanticState(inputs)
            val rawDecision = deriveRawDiscordPresenceDecision(inputs, semanticState)
            val resolution = resolveDiscordPresenceDecision(rawDecision, holdContext)

            val decision = resolution.decision
            ensureDiscordSyncFresh(request.epoch)

            val effectiveForce = request.force || refreshWaiters.isNotEmpty()
            if (!effectiveForce && decision == lastDiscordPresenceDecision) {
                Timber.tag(DISCORD_SYNC_TAG).v(
                    "sync epoch=%d reason=%s unchanged decision=%s",
                    request.epoch,
                    request.reason,
                    decision,
                )
                completeDiscordRefreshWaiters(refreshWaiters, true)
                return
            }

            Timber.tag(DISCORD_SYNC_TAG).d(
                "sync epoch=%d reason=%s force=%s effectiveForce=%s songId=%s playWhenReady=%s playbackState=%d isPlaying=%s semantic=%s raw=%s decision=%s holdState=%s lastAppliedVisible=%s refreshWaiters=%d",
                request.epoch,
                request.reason,
                request.force,
                effectiveForce,
                song?.song?.id,
                playWhenReady,
                playbackState,
                isPlaying,
                semanticState,
                rawDecision,
                decision,
                resolution.nextHoldState,
                lastAppliedVisiblePresence,
                refreshWaiters.size,
            )

            val applied =
                applyDiscordPresenceDecision(
                    request = request,
                    resolution = resolution,
                    token = token,
                    song = song,
                )

            if (applied) {
                lastDiscordPresenceDecision = decision
            }
            if (decision is DiscordPresenceDecision.Hold) {
                requeueDiscordRefreshWaiters(refreshWaiters)
                Timber.tag(DISCORD_SYNC_TAG).d(
                    "refresh waiters requeued because decision is Hold count=%d",
                    refreshWaiters.size,
                )
            } else {
                completeDiscordRefreshWaiters(refreshWaiters, applied)
            }
        } catch (_: StaleDiscordSyncException) {
            requeueDiscordRefreshWaiters(refreshWaiters)
            Timber.tag(DISCORD_SYNC_TAG).d(
                "stale sync aborted epoch=%d reason=%s and refresh waiters requeued=%d",
                request.epoch,
                request.reason,
                refreshWaiters.size,
            )
        } catch (error: CancellationException) {
            completeDiscordRefreshWaiters(refreshWaiters, false)
            throw error
        } catch (error: Exception) {
            Timber.tag(DISCORD_SYNC_TAG).e(error, "syncDiscordStateInternal failed epoch=%d reason=%s", request.epoch, request.reason)
            completeDiscordRefreshWaiters(refreshWaiters, false)
            throw error
        }
    }

    private suspend fun applyDiscordPresenceDecision(
        request: DiscordSyncRequest,
        resolution: DiscordPresenceResolution,
        token: String,
        song: Song?,
    ): Boolean {
        ensureDiscordSyncFresh(request.epoch)

        val decision = resolution.decision
        Timber.tag(DISCORD_SYNC_TAG).d(
            "apply decision epoch=%d decision=%s tokenPresent=%s songId=%s",
            request.epoch,
            decision,
            token.isNotBlank() || !lastPresenceToken.isNullOrBlank(),
            song?.song?.id,
        )
        return when (decision) {
            is DiscordPresenceDecision.Hidden -> {
                clearDiscordHoldState()
                when (decision.reason) {
                    HiddenReason.NoSong,
                    HiddenReason.PausedByPreference,
                    HiddenReason.PausedByNotificationDismiss,
                    HiddenReason.NoStablePlaybackYet,
                    HiddenReason.PlaybackStalled,
                    -> {
                        ensureDiscordSyncFresh(request.epoch)
                        val cleared =
                            DiscordPresenceManager.clearNow(
                                context = this@MusicService,
                                token = token.takeIf { it.isNotBlank() } ?: lastPresenceToken,
                            )
                        if (!cleared) {
                            Timber.tag(DISCORD_SYNC_TAG).d(
                                "clear skipped or failed for hidden reason=%s",
                                decision.reason,
                            )
                        }
                        cleared
                    }

                    HiddenReason.Disabled -> {
                        ensureDiscordSyncFresh(request.epoch)
                        DiscordPresenceManager.stop(clearActivity = false)
                        lastPresenceToken = null
                        true
                    }

                    HiddenReason.ServiceStopping -> {
                        val clearToken = token.takeIf { it.isNotBlank() } ?: lastPresenceToken
                        ensureDiscordSyncFresh(request.epoch)
                        val cleared =
                            DiscordPresenceManager.clearNow(
                                context = this@MusicService,
                                token = clearToken,
                            )
                        if (!cleared) {
                            Timber.tag(DISCORD_SYNC_TAG).d(
                                "terminal clear skipped or failed for hidden reason=%s",
                                decision.reason,
                            )
                        }
                        ensureDiscordSyncFresh(request.epoch)
                        DiscordPresenceManager.stop()
                        lastPresenceToken = null
                        true
                    }

                    HiddenReason.NoToken -> {
                        val clearToken = token.takeIf { it.isNotBlank() } ?: lastPresenceToken
                        ensureDiscordSyncFresh(request.epoch)
                        if (clearToken.isNullOrBlank()) {
                            Timber.tag(DISCORD_SYNC_TAG).v(
                                "no token available for terminal clear; stopping manager only",
                            )
                        } else {
                            val cleared =
                                DiscordPresenceManager.clearNow(
                                    context = this@MusicService,
                                    token = clearToken,
                                )
                            if (!cleared) {
                                Timber.tag(DISCORD_SYNC_TAG).d(
                                    "terminal clear skipped or failed for hidden reason=%s",
                                    decision.reason,
                                )
                            }
                        }
                        ensureDiscordSyncFresh(request.epoch)
                        DiscordPresenceManager.stop()
                        lastPresenceToken = null
                        true
                    }
                }
            }

            is DiscordPresenceDecision.Visible -> {
                clearDiscordHoldState()
                ensureDiscordSyncFresh(request.epoch)
                val snapshot =
                    buildDiscordPresenceSnapshot(
                        song = song,
                        mode = decision.mode,
                    ) ?: run {
                        requestDiscordSync(
                            reason = "playback_changed_before_presence_apply",
                            force = true,
                        )
                        return false
                    }
                ensureDiscordSyncFresh(request.epoch)
                val updated =
                    DiscordPresenceManager.updateNow(
                        context = this@MusicService,
                        token = token,
                        song = snapshot.song,
                        positionMs = snapshot.positionMs,
                        isPaused = snapshot.isPaused,
                        isMusicVideo = currentMediaMetadata.value?.isMusicVideo ?: false,
                    )
                if (!updated) {
                    Timber.tag(DISCORD_SYNC_TAG).d(
                        "visible update failed songId=%s paused=%s",
                        decision.songId,
                        decision.isPaused,
                    )
                    false
                } else {
                    if (token.isNotBlank()) {
                        lastPresenceToken = token
                    }
                    markLastAppliedVisiblePresence(decision)
                    true
                }
            }

            is DiscordPresenceDecision.Hold -> {
                updateActiveDiscordHoldState(resolution.nextHoldState)
                true
            }
        }
    }

    private suspend fun buildDiscordPresenceSnapshot(
        song: Song?,
        mode: PresenceMode,
    ): DiscordPresenceSnapshot? {
        val expectedSong = song ?: return null
        return withContext(Dispatchers.Main.immediate) {
            val currentSong = currentPresenceSong() ?: return@withContext null
            if (currentSong.song.id != expectedSong.song.id) {
                return@withContext null
            }

            val isPaused =
                when {
                    !player.playWhenReady -> true
                    player.isPlaying -> false
                    else -> return@withContext null
                }
            if (isPaused != (mode == PresenceMode.Paused)) {
                return@withContext null
            }

            DiscordPresenceSnapshot(
                song = currentSong,
                positionMs = player.currentPosition,
                isPaused = isPaused,
            )
        }
    }

    private fun cancelRestoredQueueHydration() {
        restoredQueueHydrationGeneration.incrementAndGet()
        isHydratingRestoredQueue = false
    }

    private suspend fun Queue.Status.filterPlaybackContent(
        hideExplicit: Boolean,
        hideVideo: Boolean,
    ): Queue.Status =
        filterExplicit(hideExplicit)
            .filterVideo(hideVideo)
            .filterBlockedArtists(loadBlockedArtistIds())

    private suspend fun List<MediaItem>.filterPlaybackContent(
        hideExplicit: Boolean,
        hideVideo: Boolean,
    ): List<MediaItem> =
        filterExplicit(hideExplicit)
            .filterVideo(hideVideo)
            .filterBlockedArtists(loadBlockedArtistIds())

    private suspend fun loadBlockedArtistIds(): Set<String> =
        withContext(Dispatchers.IO) {
            database.getBlockedArtistIds().toSet()
        }

    private fun removeBlockedArtistItems(updatedBlockedArtistIds: Set<String>) {
        if (updatedBlockedArtistIds.isEmpty() || player.mediaItemCount == 0) return

        removeQueueItems { item -> item.hasBlockedArtist(updatedBlockedArtistIds) }
    }

    private fun removeMusicVideoItems() {
        removeQueueItems { item -> item.metadata?.isMusicVideo == true }
    }

    private inline fun removeQueueItems(shouldRemove: (MediaItem) -> Boolean) {
        if (player.mediaItemCount == 0) return

        var blockedRangeEnd = C.INDEX_UNSET
        for (index in player.mediaItemCount - 1 downTo 0) {
            val item = player.getMediaItemAt(index)
            if (shouldRemove(item)) {
                if (blockedRangeEnd == C.INDEX_UNSET) {
                    blockedRangeEnd = index + 1
                }
            } else if (blockedRangeEnd != C.INDEX_UNSET) {
                player.removeMediaItems(index + 1, blockedRangeEnd)
                blockedRangeEnd = C.INDEX_UNSET
            }
        }
        if (blockedRangeEnd != C.INDEX_UNSET) {
            player.removeMediaItems(0, blockedRangeEnd)
        }
        if (player.mediaItemCount == 0) {
            cancelInfiniteQueueBootstrap()
            currentQueue = EmptyQueue
            queueTitle = null
        }
    }

    private suspend fun restorePersistentQueue(persistedQueue: PersistQueue) {
        val hydrationGeneration = withContext(Dispatchers.Main.immediate) {
            cancelRestoredQueueHydration()
            initialQueueJob?.cancel()
            cancelInfiniteQueueBootstrap()
            queuePageJob?.cancel()
            queuePageJob = null
            resetQueueRecommendations()
            isHydratingRestoredQueue = true
            restoredQueueHydrationGeneration.get()
        }
        try {
            val initialStatus = withContext(Dispatchers.IO) {
                persistedQueue.toQueue().getInitialStatus().filterPlaybackContent(
                    dataStore.get(HideExplicitKey, false), dataStore.get(HideVideoKey, false),
                )
            }
            withContext(Dispatchers.Main.immediate) {
                if (hydrationGeneration != restoredQueueHydrationGeneration.get()) return@withContext
                val source = persistedQueue.toContinuationQueue()
                recommendationQueue = persistedQueue.recommendationData?.let { data ->
                    YouTubeQueue(
                        WatchEndpoint(videoId = data.videoId, playlistId = data.playlistId, params = data.endpointParams),
                        followAutomixPreview = data.followAutomixPreview,
                        initialContinuation = data.continuation,
                    )
                } ?: (source as? YouTubeQueue)?.takeIf { it.isRadio }
                currentQueue = if (source.isRadio) EmptyQueue else source
                queueTitle = initialStatus.title
                if (initialStatus.items.isEmpty()) return@withContext
                player.setMediaItems(
                    initialStatus.items,
                    initialStatus.mediaItemIndex.coerceIn(initialStatus.items.indices),
                    initialStatus.position,
                )
                player.prepare()
                player.playWhenReady = false
                currentMediaMetadata.value = player.currentMetadata
                updateNotification()
            }
        } finally {
            withContext(kotlinx.coroutines.NonCancellable + Dispatchers.Main.immediate) {
                if (hydrationGeneration == restoredQueueHydrationGeneration.get()) isHydratingRestoredQueue = false
            }
        }
    }

    private suspend fun restorePersistentPlayerState(
        playerState: PersistPlayerState,
        restoredQueue: Boolean,
    ) {
        withContext(Dispatchers.Main) {
            player.repeatMode = playerState.repeatMode
            player.shuffleModeEnabled = playerState.shuffleModeEnabled
            playerVolume.value = playerState.volume.coerceIn(0f, 1f)

            if (player.mediaItemCount > 0) {
                val index =
                    when {
                        restoredQueue -> {
                            player.currentMediaItemIndex.coerceIn(0, player.mediaItemCount - 1)
                        }

                        playerState.currentMediaItemIndex in 0 until player.mediaItemCount -> {
                            playerState.currentMediaItemIndex
                        }

                        else -> {
                            player.currentMediaItemIndex.coerceIn(0, player.mediaItemCount - 1)
                        }
                    }
                player.seekTo(index, playerState.currentPosition.coerceAtLeast(0L))
            }

            player.playWhenReady = false
            abandonAudioFocus()

            currentMediaMetadata.value = player.currentMetadata.takeIf { player.mediaItemCount > 0 }
            updateNotification()
        }
    }

    private fun ensurePresenceManager() {
        if (currentMediaMetadata.value?.isPodcast == true) {
            requestDiscordSync(reason = "podcast_playback", force = true)
            return
        }
        if (DiscordPresenceManager.isRunning() && lastPresenceToken != null) return

        // Launch in scope to avoid blocking
        scope.launch {
            // Don't start if Discord RPC is disabled in settings
            if (!dataStore.get(EnableDiscordRPCKey, true)) {
                if (DiscordPresenceManager.isRunning()) {
                    Timber.tag("MusicService").d("Discord RPC disabled → stopping presence manager")
                    try {
                        DiscordPresenceManager.stop()
                    } catch (_: Exception) {
                    }
                    lastPresenceToken = null
                }
                return@launch
            }

            val key: String = dataStore.get(DiscordTokenKey, "")
            if (key.isNullOrBlank()) {
                if (DiscordPresenceManager.isRunning()) {
                    Timber.tag("MusicService").d("No Discord OAuth session -> stopping presence manager")
                    try {
                        DiscordPresenceManager.stop()
                    } catch (_: Exception) {
                    }
                    lastPresenceToken = null
                }
                return@launch
            }

            if (DiscordPresenceManager.isRunning() && lastPresenceToken == key) {
                return@launch
            }

            try {
                DiscordPresenceManager.stop()
                DiscordPresenceManager.start(
                    context = this@MusicService,
                    token = key,
                )
                DiscordPresenceManager.setOnTransportInvalidated { reason ->
                    Timber.tag(DISCORD_SYNC_TAG).w(
                        "transport invalidated reason=%s; requesting forced sync",
                        reason,
                    )
                    requestDiscordSync(
                        reason = "transport_invalidated:$reason",
                        force = true,
                    )
                }
                Timber.tag("MusicService").d("Presence manager started")
                lastPresenceToken = key
                requestDiscordSync(
                    reason = "presence_manager_started",
                    force = true,
                )
            } catch (ex: Exception) {
                Timber.tag("MusicService").e(ex, "Failed to start presence manager")
            }
        }
    }

    private fun setupAudioFocusRequest() {
        audioFocusRequest =
            AudioFocusRequest
                .Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(
                    android.media.AudioAttributes
                        .Builder()
                        .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
                        .setContentType(android.media.AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build(),
                ).setOnAudioFocusChangeListener { focusChange ->
                    handleAudioFocusChange(focusChange)
                }.setAcceptsDelayedFocusGain(true)
                .build()
    }

    private fun onAudioOutputDeviceChanged() {
        if (!::player.isInitialized) return
        val outputSignature = currentAudioOutputDeviceSignature()
        if (outputSignature == lastAudioOutputDeviceSignature) return
        lastAudioOutputDeviceSignature = outputSignature
        audioOutputResolver.refresh()
        bitPerfectOutput.refreshDevice()
        updateAudioBecomingNoisyHandling()
        if (bitPerfectOutput.ownsUsbDisconnectHandling) return
        cancelCrossfade(resetVolume = true)
        player.setAudioAttributes(playbackAudioAttributes(), false)
        audioRouteRecoveryJob?.cancel()
        audioRouteRecoveryJob =
            scope.launch {
                delay(AUDIO_ROUTE_CHANGE_DEBOUNCE_MS)
                recoverAudioRouteAfterDeviceChange()
            }
    }

    private suspend fun recoverAudioRouteAfterDeviceChange() {
        if (!::player.isInitialized) return

        rebindAudioEffectsAfterRouteChange()

        if (!shouldRebuildPlaybackForAudioRouteChange()) {
            if (bitPerfectOutput.enabled) reselectAudioSinkOutput()
            return
        }

        val now = android.os.SystemClock.elapsedRealtime()
        if (now - lastAudioRouteRecoveryRealtimeMs < AUDIO_ROUTE_RECOVERY_MIN_INTERVAL_MS) return
        lastAudioRouteRecoveryRealtimeMs = now

        val mediaItemIndex = player.currentMediaItemIndex.takeIf { it != C.INDEX_UNSET } ?: return
        val playbackPosition = player.currentPosition.coerceAtLeast(0L)
        val shouldResumePlayback = player.playWhenReady

        Timber.tag("MusicService").i(
            "Recovering audio route after output change at index=$mediaItemIndex position=$playbackPosition resume=$shouldResumePlayback",
        )

        if (shouldResumePlayback && !requestAudioFocus()) {
            wasPlayingBeforeAudioFocusLoss = true
            player.playWhenReady = false
            return
        }

        player.playWhenReady = false
        player.prepare()
        player.seekTo(mediaItemIndex, playbackPosition)
        delay(AUDIO_ROUTE_RECOVERY_RESUME_DELAY_MS)

        if (
            shouldResumePlayback &&
            player.currentMediaItem != null &&
            player.playbackState != Player.STATE_ENDED &&
            requestAudioFocus()
        ) {
            player.playWhenReady = true
        }
    }

    private suspend fun rebindAudioEffectsAfterRouteChange() {
        if (!isAudioEffectSessionOpened) return
        closeAudioEffectSession()
        if (!player.playWhenReady) return
        delay(AUDIO_EFFECT_ROUTE_REBIND_DELAY_MS)
        openAudioEffectSession()
    }

    private fun updateAudioBecomingNoisyHandling() {
        if (!::localPlaybackPlayer.isInitialized) return
        localPlayer.setHandleAudioBecomingNoisy(!bitPerfectOutput.ownsUsbDisconnectHandling)
    }

    private fun reselectAudioSinkOutput() {
        if (!::localPlaybackPlayer.isInitialized || localPlayer.currentMediaItem == null) return
        val state = localPlayer.playbackState
        if (state == Player.STATE_IDLE || state == Player.STATE_ENDED) return
        localPlayer.seekTo(localPlayer.currentPosition.coerceAtLeast(0L))
    }

    private fun shouldRebuildPlaybackForAudioRouteChange(): Boolean {
        if (player.currentMediaItem == null) return false
        if (player.playbackState == Player.STATE_IDLE || player.playbackState == Player.STATE_ENDED) return false
        return player.playWhenReady || player.playbackState == Player.STATE_BUFFERING
    }

    private fun currentAudioOutputDeviceSignature(): String =
        runCatching {
            audioManager
                .getDevices(AudioManager.GET_DEVICES_OUTPUTS)
                .asSequence()
                .filter { it.isSink }
                .sortedWith(
                    compareBy<AudioDeviceInfo>(
                        { it.type },
                        { it.id },
                        { it.productName?.toString().orEmpty() },
                    ),
                ).joinToString(separator = "|") { device ->
                    "${device.type}:${device.id}:${device.productName?.toString().orEmpty()}"
                }
        }.getOrDefault("")

    private fun playbackAudioAttributes(): AudioAttributes =
        AudioAttributes
            .Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .setAllowedCapturePolicy(C.ALLOW_CAPTURE_BY_ALL)
            .build()

    private fun calculateEffectivePlayerVolume(
        playerVolume: Float,
        normalizeFactor: Float,
        audioFocusVolumeFactor: Float,
    ): Float {
        val safePlayerVolume = playerVolume.takeIf { it.isFinite() }?.coerceIn(0f, 1f) ?: 1f
        val safeNormalizeFactor =
            normalizeFactor.takeIf { it.isFinite() }?.coerceIn(MIN_AUDIO_NORMALIZATION_FACTOR, MAX_AUDIO_NORMALIZATION_FACTOR) ?: 1f
        val safeAudioFocusVolumeFactor =
            audioFocusVolumeFactor.takeIf { it.isFinite() }?.coerceIn(MIN_AUDIO_FOCUS_VOLUME_FACTOR, 1f) ?: 1f
        val safeSleepTimerVolumeFactor = sleepTimerVolumeFactor.value.takeIf { it.isFinite() }?.coerceIn(0f, 1f) ?: 1f
        return if (recapAudioMuted.value) 0f else
            (safePlayerVolume * safeNormalizeFactor * safeAudioFocusVolumeFactor * safeSleepTimerVolumeFactor)
                .coerceIn(0f, maxSafeGainFactor)
    }

    fun setSleepTimerVolumeFactor(factor: Float) {
        val safeFactor = factor.takeIf { it.isFinite() }?.coerceIn(0f, 1f) ?: 1f
        if (sleepTimerVolumeFactor.value == safeFactor) return
        sleepTimerVolumeFactor.value = safeFactor
        if (::player.isInitialized) applyEffectiveVolumeImmediately()
    }

    fun setRecapMuted(muted: Boolean) {
        val nextMuted = muted && recapAudioQueue === currentQueue && recapQueueActive.value
        if (recapAudioMuted.value == nextMuted) return
        recapAudioMuted.value = nextMuted
        if (::player.isInitialized) applyEffectiveVolumeImmediately()
    }

    fun playRecapQueue(queue: ListQueue): Boolean {
        setRecapMuted(false)
        recapAudioQueue = queue
        playQueue(queue)
        if (currentQueue !== queue) {
            recapAudioQueue = null
            recapQueueActive.value = false
            return false
        }
        recapQueueActive.value = true
        return true
    }

    private fun currentEffectivePlayerVolume(): Float =
        calculateEffectivePlayerVolume(playerVolume.value, normalizeFactor.value, audioFocusVolumeFactor.value)

    private fun currentEffectivePlayerVolumeForMediaId(mediaId: String): Float {
        val targetNormalizeFactor =
            if (audioNormalizationEnabled) {
                audioNormalizationFactorCache[mediaId] ?: 1f
            } else {
                1f
            }
        return calculateEffectivePlayerVolume(playerVolume.value, targetNormalizeFactor, audioFocusVolumeFactor.value)
    }

    private fun updateEffectiveVolume(finalVolume: Float) {
        if (!::player.isInitialized || !shouldRampEffectiveVolume(finalVolume)) {
            applyEffectiveVolumeImmediately(finalVolume)
            return
        }

        val startVolume = player.volume.takeIf { it.isFinite() }?.coerceIn(0f, maxSafeGainFactor) ?: finalVolume
        val targetVolume = finalVolume.coerceIn(0f, maxSafeGainFactor)
        if (abs(targetVolume - startVolume) <= EFFECTIVE_VOLUME_RAMP_MIN_DELTA) {
            applyEffectiveVolumeImmediately(targetVolume)
            return
        }

        effectiveVolumeRampJob?.cancel()
        effectiveVolumeRampJob =
            scope.launch {
                val durationMs =
                    if (targetVolume > startVolume) {
                        EFFECTIVE_VOLUME_RAMP_UP_MS
                    } else {
                        EFFECTIVE_VOLUME_RAMP_DOWN_MS
                    }
                val startedAtMs = android.os.SystemClock.elapsedRealtime()
                while (isActive) {
                    val elapsedMs = android.os.SystemClock.elapsedRealtime() - startedAtMs
                    val progress = (elapsedMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f)
                    val easedProgress = progress * progress * (3f - (2f * progress))
                    val interpolatedVolume = startVolume + ((targetVolume - startVolume) * easedProgress)
                    applyEffectiveVolume(interpolatedVolume)
                    if (progress >= 1f) break
                    delay(EFFECTIVE_VOLUME_RAMP_FRAME_MS)
                }
                applyEffectiveVolume(targetVolume)
                effectiveVolumeRampJob = null
            }
    }

    private fun shouldRampEffectiveVolume(finalVolume: Float): Boolean {
        if (crossfadeHandler?.isFading == true) return false
        if (!shouldKeepPlaybackAudible()) return false
        if (!finalVolume.isFinite()) return false
        if (player.volume <= STUCK_MUTED_VOLUME_EPSILON) return false
        return true
    }

    private fun applyEffectiveVolumeImmediately(finalVolume: Float = currentEffectivePlayerVolume()) {
        effectiveVolumeRampJob?.cancel()
        effectiveVolumeRampJob = null
        applyEffectiveVolume(finalVolume)
    }

    private fun applyEffectiveVolume(finalVolume: Float = currentEffectivePlayerVolume()) {
        if (!::player.isInitialized) return
        if (crossfadeHandler?.isFading == true) return
        player.volume = finalVolume
    }

    private fun ensureAudiblePlaybackVolume(reason: String) {
        if (!::player.isInitialized) return
        if (crossfadeHandler?.isFading == true) return
        if (!shouldKeepPlaybackAudible()) return
        if (playerVolume.value <= 0f) return

        val expectedVolume = currentEffectivePlayerVolume()
        if (expectedVolume <= MIN_AUDIBLE_EFFECTIVE_VOLUME) return
        if (player.volume > STUCK_MUTED_VOLUME_EPSILON) return

        Timber.tag(TAG).w(
            "Restoring muted primary player volume during active playback: reason=%s expected=%s actual=%s",
            reason,
            expectedVolume,
            player.volume,
        )
        applyEffectiveVolumeImmediately(expectedVolume)
    }

    private fun updateAudiblePlaybackRecovery() {
        if (!::player.isInitialized || !shouldKeepPlaybackAudible()) {
            audiblePlaybackRecoveryJob?.cancel()
            audiblePlaybackRecoveryJob = null
            return
        }

        if (audiblePlaybackRecoveryJob?.isActive == true) return
        audiblePlaybackRecoveryJob =
            scope.launch {
                while (isActive && shouldKeepPlaybackAudible()) {
                    ensureAudiblePlaybackVolume("watchdog")
                    delay(AUDIBLE_PLAYBACK_VOLUME_CHECK_MS)
                }
                audiblePlaybackRecoveryJob = null
            }
    }

    fun pauseFromSleepTimer() {
        cancelCrossfade(resetVolume = false)
        player.pause()
        player.playWhenReady = false
        localPlayer.pause()
        localPlayer.playWhenReady = false
        sleepTimer.clear()
        applyEffectiveVolumeImmediately()
        updateNotification()
    }

    private fun scheduleCrossfade() {
        if (!::player.isInitialized) return
        crossfadeHandler?.schedule(resolveCrossfadePlan())
    }

    private fun isLocalPlaybackActive(): Boolean =
        ::player.isInitialized && player.deviceInfo.playbackType == androidx.media3.common.DeviceInfo.PLAYBACK_TYPE_LOCAL

    private fun resolveCrossfadePlan(): CrossfadePlan? {
        if (!crossfadeEnabled || crossfadeDurationMs <= 0L) return null
        if (sleepTimer.pauseWhenSongEnd) return null
        if (bitPerfectOutput.status.value.active) return null
        if (!isLocalPlaybackActive()) return null
        if (player.mediaItemCount == 0 || player.currentTimeline.isEmpty) return null
        if (player.playbackState == Player.STATE_IDLE || player.playbackState == Player.STATE_ENDED) return null

        val currentIndex = player.currentMediaItemIndex
        if (currentIndex !in 0 until player.mediaItemCount) return null

        val repeatCurrent = player.repeatMode == REPEAT_MODE_ONE
        val targetIndex = if (repeatCurrent) currentIndex else player.nextMediaItemIndex
        if (targetIndex == C.INDEX_UNSET || targetIndex !in 0 until player.mediaItemCount) return null
        if (!repeatCurrent && targetIndex == currentIndex) return null

        val currentItem = player.getMediaItemAt(currentIndex)
        val targetItem = player.getMediaItemAt(targetIndex)
        if (crossfadeSuppressedMediaId == currentItem.mediaId) return null
        if (currentItem.metadata?.isPodcast == true || targetItem.metadata?.isPodcast == true) return null
        if (!repeatCurrent && crossfadeGapless && isGaplessAlbumTransition(currentItem, targetItem)) return null

        val durationMs = localPlayer.duration.takeIf { it != C.TIME_UNSET && it > 0L } ?: return null
        val triggerPositionMs = CrossfadePlan.triggerPositionMs(durationMs, crossfadeDurationMs) ?: return null
        return CrossfadePlan(
            outgoingMediaId = currentItem.mediaId,
            outgoingIndex = currentIndex,
            incomingMediaId = targetItem.mediaId,
            incomingIndex = targetIndex,
            triggerPositionMs = triggerPositionMs,
            fadeDurationMs = crossfadeDurationMs,
        )
    }

    private fun isGaplessAlbumTransition(
        currentItem: MediaItem,
        targetItem: MediaItem,
    ): Boolean {
        val currentAlbum =
            currentItem.metadata
                ?.album
                ?.id
                ?.takeIf { it.isNotBlank() }
                ?: currentItem.metadata
                    ?.album
                    ?.title
                    ?.takeIf { it.isNotBlank() }
                ?: currentItem.mediaMetadata.albumTitle
                    ?.toString()
                    ?.takeIf { it.isNotBlank() }
        val targetAlbum =
            targetItem.metadata
                ?.album
                ?.id
                ?.takeIf { it.isNotBlank() }
                ?: targetItem.metadata
                    ?.album
                    ?.title
                    ?.takeIf { it.isNotBlank() }
                ?: targetItem.mediaMetadata.albumTitle
                    ?.toString()
                    ?.takeIf { it.isNotBlank() }
        return currentAlbum != null && currentAlbum == targetAlbum
    }

    private fun buildLocalExoPlayer(): ExoPlayer =
        ExoPlayer
            .Builder(this)
            .setMediaSourceFactory(createMediaSourceFactory())
            .setRenderersFactory(createRenderersFactory())
            .setLoadControl(createPrimaryLoadControl())
            .setTrackSelector(DefaultTrackSelector(this, SafeTrackSelectionFactory()))
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .setAudioAttributes(
                playbackAudioAttributes(),
                false,
            ).setSeekBackIncrementMs(5000)
            .setSeekForwardIncrementMs(5000)
            .setDeviceVolumeControlEnabled(true)
            .build()
            .apply {
                setOffloadEnabled(false)
            }

    private fun createCrossfadePlayer(): ExoPlayer {
        val source = localPlayer
        return buildLocalExoPlayer().apply {
            val sessionAudioSessionId = source.audioSessionId
            if (sessionAudioSessionId != C.AUDIO_SESSION_ID_UNSET) {
                setAudioSessionId(sessionAudioSessionId)
            }
            syncCrossfadePlayerConfiguration(this, source)
        }
    }

    private fun syncCrossfadePlayerConfiguration(
        target: ExoPlayer,
        source: ExoPlayer,
    ) {
        target.skipSilenceEnabled = source.skipSilenceEnabled
        target.trackSelectionParameters = source.trackSelectionParameters
        target.setOffloadEnabled(false)
        target.setHandleAudioBecomingNoisy(!bitPerfectOutput.ownsUsbDisconnectHandling)
    }

    private fun activateCrossfadePlayer(
        target: ExoPlayer,
        source: ExoPlayer,
    ) {
        syncCrossfadePlayerConfiguration(target, source)
        target.addAnalyticsListener(PlaybackStatsListener(false, this))
    }

    private fun releaseCrossfadePlayer(retired: ExoPlayer) {
        runCatching { retired.stop() }
        runCatching { retired.release() }
            .onFailure { Timber.tag(TAG).w(it, "Unable to release crossfade player") }
    }

    private fun onCrossfadeFinished() {
        applyEffectiveVolumeImmediately()
        updateAudiblePlaybackRecovery()
        scheduleCrossfade()
    }

    private fun onCrossfadeAbandoned(plan: CrossfadePlan) {
        Timber.tag(TAG).d("Crossfade abandoned for %s", plan.outgoingMediaId)
        crossfadeSuppressedMediaId = plan.outgoingMediaId
        applyEffectiveVolumeImmediately()
    }

    private fun cancelCrossfade(resetVolume: Boolean) {
        crossfadeHandler?.cancel()
        if (resetVolume && ::player.isInitialized) {
            applyEffectiveVolumeImmediately()
        }
    }

    private fun calculateAudioNormalizationFactor(
        format: FormatEntity?,
        normalizeAudio: Boolean,
    ): Float {
        Timber.tag("AudioNormalization").d("Audio normalization enabled: $normalizeAudio")
        Timber
            .tag(
                "AudioNormalization",
            ).d("Format loudnessDb: ${format?.loudnessDb}, perceptualLoudnessDb: ${format?.perceptualLoudnessDb}")

        if (!normalizeAudio) {
            Timber.tag("AudioNormalization").d("Normalization disabled - using factor 1.0")
            return 1f
        }

        val loudnessDb = format?.normalizationLoudnessDb()
        if (loudnessDb == null || !loudnessDb.isFinite()) {
            Timber.tag("AudioNormalization").w("Normalization enabled but no valid loudness data available - no normalization applied")
            return 1f
        }

        val rawFactor = 10f.pow(-loudnessDb / 20)
        val factor =
            if (rawFactor.isFinite()) {
                rawFactor.coerceIn(MIN_AUDIO_NORMALIZATION_FACTOR, MAX_AUDIO_NORMALIZATION_FACTOR)
            } else {
                1f
            }

        if (factor != rawFactor) {
            Timber.tag("AudioNormalization").d("Normalization factor clamped from $rawFactor to $factor")
        }
        Timber.tag("AudioNormalization").i("Applying normalization factor: $factor")
        return factor
    }

    private fun resolveAudioNormalizationFactor(
        mediaId: String?,
        format: FormatEntity?,
        normalizeAudio: Boolean,
    ): Float {
        val currentMediaId = mediaId?.takeIf { it.isNotBlank() } ?: return 1f
        if (!normalizeAudio) {
            return 1f
        }

        if (format?.id == currentMediaId) {
            val factor = calculateAudioNormalizationFactor(format, normalizeAudio = true)
            audioNormalizationFactorCache[currentMediaId] = factor
            return factor
        }

        return audioNormalizationFactorCache[currentMediaId] ?: 1f
    }

    private fun FormatEntity.normalizationLoudnessDb(): Float? =
        sequenceOf(perceptualLoudnessDb, loudnessDb)
            .mapNotNull { it?.toFloat() }
            .firstOrNull { it.isFinite() }

    private fun shouldKeepPlaybackAudible(): Boolean {
        if (!::player.isInitialized) return false
        if (player.currentMediaItem == null || !player.playWhenReady) return false
        return player.playbackState != Player.STATE_IDLE && player.playbackState != Player.STATE_ENDED
    }

    private fun restoreAudioFocusVolume() {
        audioFocusVolumeFactor.value = 1f
        hasAudioFocus = true
        lastAudioFocusState = AudioManager.AUDIOFOCUS_GAIN
    }

    private fun pauseForAudioFocusLoss(resumeWhenFocusReturns: Boolean) {
        audioFocusVolumeFactor.value = 1f
        wasPlayingBeforeAudioFocusLoss = resumeWhenFocusReturns && player.playWhenReady
        if (player.playWhenReady) {
            player.pause()
        }
    }

    private fun ensureAudioFocusForActivePlayback(): Boolean {
        if (!player.playWhenReady) return true
        if (requestAudioFocus()) return true
        pauseForAudioFocusLoss(resumeWhenFocusReturns = true)
        return false
    }

    private fun handleAudioFocusChange(focusChange: Int) {
        when (focusChange) {
            AudioManager.AUDIOFOCUS_GAIN -> {
                hasAudioFocus = true
                audioFocusVolumeFactor.value = 1f

                if (wasPlayingBeforeAudioFocusLoss) {
                    player.play()
                    wasPlayingBeforeAudioFocusLoss = false
                }

                lastAudioFocusState = focusChange
            }

            AudioManager.AUDIOFOCUS_LOSS -> {
                hasAudioFocus = false
                pauseForAudioFocusLoss(resumeWhenFocusReturns = false)

                abandonAudioFocus()

                lastAudioFocusState = focusChange
            }

            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                hasAudioFocus = false
                pauseForAudioFocusLoss(resumeWhenFocusReturns = true)

                lastAudioFocusState = focusChange
            }

            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                hasAudioFocus = false
                pauseForAudioFocusLoss(resumeWhenFocusReturns = true)

                lastAudioFocusState = focusChange
            }

            AudioManager.AUDIOFOCUS_GAIN_TRANSIENT -> {
                hasAudioFocus = true
                audioFocusVolumeFactor.value = 1f

                if (wasPlayingBeforeAudioFocusLoss) {
                    player.play()
                    wasPlayingBeforeAudioFocusLoss = false
                }

                lastAudioFocusState = focusChange
            }

            AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK -> {
                hasAudioFocus = true
                audioFocusVolumeFactor.value = 1f

                lastAudioFocusState = focusChange
            }
        }
    }

    private fun requestAudioFocus(): Boolean {
        if (hasAudioFocus) {
            if (audioFocusVolumeFactor.value != 1f || lastAudioFocusState == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK) {
                restoreAudioFocusVolume()
            }
            return true
        }

        audioFocusRequest?.let { request ->
            val result = audioManager.requestAudioFocus(request)
            hasAudioFocus = result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
            if (hasAudioFocus) {
                restoreAudioFocusVolume()
            }
            return hasAudioFocus
        }
        return false
    }

    private fun abandonAudioFocus() {
        if (hasAudioFocus) {
            audioFocusRequest?.let { request ->
                audioManager.abandonAudioFocusRequest(request)
                hasAudioFocus = false
            }
        }
    }

    fun hasAudioFocusForPlayback(): Boolean = hasAudioFocus

    private fun isDeviceMutedNow(): Boolean {
        val streamVolume =
            runCatching {
                audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
            }.getOrElse { error ->
                reportException(error)
                return player.isDeviceMuted || player.deviceVolume <= 0
            }
        val isStreamMuted =
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                runCatching {
                    audioManager.isStreamMute(AudioManager.STREAM_MUSIC)
                }.getOrElse { error ->
                    reportException(error)
                    false
                }

        return isStreamMuted || streamVolume <= 0
    }

    private fun isTogetherGuestSession(): Boolean {
        val joined = togetherSessionState.value as? moe.rukamori.archivetune.together.TogetherSessionState.Joined
        return joined?.role is moe.rukamori.archivetune.together.TogetherRole.Guest
    }

    private fun registerMuteRecoveryObserver() {
        if (muteRecoveryObserver != null) return
        val observer =
            object : ContentObserver(Handler(mainLooper)) {
                override fun onChange(selfChange: Boolean) {
                    if (audioManager.getStreamVolume(AudioManager.STREAM_MUSIC) > 0) {
                        handleDeviceMuteStateChanged()
                    }
                }
            }
        contentResolver.registerContentObserver(
            android.provider.Settings.System.CONTENT_URI,
            true,
            observer,
        )
        muteRecoveryObserver = observer
    }

    private fun unregisterMuteRecoveryObserver() {
        muteRecoveryObserver?.let { contentResolver.unregisterContentObserver(it) }
        muteRecoveryObserver = null
    }

    private fun handleDeviceMuteStateChanged(playbackRequestedWhileMuted: Boolean = false) {
        if (!pauseOnDeviceMuteEnabled || isTogetherGuestSession()) {
            wasAutoPausedByDeviceMute = false
            unregisterMuteRecoveryObserver()
            return
        }

        if (isDeviceMutedNow()) {
            if (playbackRequestedWhileMuted && restoreDeviceMusicVolumeForPlayback()) {
                wasAutoPausedByDeviceMute = false
                unregisterMuteRecoveryObserver()
                return
            }

            val canPauseNow =
                player.currentMediaItem != null &&
                    player.playWhenReady &&
                    player.playbackState != Player.STATE_IDLE &&
                    player.playbackState != Player.STATE_ENDED

            if (canPauseNow) {
                player.pause()
                wasAutoPausedByDeviceMute = true
                registerMuteRecoveryObserver()
                if (playbackRequestedWhileMuted) {
                    showDeviceMutePlaybackNotice()
                }
            }
            return
        }

        unregisterMuteRecoveryObserver()

        if (!wasAutoPausedByDeviceMute) return

        wasAutoPausedByDeviceMute = false
        val canResumeNow =
            player.currentMediaItem != null &&
                player.playbackState != Player.STATE_IDLE &&
                player.playbackState != Player.STATE_ENDED
        if (canResumeNow) {
            player.play()
        }
    }

    private fun restoreDeviceMusicVolumeForPlayback(): Boolean {
        val recoveryPercent = deviceMutePlaybackRecoveryVolumePercent.coerceIn(0, 100)
        if (recoveryPercent <= 0) return false

        val maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        if (maxVolume <= 0) return false

        val targetVolume =
            ceil(maxVolume * (recoveryPercent / 100.0))
                .toInt()
                .coerceIn(1, maxVolume)

        return runCatching {
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, targetVolume, 0)
            audioManager.getStreamVolume(AudioManager.STREAM_MUSIC) > 0
        }.getOrElse {
            reportException(it)
            false
        }
    }

    private fun showDeviceMutePlaybackNotice() {
        val now = android.os.SystemClock.elapsedRealtime()
        if (now - lastDeviceMutePlaybackNoticeAtElapsedMs < DEVICE_MUTE_PLAYBACK_NOTICE_INTERVAL_MS) return
        lastDeviceMutePlaybackNoticeAtElapsedMs = now
        scope.launch(SilentHandler) {
            Toast
                .makeText(
                    this@MusicService,
                    R.string.device_volume_zero_playback_paused,
                    Toast.LENGTH_SHORT,
                ).show()
        }
    }

    private val bluetoothReceiver =
        object : BroadcastReceiver() {
            override fun onReceive(
                context: Context,
                intent: Intent,
            ) {
                if (intent.action != BluetoothDevice.ACTION_ACL_CONNECTED) return
                if (!autoStartOnBluetoothEnabled) return

                val device = intent.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE) ?: return

                val isAudioDevice =
                    try {
                        val majorClass = device.bluetoothClass?.majorDeviceClass
                        majorClass == BluetoothClass.Device.Major.AUDIO_VIDEO ||
                            majorClass == BluetoothClass.Device.Major.WEARABLE
                    } catch (_: SecurityException) {
                        true
                    }

                if (!isAudioDevice) return

                scope.launch {
                    delay(1500)
                    handleBluetoothAutoStart()
                }
            }
        }

    private fun handleBluetoothAutoStart() {
        if (isTogetherGuestSession()) return

        if (player.currentMediaItem != null &&
            player.playbackState != Player.STATE_IDLE &&
            player.playbackState != Player.STATE_ENDED
        ) {
            if (!player.playWhenReady) {
                player.play()
            }
            return
        }

        if (player.mediaItemCount > 0) {
            player.prepare()
            player.play()
        }
    }

    @Suppress("DEPRECATION")
    private fun registerBluetoothReceiver() {
        if (bluetoothReceiverRegistered) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            checkSelfPermission(android.Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }

        val filter = IntentFilter(BluetoothDevice.ACTION_ACL_CONNECTED)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(bluetoothReceiver, filter, RECEIVER_EXPORTED)
        } else {
            registerReceiver(bluetoothReceiver, filter)
        }
        bluetoothReceiverRegistered = true
    }

    private fun unregisterBluetoothReceiver() {
        if (!bluetoothReceiverRegistered) return
        try {
            unregisterReceiver(bluetoothReceiver)
        } catch (_: Exception) {
        }
        bluetoothReceiverRegistered = false
    }

    private fun waitOnNetworkError() {
        waitingForNetworkConnection.value = true
    }

    private fun skipOnError() {
        /**
         * Auto skip to the next media item on error.
         *
         * To prevent a "runaway diesel engine" scenario, force the user to take action after
         * too many errors come up too quickly. Pause to show player "stopped" state
         */
        consecutivePlaybackErr += 2
        val nextWindowIndex = player.nextMediaItemIndex

        if (consecutivePlaybackErr <= MAX_CONSECUTIVE_ERR && nextWindowIndex != C.INDEX_UNSET) {
            player.seekTo(nextWindowIndex, C.TIME_UNSET)
            player.prepare()
            player.play()
            return
        }

        player.pause()
        consecutivePlaybackErr = 0
    }

    private fun stopOnError() {
        player.pause()
    }

    private fun findStreamHttpFailure(
        error: PlaybackException,
    ): androidx.media3.datasource.HttpDataSource.InvalidResponseCodeException? {
        var throwable: Throwable? = error.cause
        while (throwable != null) {
            if (throwable is androidx.media3.datasource.HttpDataSource.InvalidResponseCodeException) {
                return throwable
            }
            throwable = throwable.cause
        }
        return null
    }

    private fun isRetryableRemoteParserFailure(error: PlaybackException): Boolean {
        if (
            error.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED ||
            error.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED
        ) {
            return true
        }

        var throwable: Throwable? = error.cause
        while (throwable != null) {
            if (
                throwable.message?.contains("Skipping atom with length", ignoreCase = true) == true ||
                    throwable.isMedia3ExtractorBoundsFailure()
            ) {
                return true
            }
            throwable = throwable.cause
        }
        return false
    }

    private fun isCacheCorruptionError(
        error: PlaybackException,
        isContentCached: Boolean,
    ): Boolean {
        val isContainerParseError =
            error.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED ||
                error.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED
        if (error.errorCode == PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND ||
            (isContentCached && error.errorCode == PlaybackException.ERROR_CODE_IO_READ_POSITION_OUT_OF_RANGE)
        ) {
            return true
        }

        var throwable: Throwable? = error.cause
        while (throwable != null) {
            when {
                throwable is EOFException || throwable is Cache.CacheException -> {
                    return true
                }

                throwable is IOException &&
                    throwable.message?.contains("unexpected end of stream", ignoreCase = true) == true -> {
                    return true
                }

                throwable is IllegalStateException || throwable is IllegalArgumentException -> {
                    if (throwable.stackTrace.any { it.className.startsWith("androidx.media3.extractor") }) {
                        return true
                    }
                }

                isContentCached && throwable.isMedia3ExtractorBoundsFailure() -> {
                    return true
                }

                isContainerParseError && isContentCached && throwable is ParserException -> {
                    return true
                }

                isContainerParseError && isContentCached &&
                    throwable.message?.let {
                        it.contains("Invalid integer size", ignoreCase = true) ||
                            it.contains("Skipping atom with length", ignoreCase = true) ||
                            it.contains("contentIsMalformed=true", ignoreCase = true)
                    } == true -> {
                    return true
                }
            }
            throwable = throwable.cause
        }
        return false
    }

    private fun Throwable.isMedia3ExtractorBoundsFailure(): Boolean =
        this is ArrayIndexOutOfBoundsException &&
            stackTrace.any { it.className.startsWith("androidx.media3.extractor") }

    private fun retryPlaybackAfterStreamFailure(
        mediaId: String,
        isFullyDownloadedMedia: Boolean,
        responseException: androidx.media3.datasource.HttpDataSource.InvalidResponseCodeException,
    ): Boolean {
        if (isFullyDownloadedMedia) return false

        val recoverySnapshot = capturePlaybackRecoverySnapshot()

        val failedUrl = responseException.dataSpec.uri.toString()
        val requestProfile = StreamClientUtils.resolveRequestProfile(failedUrl)
        val failedExpiredUrl = YTPlayerUtils.isExpiredOrNearExpiredStreamUrl(failedUrl)

        resolveAudioStream.invalidate(mediaId)
        YTPlayerUtils.invalidateCachedStreamUrls(mediaId)
        if (!failedExpiredUrl && requestProfile.clientKey.isNotEmpty()) {
            YTPlayerUtils.markStreamClientFailed(mediaId, requestProfile.clientKey, responseException.responseCode)
        }

        if (!playbackStreamRecoveryTracker.registerRetryAttempt(mediaId)) {
            return false
        }

        if (responseException.responseCode == 403) {
            resolveAudioStream.invalidateSession()
        }

        Timber.tag("MusicService").i(
            "Retrying playback for %s after stream HTTP %d from %s failed",
            mediaId,
            responseException.responseCode,
            requestProfile.variantLabel,
        )
        return preparePlaybackFromSnapshot(recoverySnapshot)
    }

    private fun retryPlaybackAfterNetworkFailure(
        mediaId: String,
        isFullyDownloadedMedia: Boolean,
    ): Boolean {
        if (isFullyDownloadedMedia) return false

        val recoverySnapshot = capturePlaybackRecoverySnapshot()

        resolveAudioStream.invalidate(mediaId)
        YTPlayerUtils.invalidateCachedStreamUrls(mediaId)

        if (!playbackStreamRecoveryTracker.registerRetryAttempt(mediaId)) {
            return false
        }

        Timber.tag("MusicService").i("Retrying playback for %s after a transient network failure", mediaId)
        return preparePlaybackFromSnapshot(recoverySnapshot)
    }

    private fun capturePlaybackRecoverySnapshot(): PlaybackRecoverySnapshot? {
        val mediaItem = player.currentMediaItem ?: return null
        val mediaItemIndex = player.currentMediaItemIndex
        if (mediaItemIndex == C.INDEX_UNSET) return null

        val duration = player.duration
        val positionMs =
            player.currentPosition
                .coerceAtLeast(0L)
                .let { position ->
                    if (duration > 0L && duration != C.TIME_UNSET) {
                        position.coerceAtMost(duration)
                    } else {
                        position
                    }
                }

        return PlaybackRecoverySnapshot(
            mediaId = mediaItem.mediaId,
            positionMs = positionMs,
            playWhenReady = player.playWhenReady,
        )
    }

    private fun preparePlaybackFromSnapshot(snapshot: PlaybackRecoverySnapshot?): Boolean {
        if (snapshot == null) {
            player.prepare()
            return true
        }
        if (player.currentMediaItem?.mediaId != snapshot.mediaId) return false

        val currentIndex = player.currentMediaItemIndex
        val targetIndex =
            if (currentIndex in 0 until player.mediaItemCount &&
                player.getMediaItemAt(currentIndex).mediaId == snapshot.mediaId
            ) {
                currentIndex
            } else {
                (0 until player.mediaItemCount)
                    .firstOrNull { index -> player.getMediaItemAt(index).mediaId == snapshot.mediaId }
                    ?: return false
            }
        player.seekTo(targetIndex, snapshot.positionMs)
        player.prepare()
        player.playWhenReady = snapshot.playWhenReady
        return true
    }

    private fun updateNotification() {
        try {
            mediaSession.setMediaButtonPreferences(buildNotificationButtons(notificationConfiguration))
            updateAndroidAutoButtons()
        } catch (e: Exception) {
            reportException(e)
        }
    }

    private fun buildNotificationButtons(configuration: MediaNotificationConfiguration): List<CommandButton> {
        val navigationButtons =
            if (configuration.navigation == MediaNotificationNavigation.SEEK) {
                listOf(
                    seekNotificationButton(forward = false, seconds = configuration.seekIncrementSeconds),
                    seekNotificationButton(forward = true, seconds = configuration.seekIncrementSeconds),
                )
            } else {
                emptyList()
            }
        return navigationButtons + configuration.actions.map { action -> notificationActionButton(action, configuration) }
    }

    private fun seekNotificationButton(
        forward: Boolean,
        seconds: Int,
    ): CommandButton =
        CommandButton
            .Builder(
                if (forward) {
                    when (seconds) {
                        5 -> CommandButton.ICON_SKIP_FORWARD_5
                        10 -> CommandButton.ICON_SKIP_FORWARD_10
                        15 -> CommandButton.ICON_SKIP_FORWARD_15
                        30 -> CommandButton.ICON_SKIP_FORWARD_30
                        else -> CommandButton.ICON_SKIP_FORWARD
                    }
                } else {
                    when (seconds) {
                        5 -> CommandButton.ICON_SKIP_BACK_5
                        10 -> CommandButton.ICON_SKIP_BACK_10
                        15 -> CommandButton.ICON_SKIP_BACK_15
                        30 -> CommandButton.ICON_SKIP_BACK_30
                        else -> CommandButton.ICON_SKIP_BACK
                    }
                },
            ).setDisplayName(
                resources.getQuantityString(
                    if (forward) R.plurals.media_notification_seek_forward else R.plurals.media_notification_seek_back,
                    seconds,
                    seconds,
                ),
            ).setCustomIconResId(if (forward) R.drawable.seek_forward else R.drawable.replay)
            .setSessionCommand(if (forward) CommandSeekForwardIncrement else CommandSeekBackIncrement)
            .setSlots(if (forward) CommandButton.SLOT_FORWARD else CommandButton.SLOT_BACK)
            .setEnabled(player.currentMediaItem != null)
            .build()

    private fun notificationActionButton(
        action: MediaNotificationAction,
        configuration: MediaNotificationConfiguration,
    ): CommandButton {
        val song = currentSong.value
        val mediaMetadata = currentMediaMetadata.value
        return when (action) {
            MediaNotificationAction.LIKE -> {
                val liked = song?.song?.liked == true
                customNotificationButton(
                    displayName = getString(if (liked) R.string.action_remove_like else R.string.action_like),
                    iconResId = if (liked) R.drawable.favorite else R.drawable.favorite_border,
                    command = CommandToggleLike,
                    enabled = song != null,
                )
            }

            MediaNotificationAction.REPEAT ->
                customNotificationButton(
                    displayName =
                        getString(
                            when (player.repeatMode) {
                                REPEAT_MODE_ONE -> R.string.repeat_mode_one
                                REPEAT_MODE_ALL -> R.string.repeat_mode_all
                                else -> R.string.repeat_mode_off
                            },
                        ),
                    iconResId =
                        when (player.repeatMode) {
                            REPEAT_MODE_ONE -> R.drawable.repeat_one_on
                            REPEAT_MODE_ALL -> R.drawable.repeat_on
                            else -> R.drawable.repeat
                        },
                    command = CommandToggleRepeatMode,
                )

            MediaNotificationAction.SHUFFLE ->
                customNotificationButton(
                    displayName = getString(if (player.shuffleModeEnabled) R.string.action_shuffle_off else R.string.action_shuffle_on),
                    iconResId = if (player.shuffleModeEnabled) R.drawable.shuffle_on else R.drawable.shuffle,
                    command = CommandToggleShuffle,
                )

            MediaNotificationAction.START_RADIO ->
                customNotificationButton(
                    displayName = getString(R.string.start_radio),
                    iconResId = R.drawable.radio,
                    command = CommandToggleStartRadio,
                    enabled = song != null && mediaMetadata?.isPodcast != true,
                )

            MediaNotificationAction.LIBRARY -> {
                val inLibrary = song?.song?.inLibrary != null
                customNotificationButton(
                    displayName = getString(if (inLibrary) R.string.remove_from_library else R.string.add_to_library),
                    iconResId = if (inLibrary) R.drawable.library_add_check else R.drawable.library_add,
                    command = CommandToggleLibrary,
                    enabled = song != null,
                )
            }

            MediaNotificationAction.DOWNLOAD -> {
                val downloadState = currentDownloadState
                customNotificationButton(
                    displayName =
                        getString(
                            when (downloadState) {
                                Download.STATE_COMPLETED -> R.string.remove_download
                                Download.STATE_QUEUED, Download.STATE_DOWNLOADING, Download.STATE_RESTARTING -> R.string.downloading
                                else -> R.string.action_download
                            },
                        ),
                    iconResId = if (downloadState == Download.STATE_COMPLETED) R.drawable.offline else R.drawable.download,
                    command = CommandToggleDownload,
                    enabled = canDownloadFromNotification(mediaMetadata, song) && downloadState != Download.STATE_REMOVING,
                )
            }

            MediaNotificationAction.SLEEP_TIMER -> {
                val active = ::sleepTimer.isInitialized && sleepTimer.isActive
                customNotificationButton(
                    displayName =
                        if (active) {
                            getString(R.string.media_notification_sleep_timer_cancel)
                        } else {
                            getString(
                                R.string.media_notification_sleep_timer_start,
                                resources.getQuantityString(
                                    R.plurals.minute,
                                    configuration.sleepTimerMinutes,
                                    configuration.sleepTimerMinutes,
                                ),
                            )
                        },
                    iconResId = if (active) R.drawable.bedtime else R.drawable.timer,
                    command = CommandToggleSleepTimer,
                    enabled = active || mediaMetadata != null,
                )
            }

            MediaNotificationAction.CLOSE ->
                customNotificationButton(
                    displayName = getString(R.string.close),
                    iconResId = R.drawable.close,
                    command = CommandClosePlayback,
                    enabled = mediaMetadata != null && isTogetherSessionIdle(),
                )
        }
    }

    private fun customNotificationButton(
        displayName: String,
        @DrawableRes iconResId: Int,
        command: SessionCommand,
        enabled: Boolean = true,
    ): CommandButton =
        CommandButton
            .Builder(CommandButton.ICON_UNDEFINED)
            .setDisplayName(displayName)
            .setCustomIconResId(iconResId)
            .setSessionCommand(command)
            .setEnabled(enabled)
            .build()

    private fun canDownloadFromNotification(
        mediaMetadata: moe.rukamori.archivetune.models.MediaMetadata?,
        song: Song?,
    ): Boolean = mediaMetadata != null && !mediaMetadata.id.isLocalMediaId() && song?.song?.isLocal != true

    private fun isTogetherSessionIdle(): Boolean =
        togetherSessionState.value is moe.rukamori.archivetune.together.TogetherSessionState.Idle

    private fun toggleCurrentDownload() {
        val mediaMetadata = currentMediaMetadata.value ?: return
        if (!canDownloadFromNotification(mediaMetadata, currentSong.value)) return
        when (moduleDownloadUtil.downloads.value[mediaMetadata.id]?.state) {
            Download.STATE_COMPLETED,
            Download.STATE_QUEUED,
            Download.STATE_DOWNLOADING,
            Download.STATE_RESTARTING,
            -> DownloadService.sendRemoveDownload(this, ExoDownloadService::class.java, mediaMetadata.id, false)

            Download.STATE_REMOVING -> Unit

            else ->
                ioScope.launch {
                    try {
                        database.withTransaction { insert(mediaMetadata) }
                        val downloadRequest =
                            androidx.media3.exoplayer.offline.DownloadRequest
                                .Builder(mediaMetadata.id, mediaMetadata.id.toUri())
                                .setCustomCacheKey(mediaMetadata.id)
                                .setData(mediaMetadata.title.toByteArray())
                                .build()
                        DownloadService.sendAddDownload(
                            this@MusicService,
                            ExoDownloadService::class.java,
                            downloadRequest,
                            false,
                        )
                    } catch (error: CancellationException) {
                        throw error
                    } catch (error: Exception) {
                        reportException(error)
                    }
                }
        }
    }

    private fun toggleSleepTimerFromNotification() {
        if (!::sleepTimer.isInitialized) return
        if (sleepTimer.isActive) {
            sleepTimer.clear()
        } else {
            if (currentMediaMetadata.value == null) return
            sleepTimer.start(
                minutes = notificationConfiguration.sleepTimerMinutes,
                finishCurrentSong = dataStore.get(SleepTimerFinishSongKey, false),
                fadeOut = dataStore.get(SleepTimerFadeOutKey, true),
            )
        }
        updateNotification()
    }

    private fun seekByNotificationIncrement(forward: Boolean) {
        if (player.currentMediaItem == null || !player.isCurrentMediaItemSeekable) return
        val incrementMs = notificationConfiguration.seekIncrementMs
        val duration = player.duration
        val target =
            if (forward) {
                val next = player.currentPosition + incrementMs
                if (duration != C.TIME_UNSET && duration > 0L) next.coerceAtMost(duration) else next
            } else {
                (player.currentPosition - incrementMs).coerceAtLeast(0L)
            }
        player.seekTo(target)
    }

    private fun closePlaybackFromNotification() {
        if (!isTogetherSessionIdle()) return
        scope.launch {
            if (dataStore.getAsync(PersistentQueueKey, true) && player.mediaItemCount > 0) {
                saveQueueToDisk()
            }
            if (::sleepTimer.isInitialized) sleepTimer.clear()
            stopAndClearPlayback(clearPersistentState = false)
            requestDiscordSync(
                reason = "media_notification_closed",
                force = true,
            )
            stopForegroundAndSelf()
        }
    }

    private fun updateAndroidAutoButtons(
        configuration: AndroidAutoConfiguration = androidAutoSettings.currentConfiguration(),
    ) {
        val buttons = buildAndroidAutoButtons(configuration)
        mediaSession.connectedControllers
            .filter { mediaLibrarySessionCallback.isCarController(mediaSession, it) }
            .forEach { controller ->
                mediaSession.setMediaButtonPreferences(controller, buttons)
                mediaSession.setCustomLayout(controller, buttons)
            }
    }

    private fun buildAndroidAutoButtons(configuration: AndroidAutoConfiguration): List<CommandButton> =
        listOf(configuration.primaryAction, configuration.secondaryAction)
            .filter { it != AndroidAutoCustomAction.NONE }
            .distinct()
            .map { action ->
                when (action) {
                    AndroidAutoCustomAction.LIKE -> CommandButton.Builder()
                        .setDisplayName(
                            getString(if (currentSong.value?.song?.liked == true) R.string.action_remove_like else R.string.action_like),
                        )
                        .setIconResId(
                            if (currentSong.value?.song?.liked == true) R.drawable.favorite else R.drawable.favorite_border,
                        )
                        .setSessionCommand(CommandToggleLike)
                        .setEnabled(currentSong.value != null)
                        .build()
                    AndroidAutoCustomAction.START_RADIO -> CommandButton.Builder()
                        .setDisplayName(getString(R.string.start_radio))
                        .setIconResId(R.drawable.radio)
                        .setSessionCommand(CommandToggleStartRadio)
                        .setEnabled(currentSong.value != null && currentMediaMetadata.value?.isPodcast != true)
                        .build()
                    AndroidAutoCustomAction.SHUFFLE -> CommandButton.Builder()
                        .setDisplayName(
                            getString(if (player.shuffleModeEnabled) R.string.action_shuffle_off else R.string.action_shuffle_on),
                        )
                        .setIconResId(if (player.shuffleModeEnabled) R.drawable.shuffle_on else R.drawable.shuffle)
                        .setSessionCommand(CommandToggleShuffle)
                        .build()
                    AndroidAutoCustomAction.REPEAT -> CommandButton.Builder()
                        .setDisplayName(
                            getString(
                                when (player.repeatMode) {
                                    REPEAT_MODE_ONE -> R.string.repeat_mode_one
                                    REPEAT_MODE_ALL -> R.string.repeat_mode_all
                                    else -> R.string.repeat_mode_off
                                },
                            ),
                        )
                        .setIconResId(
                            when (player.repeatMode) {
                                REPEAT_MODE_ONE -> R.drawable.repeat_one_on
                                REPEAT_MODE_ALL -> R.drawable.repeat_on
                                else -> R.drawable.repeat
                            },
                        )
                        .setSessionCommand(CommandToggleRepeatMode)
                        .build()
                    AndroidAutoCustomAction.NONE -> error("None is not a media button")
                }
            }

    private suspend fun recoverSong(
        mediaId: String,
        playbackData: YTPlayerUtils.PlaybackData? = null,
    ) {
        val song = database.song(mediaId).first()
        val mediaMetadata =
            withContext(Dispatchers.Main) {
                player.findNextMediaItemById(mediaId)?.metadata
            } ?: return
        val duration =
            song?.song?.duration?.takeIf { it != -1 }
                ?: mediaMetadata.duration.takeIf { it != -1 }
                ?: (
                    playbackData?.videoDetails ?: YTPlayerUtils
                        .playerResponseForMetadata(mediaId)
                        .getOrNull()
                        ?.videoDetails
                )?.lengthSeconds?.toInt()
                ?: -1
        database.query {
            if (song == null) {
                insert(mediaMetadata.copy(duration = duration))
            } else if (song.song.duration == -1) {
                update(song.song.copy(duration = duration))
            }
        }
        if (mediaMetadata.isPodcast) return
        if (!database.hasRelatedSongs(mediaId)) {
            val relatedEndpoint =
                YouTube.next(WatchEndpoint(videoId = mediaId)).getOrNull()?.relatedEndpoint
                    ?: return
            val relatedPage = YouTube.related(relatedEndpoint).getOrNull() ?: return
            database.query {
                relatedPage.songs
                    .map(SongItem::toMediaMetadata)
                    .onEach(::insert)
                    .map {
                        RelatedSongMap(
                            songId = mediaId,
                            relatedSongId = it.id,
                        )
                    }.forEach(::insert)
            }
        }
    }

    fun playQueue(
        queue: Queue,
        playWhenReady: Boolean = true,
    ) {
        val joined = togetherSessionState.value as? moe.rukamori.archivetune.together.TogetherSessionState.Joined
        if (!isTogetherApplyingRemote() && joined?.role is moe.rukamori.archivetune.together.TogetherRole.Guest) {
            if (!joined.roomState.settings.allowGuestsToControlPlayback) {
                showTogetherNotice(getString(R.string.not_allowed), key = "GUEST_PLAYQUEUE_DISABLED")
                return
            }
            ensureScopesActive()
            scope.launch(SilentHandler) {
                val initialStatus = try {
                    withContext(Dispatchers.IO) {
                        queue
                            .getInitialStatus()
                            .filterPlaybackContent(
                                hideExplicit = dataStore.get(HideExplicitKey, false),
                                hideVideo = dataStore.get(HideVideoKey, false),
                            )
                    }
                } catch (error: CancellationException) {
                    throw error
                } catch (error: Exception) {
                    Timber.e(error, "Failed to load requested queue")
                    Toast.makeText(this@MusicService, R.string.queue_action_failed, Toast.LENGTH_SHORT).show()
                    return@launch
                }

                val targetItem =
                    initialStatus.items.getOrNull(initialStatus.mediaItemIndex)
                        ?: queue.preloadItem
                            ?.toMediaItem()
                            ?.takeUnless { item ->
                                item.hasBlockedArtist(loadBlockedArtistIds())
                            }

                val meta = targetItem?.metadata
                val trackId =
                    meta?.id?.trim().orEmpty().ifBlank {
                        targetItem?.mediaId?.trim().orEmpty()
                    }
                if (trackId.isBlank()) {
                    showTogetherNotice(getString(R.string.not_allowed), key = "GUEST_PLAYQUEUE_NO_TRACK")
                    return@launch
                }

                val track =
                    moe.rukamori.archivetune.together.TogetherTrack(
                        id = trackId,
                        title = meta?.title ?: trackId,
                        artists = meta?.artists?.map { it.name }.orEmpty(),
                        durationSec = meta?.duration ?: -1,
                        thumbnailUrl = meta?.thumbnailUrl,
                    )

                val ops =
                    moe.rukamori.archivetune.together.TogetherGuestPlaybackPlanner.planPlayTrackNow(
                        roomState = joined.roomState,
                        track = track,
                        positionMs = initialStatus.position,
                        playWhenReady = playWhenReady,
                    )

                if (ops.isEmpty()) {
                    showTogetherNotice(getString(R.string.not_allowed), key = "GUEST_PLAYQUEUE_BLOCKED")
                    return@launch
                }

                showTogetherNotice(getString(R.string.together_requesting_song_change), key = "GUEST_PLAYQUEUE_REQUEST")
                ops.forEach { op ->
                    when (op) {
                        is moe.rukamori.archivetune.together.TogetherGuestOp.Control -> requestTogetherControl(op.action)
                        is moe.rukamori.archivetune.together.TogetherGuestOp.AddTrack -> requestTogetherAddTrack(op.track, op.mode)
                    }
                }
            }
            return
        }
        if (playWhenReady) {
            cancelIdleStop()
            ensureForegroundPlaybackService()
        }
        cancelRestoredQueueHydration()
        ensureScopesActive()
        cancelCrossfade(resetVolume = true)
        cancelInfiniteQueueBootstrap()
        suppressAutoPlayback = false
        initialQueueJob?.cancel()
        queuePageJob?.cancel()
        queuePageJob = null
        currentQueue = queue
        queueTitle = null
        val permanentShuffle = dataStore.get(PermanentShuffleKey, false) && queue !== recapAudioQueue
        if (!permanentShuffle) {
            player.shuffleModeEnabled = false
        }

        clearAutomix()
        initialQueueJob = scope.launch(SilentHandler) {
            val hideExplicit = dataStore.get(HideExplicitKey, false)
            val hideVideo = dataStore.get(HideVideoKey, false)
            val autoLoadMoreEnabled = dataStore.get(AutoLoadMoreKey, true)
            val preloadItem =
                queue.preloadItem
                    ?.toMediaItem()?.withQueueEntry(recommended = false)
                    ?.takeUnless { item ->
                        item.hasBlockedArtist(loadBlockedArtistIds())
                    }
            if (preloadItem != null) {
                player.setMediaItem(preloadItem)
                player.prepare()
                player.playWhenReady = playWhenReady
            }
            var initialStatus = try {
                withContext(Dispatchers.IO) {
                    queue
                        .getInitialStatus()
                        .filterPlaybackContent(hideExplicit, hideVideo)
                }
            } catch (error: CancellationException) {
                throw error
            } catch (error: Exception) {
                Timber.e(error, "Failed to load playback queue")
                if (currentQueue === queue) {
                    currentQueue = EmptyQueue
                    initialQueueJob = null
                    Toast.makeText(this@MusicService, R.string.queue_action_failed, Toast.LENGTH_SHORT).show()
                }
                return@launch
            }
            if (!autoLoadMoreEnabled && queue.shouldExpandToFullQueueWhenAutoLoadMoreDisabled() && queue.hasNextPage()) {
                val expandedItems = initialStatus.items.toMutableList()
                var pagesLoaded = 0
                while (queue.hasNextPage() && pagesLoaded < 200) {
                    pagesLoaded++
                    val nextItems =
                        withContext(Dispatchers.IO) {
                            queue
                                .nextPage()
                                .filterPlaybackContent(hideExplicit, hideVideo)
                        }
                    if (nextItems.isNotEmpty()) {
                        expandedItems += nextItems
                    }
                }
                initialStatus = initialStatus.copy(items = expandedItems)
            }
            if (currentQueue !== queue) return@launch
            if (queue is YouTubeQueue && queue.isRadio) {
                recommendationQueue = queue
                queueRecommendations.value = QueueRecommendations(chips = queue.chips)
                currentQueue = EmptyQueue
            }
            initialStatus = initialStatus.copy(items = initialStatus.items.map {
                it.withQueueEntry(recommended = queue.isRadio, id = java.util.UUID.randomUUID().toString())
            })
            if (initialStatus.title != null) {
                queueTitle = initialStatus.title
            }
            if (initialStatus.items.isEmpty() && preloadItem == null) {
                currentQueue = EmptyQueue
                queueTitle = null
                initialQueueJob = null
                player.clearMediaItems()
                return@launch
            }
            if (preloadItem != null) {
                val preloadMediaId = preloadItem.mediaId.trim()
                val insertionIndex =
                    initialStatus.mediaItemIndex.coerceIn(0, initialStatus.items.size)
                val itemsBeforeCurrent =
                    initialStatus.items
                        .subList(0, insertionIndex)
                        .filterNot { preloadMediaId.isNotEmpty() && it.mediaId.trim() == preloadMediaId }
                val itemsAfterCurrent =
                    initialStatus.items
                        .subList(insertionIndex, initialStatus.items.size)
                        .filterNot { preloadMediaId.isNotEmpty() && it.mediaId.trim() == preloadMediaId }

                player.addMediaItems(0, itemsBeforeCurrent)
                player.addMediaItems(itemsAfterCurrent)
                if (player.shuffleModeEnabled) {
                    applyCurrentFirstShuffleOrder()
                }
            } else {
                val items = initialStatus.items
                val index = initialStatus.mediaItemIndex

                player.setMediaItems(items, index, initialStatus.position)
                player.prepare()
                player.playWhenReady = playWhenReady
                if (player.shuffleModeEnabled) {
                    applyCurrentFirstShuffleOrder()
                }
            }

            initialQueueJob = null
            if (
                autoLoadMoreEnabled &&
                player.currentMetadata?.isPodcast != true &&
                !queue.recommendationOnlyContinuation &&
                queue.hasNextPage() &&
                player.mediaItemCount - player.getCurrentQueueIndex() <= 5
            ) {
                extendExplicitQueue()
            }
            if (
                autoLoadMoreEnabled &&
                player.currentMetadata?.isPodcast != true &&
                !queue.hasNextPage() &&
                player.mediaItemCount - player.currentMediaItemIndex <= 3
            ) {
                onInfiniteQueueEnabled()
            }
        }
    }

    private fun applyCurrentFirstShuffleOrder() {
        val count = player.mediaItemCount
        if (count <= 1) return
        val currentIndex = player.currentMediaItemIndex.coerceIn(0, count - 1)
        val shuffledIndices = IntArray(count) { it }
        shuffledIndices.shuffle()
        val currentPos = shuffledIndices.indexOf(currentIndex)
        if (currentPos >= 0) {
            shuffledIndices[currentPos] = shuffledIndices[0]
        }
        shuffledIndices[0] = currentIndex
        localPlayer.setShuffleOrder(DefaultShuffleOrder(shuffledIndices, System.currentTimeMillis()))
    }

    private fun buildPlayNextShuffleOrder(
        currentIndex: Int,
        insertionIndex: Int,
        insertionCount: Int,
    ): DefaultShuffleOrder? {
        if (insertionCount <= 0 || player.currentTimeline.isEmpty) return null

        fun adjustedIndex(index: Int): Int =
            if (index >= insertionIndex) {
                index + insertionCount
            } else {
                index
            }

        val timeline = player.currentTimeline
        val previousIndices = ArrayDeque<Int>()
        var traversalIndex = currentIndex
        while (true) {
            traversalIndex = timeline.getPreviousWindowIndex(traversalIndex, REPEAT_MODE_OFF, true)
            if (traversalIndex == C.INDEX_UNSET) {
                break
            }
            previousIndices.addFirst(adjustedIndex(traversalIndex))
        }

        val nextIndices = mutableListOf<Int>()
        traversalIndex = currentIndex
        while (true) {
            traversalIndex = timeline.getNextWindowIndex(traversalIndex, REPEAT_MODE_OFF, true)
            if (traversalIndex == C.INDEX_UNSET) {
                break
            }
            nextIndices += adjustedIndex(traversalIndex)
        }

        val shuffledIndices =
            buildList(player.mediaItemCount + insertionCount) {
                addAll(previousIndices)
                add(currentIndex)
                repeat(insertionCount) { offset ->
                    add(insertionIndex + offset)
                }
                addAll(nextIndices)
            }.toIntArray()

        return DefaultShuffleOrder(shuffledIndices, System.currentTimeMillis())
    }

    fun startRadioSeamlessly() {
        val joined = togetherSessionState.value as? moe.rukamori.archivetune.together.TogetherSessionState.Joined
        if (!isTogetherApplyingRemote() && joined?.role is moe.rukamori.archivetune.together.TogetherRole.Guest) {
            if (!joined.roomState.settings.allowGuestsToControlPlayback) {
                showTogetherNotice(getString(R.string.not_allowed), key = "GUEST_RADIO_DISABLED")
                return
            }
            showTogetherNotice(getString(R.string.not_allowed), key = "GUEST_RADIO_UNSUPPORTED")
            return
        }
        val metadata = player.currentMetadata ?: return
        if (metadata.isPodcast || isCurrentPlaybackItemLocal(metadata)) return
        initialQueueJob?.cancel()
        cancelInfiniteQueueBootstrap()
        queuePageJob?.cancel()
        queuePageJob = null
        resetQueueRecommendations()
        currentQueue = EmptyQueue
        suppressAutoPlayback = false
        val generation = ++recommendationGeneration
        val seedEntry = player.currentMediaItem?.queueEntryId
        queueRecommendations.value = QueueRecommendations(loading = true)
        recommendationRequest = scope.launch {
            try {
                val queue = YouTubeQueue(WatchEndpoint(videoId = metadata.id), followAutomixPreview = true)
                val status = withContext(Dispatchers.IO) {
                    queue.getInitialStatus().filterPlaybackContent(
                        dataStore.get(HideExplicitKey, false), dataStore.get(HideVideoKey, false),
                    )
                }
                if (generation != recommendationGeneration || player.currentMediaItem?.queueEntryId != seedEntry ||
                    player.currentMetadata?.id != metadata.id || isTogetherGuestSession()
                ) return@launch
                val queuePlayer = queueEditPlayer()
                val windows = queuePlayer.getQueueWindows()
                val currentUid = queuePlayer.currentTimeline.getWindow(queuePlayer.currentMediaItemIndex, Timeline.Window()).uid
                val current = windows.indexOfFirst { it.uid == currentUid }
                val future = windows.drop(current + 1)
                removeQueueWindows(queuePlayer, future)
                val items = status.items.filterNot { it.mediaId == metadata.id }
                appendRecommendations(items)
                recommendationQueue = queue
                recommendationSeed = metadata.id
                queueTitle = status.title ?: queueTitle
                queueRecommendations.value = QueueRecommendations(chips = queue.chips)
            } catch (error: CancellationException) {
                throw error
            } catch (error: Exception) {
                Timber.e(error, "Failed to start radio")
                if (generation == recommendationGeneration) queueRecommendations.value = QueueRecommendations(failed = true)
            } finally {
                if (generation == recommendationGeneration) {
                    recommendationRequest = null
                    queueRecommendations.value = queueRecommendations.value.copy(loading = false)
                }
            }
        }
    }

    fun clearAutomix() {
        resetQueueRecommendations()
    }

    fun adoptQueueContinuation(
        queue: Queue,
        title: String?,
    ) {
        if (isTogetherGuestSession()) return
        clearQueueContinuation()
        currentQueue = queue
        queueTitle = title
    }

    fun clearQueueContinuation() {
        if (isTogetherGuestSession()) return
        cancelRestoredQueueHydration()
        initialQueueJob?.cancel()
        queuePageJob?.cancel()
        queuePageJob = null
        cancelInfiniteQueueBootstrap()
        resetQueueRecommendations()
        currentQueue = EmptyQueue
    }

    private fun resetQueueRecommendations() {
        recommendationGeneration++
        recommendationRequest?.cancel()
        recommendationRequest = null
        recommendationQueue = null
        recommendationSeed = null
        recommendationBuffer = emptyList()
        failedRecommendation = null
        queueRecommendations.value = QueueRecommendations()
    }

    fun refreshQueueRecommendations(force: Boolean = false) {
        val metadata = player.currentMetadata ?: return
        if (!dataStore.get(AutoLoadMoreKey, true) || metadata.isPodcast ||
            isCurrentPlaybackItemLocal(metadata) || isTogetherGuestSession()
        ) return
        val active = recommendationQueue ?: (currentQueue as? YouTubeQueue)?.takeIf { it.isRadio }
        val chips = queueRecommendations.value.chips.ifEmpty {
            active?.chips.orEmpty().ifEmpty { currentQueue.queueChips }
        }
        if (recommendationRequest?.isActive == true || infiniteQueueJob?.isActive == true) return
        if (force) {
            failedRecommendation?.let { (endpoint, replace, id) ->
                requestRecommendations(endpoint, replace, id)
                return
            }
            if (queueRecommendations.value.failed && currentQueue.hasNextPage()) {
                extendExplicitQueue()
                return
            }
        }
        if (!force && queueRecommendations.value.failed) return
        if (!force && chips.isNotEmpty()) {
            queueRecommendations.value = QueueRecommendations(chips = chips)
            return
        }
        if (!force && (recommendationRequest?.isActive == true || recommendationSeed == metadata.id)) return
        requestRecommendations(active?.endpoint ?: WatchEndpoint(videoId = metadata.id), replace = false)
    }

    fun selectQueueChip(id: String) {
        if (isTogetherGuestSession() || !dataStore.get(AutoLoadMoreKey, true)) return
        if (queueRecommendations.value.pendingChipId == id) return
        val chip = queueRecommendations.value.chips.firstOrNull { it.id == id } ?: return
        val endpoint = if (chip.selected) chip.deselectEndpoint ?: return else chip.endpoint
        requestRecommendations(endpoint, replace = true, chipId = id)
    }

    private fun requestRecommendations(endpoint: WatchEndpoint, replace: Boolean, chipId: String? = null) {
        val seed = player.currentMetadata ?: return
        if (seed.isPodcast || isCurrentPlaybackItemLocal(seed)) return
        val queuePlayer = queueEditPlayer()
        recommendationRequest?.cancel()
        if (replace) {
            cancelInfiniteQueueBootstrap()
        }
        val generation = ++recommendationGeneration
        val source = currentQueue
        val seedEntry = queuePlayer.currentMediaItem?.queueEntryId
        recommendationSeed = seed.id
        val previous = queueRecommendations.value
        failedRecommendation = null
        queueRecommendations.value = previous.copy(loading = true, pendingChipId = chipId, failed = false)
        recommendationRequest = scope.launch {
            try {
                val queue = YouTubeQueue(endpoint, followAutomixPreview = chipId == null)
                val status = withContext(Dispatchers.IO) {
                    queue.getInitialStatus().filterPlaybackContent(
                        dataStore.get(HideExplicitKey, false), dataStore.get(HideVideoKey, false),
                    )
                }
                if (generation != recommendationGeneration || currentQueue !== source ||
                    queueEditPlayer() !== queuePlayer || queuePlayer.currentMediaItem?.queueEntryId != seedEntry ||
                    queuePlayer.currentMetadata?.id != seed.id || !dataStore.get(AutoLoadMoreKey, true) ||
                    isTogetherGuestSession()
                ) return@launch
                val updated = previous.acceptResponse(queue.chips, chipId)
                queue.updateChips(updated.chips)
                if (replace) {
                    val incoming = recommendationItems(status.items)
                    replaceUpcomingRecommendations(incoming)
                    recommendationQueue = queue
                    recommendationBuffer = emptyList()
                    if (currentQueue.recommendationOnlyContinuation) {
                        queuePageJob?.cancel()
                        queuePageJob = null
                        currentQueue = EmptyQueue
                    }
                } else {
                    val active = recommendationQueue
                    if (active == null) {
                        recommendationQueue = queue
                        recommendationBuffer = status.items
                    } else active.updateChips(updated.chips)
                }
                queueRecommendations.value = updated
                if (replace) saveQueueToDisk()
            } catch (error: CancellationException) {
                throw error
            } catch (error: Exception) {
                Timber.e(error, "Failed to update queue recommendations")
                if (generation == recommendationGeneration) {
                    failedRecommendation = Triple(endpoint, replace, chipId)
                    queueRecommendations.value = previous.copy(loading = false, pendingChipId = null, failed = true)
                }
            } finally {
                if (generation == recommendationGeneration) {
                    recommendationRequest = null
                    queueRecommendations.value = queueRecommendations.value.copy(loading = false, pendingChipId = null)
                    if (!queueRecommendations.value.failed && recommendationBuffer.isNotEmpty() &&
                        player.mediaItemCount - player.currentMediaItemIndex <= 3
                    ) onInfiniteQueueEnabled()
                }
            }
        }
    }

    private fun recommendationItems(items: List<MediaItem>): List<MediaItem> {
        val queuePlayer = queueEditPlayer()
        val replaced = upcomingRecommendationWindows(queuePlayer).mapTo(mutableSetOf()) { it.uid }
        val known = queuePlayer.getQueueWindows()
            .filterNot { it.uid in replaced }
            .mapTo(mutableSetOf()) { it.mediaItem.mediaId }
        return items.filter { known.add(it.mediaId) }.map { it.withQueueEntry(recommended = true) }
    }

    private fun upcomingRecommendationWindows(queuePlayer: Player = queueEditPlayer()): List<Timeline.Window> {
        val timeline = queuePlayer.currentTimeline
        if (timeline.isEmpty) return emptyList()
        val windows = queuePlayer.getQueueWindows()
        val currentUid = timeline.getWindow(queuePlayer.currentMediaItemIndex, Timeline.Window()).uid
        val current = windows.indexOfFirst { it.uid == currentUid }
        return if (current < 0) emptyList() else windows.drop(current + 1).filter { it.mediaItem.isQueueRecommendation }
    }

    private fun applyQueueTraversal(queuePlayer: Player, order: List<Any>) {
        if (queuePlayer !is ExoPlayer || !queuePlayer.shuffleModeEnabled) return
        val timeline = queuePlayer.currentTimeline
        val indices = (0 until timeline.windowCount).associate { index ->
            timeline.getWindow(index, Timeline.Window()).uid to index
        }
        val retained = order.mapNotNull(indices::get).distinct()
        val seen = retained.toHashSet()
        val remaining = (0 until timeline.windowCount).filterNot { it in seen }
        queuePlayer.setShuffleOrder(DefaultShuffleOrder((retained + remaining).toIntArray(), System.currentTimeMillis()))
    }

    private fun insertedQueueUids(queuePlayer: Player, items: List<MediaItem>): List<Any> {
        val windows = queuePlayer.getQueueWindows().associateBy { it.mediaItem.queueEntryId }
        return items.mapNotNull { windows[it.queueEntryId]?.uid }
    }

    private fun removeQueueWindows(queuePlayer: Player, windows: List<Timeline.Window>) {
        val removed = windows.mapTo(mutableSetOf()) { it.uid }
        val timeline = queuePlayer.currentTimeline
        val indices = (0 until timeline.windowCount).filter { index ->
            timeline.getWindow(index, Timeline.Window()).uid in removed
        }
        indices.asReversed().forEach(queuePlayer::removeMediaItem)
    }

    private fun appendRecommendations(items: List<MediaItem>) {
        val queuePlayer = queueEditPlayer()
        val order = queuePlayer.getQueueWindows().map { it.uid }
        queuePlayer.addMediaItems(items)
        applyQueueTraversal(queuePlayer, order + insertedQueueUids(queuePlayer, items))
    }

    private fun replaceUpcomingRecommendations(items: List<MediaItem>) {
        val queuePlayer = queueEditPlayer()
        val upcoming = upcomingRecommendationWindows(queuePlayer)
        val removed = upcoming.mapTo(mutableSetOf()) { it.uid }
        val traversal = queuePlayer.getQueueWindows().filterNot { it.uid in removed }.map { it.uid }
        removeQueueWindows(queuePlayer, upcoming)
        queuePlayer.addMediaItems(items)
        applyQueueTraversal(queuePlayer, traversal + insertedQueueUids(queuePlayer, items))
    }

    fun onInfiniteQueueDisabled() {
        cancelInfiniteQueueBootstrap()
        resetQueueRecommendations()
        val queuePlayer = queueEditPlayer()
        removeQueueWindows(queuePlayer, upcomingRecommendationWindows(queuePlayer))
        if (currentQueue.recommendationOnlyContinuation) {
            queuePageJob?.cancel()
            queuePageJob = null
            currentQueue = EmptyQueue
        }
    }

    fun onInfiniteQueueEnabled() {
        val metadata = player.currentMetadata ?: return
        if (metadata.isPodcast || isCurrentPlaybackItemLocal(metadata) || isTogetherGuestSession()) return
        if (infiniteQueueJob?.isActive == true || recommendationRequest?.isActive == true ||
            queuePageJob?.isActive == true || initialQueueJob?.isActive == true || currentQueue.hasNextPage()
        ) return
        val active = recommendationQueue
        if (active != null && recommendationBuffer.isEmpty() && !active.hasNextPage()) return
        val generation = ++infiniteQueueGeneration
        val recommendationVersion = recommendationGeneration
        val seedId = metadata.id
        val source = currentQueue
        infiniteQueueLoading.value = true
        infiniteQueueJob = scope.launch {
            try {
                val queue = active
                    ?: YouTubeQueue(WatchEndpoint(videoId = seedId), followAutomixPreview = true)
                val buffered = recommendationBuffer
                val fetchPage = recommendationQueue === queue && buffered.isEmpty() && queue.hasNextPage()
                val (page, items) = withContext(Dispatchers.IO) {
                    val page = if (fetchPage) queue.fetchNextPage() else null
                    val items = when {
                        buffered.isNotEmpty() -> buffered
                        page != null -> page.items.map { it.toMediaItem().withQueueEntry(recommended = true) }
                        else -> queue.getInitialStatus().items
                    }
                    page to items.filterPlaybackContent(dataStore.get(HideExplicitKey, false), dataStore.get(HideVideoKey, false))
                }
                if (generation != infiniteQueueGeneration || recommendationVersion != recommendationGeneration ||
                    currentQueue !== source || !dataStore.get(AutoLoadMoreKey, true) || isTogetherGuestSession()
                ) return@launch
                page?.let(queue::acceptNextPage)
                val known = (0 until player.mediaItemCount).mapTo(mutableSetOf()) { player.getMediaItemAt(it).mediaId }
                val additions = items.filter { known.add(it.mediaId) }.map { it.withQueueEntry(recommended = true) }
                val resumeAfterEnd = player.playbackState == Player.STATE_ENDED && player.playWhenReady
                appendRecommendations(additions)
                if (resumeAfterEnd && player.hasNextMediaItem()) player.seekToNextMediaItem()
                recommendationBuffer = emptyList()
                recommendationQueue = queue
                recommendationSeed = seedId
                val updated = queueRecommendations.value.acceptResponse(queue.chips)
                queue.updateChips(updated.chips)
                queueRecommendations.value = updated
            } catch (error: CancellationException) {
                throw error
            } catch (error: Exception) {
                Timber.e(error, "Failed to load queue recommendations")
                if (generation == infiniteQueueGeneration) queueRecommendations.value = queueRecommendations.value.copy(failed = true)
            } finally {
                if (generation == infiniteQueueGeneration) {
                    infiniteQueueJob = null
                    infiniteQueueLoading.value = false
                }
            }
        }
    }

    private fun extendExplicitQueue() {
        if (queuePageJob?.isActive == true || initialQueueJob?.isActive == true || !currentQueue.hasNextPage()) return
        val queue = currentQueue
        queueRecommendations.value = queueRecommendations.value.copy(failed = false)
        queuePageJob = scope.launch {
            try {
                val items = withContext(Dispatchers.IO) {
                    queue.nextPage().filterPlaybackContent(
                        dataStore.get(HideExplicitKey, false), dataStore.get(HideVideoKey, false),
                    )
                }
                if (currentQueue !== queue || player.playbackState == STATE_IDLE) return@launch
                val queuePlayer = queueEditPlayer()
                val knownEntries = queuePlayer.getQueueWindows().mapNotNullTo(mutableSetOf()) { it.mediaItem.metadata?.setVideoId }
                val additions = items.filter { item ->
                    item.metadata?.setVideoId?.takeIf { it.isNotBlank() }?.let(knownEntries::add) ?: true
                }.map { it.withQueueEntry() }
                val windows = queuePlayer.getQueueWindows()
                val upcoming = upcomingRecommendationWindows(queuePlayer).mapTo(mutableSetOf()) { it.uid }
                val position = windows.indexOfFirst { it.uid in upcoming }.takeIf { it >= 0 } ?: windows.size
                if (queuePlayer.shuffleModeEnabled) {
                    queuePlayer.addMediaItems(additions)
                    val order = windows.map { it.uid }
                    applyQueueTraversal(queuePlayer, order.take(position) + insertedQueueUids(queuePlayer, additions) + order.drop(position))
                } else {
                    queuePlayer.addMediaItems(position, additions)
                }
                if (queue.recommendationOnlyContinuation) {
                    queueRecommendations.value = queueRecommendations.value.acceptResponse(queue.queueChips)
                }
            } catch (error: CancellationException) {
                throw error
            } catch (error: Exception) {
                Timber.e(error, "Failed to extend explicit queue")
                queueRecommendations.value = queueRecommendations.value.copy(failed = true)
            }
        }
    }

    private fun cancelInfiniteQueueBootstrap() {
        infiniteQueueGeneration++
        infiniteQueueJob?.cancel()
        infiniteQueueJob = null
        infiniteQueueLoading.value = false
    }

    fun stopAndClearPlayback(clearPersistentState: Boolean = false) {
        cancelRestoredQueueHydration()
        initialQueueJob?.cancel()
        queuePageJob?.cancel()
        queuePageJob = null
        cancelInfiniteQueueBootstrap()
        resetQueueRecommendations()
        suppressAutoPlayback = true
        cancelCrossfade(resetVolume = true)
        currentQueue = EmptyQueue
        queueTitle = null
        waitingForNetworkConnection.value = false
        currentMediaMetadata.value = null
        player.playWhenReady = false
        player.stop()
        player.clearMediaItems()
        abandonAudioFocus()
        closeAudioEffectSession()
        consecutivePlaybackErr = 0
        if (clearPersistentState) {
            clearPersistedQueueFiles()
        }
    }

    fun playNext(items: List<MediaItem>) {
        val allowedItems =
            items
                .filterBlockedArtists(blockedArtistIds)
                .filterVideo(hideMusicVideos)
        if (allowedItems.isEmpty()) return
        val joined = togetherSessionState.value as? moe.rukamori.archivetune.together.TogetherSessionState.Joined
        if (joined?.role is moe.rukamori.archivetune.together.TogetherRole.Guest) {
            if (!joined.roomState.settings.allowGuestsToAddTracks) {
                return
            }
            val tracks =
                allowedItems.mapNotNull { it.metadata }.map { meta ->
                    moe.rukamori.archivetune.together.TogetherTrack(
                        id = meta.id,
                        title = meta.title,
                        artists = meta.artists.map { it.name },
                        durationSec = meta.duration,
                        thumbnailUrl = meta.thumbnailUrl,
                    )
                }
            tracks.asReversed().forEach { track ->
                requestTogetherAddTrack(track, moe.rukamori.archivetune.together.AddTrackMode.PLAY_NEXT)
            }
            return
        }
        suppressAutoPlayback = false
        val insertionIndex = if (player.mediaItemCount == 0) 0 else player.currentMediaItemIndex + 1
        val playNextShuffleOrder =
            if (player.shuffleModeEnabled && player.mediaItemCount > 0) {
                buildPlayNextShuffleOrder(
                    currentIndex = player.currentMediaItemIndex,
                    insertionIndex = insertionIndex,
                    insertionCount = allowedItems.size,
                )
            } else {
                null
            }

        player.addMediaItems(insertionIndex, allowedItems.map { it.withQueueEntry(recommended = false, id = java.util.UUID.randomUUID().toString()) })
        playNextShuffleOrder?.let(localPlayer::setShuffleOrder)
        player.prepare()
    }

    internal fun removeQueueItems(windows: List<Timeline.Window>): QueueRemoval? {
        if (isTogetherGuestSession()) return null
        return QueueRemoval.remove(queueEditPlayer(), windows).also { pendingQueueRemoval = it }
    }

    internal fun restoreQueueItems(removal: QueueRemoval): Boolean {
        if (pendingQueueRemoval !== removal || isTogetherGuestSession()) return false
        pendingQueueRemoval = null
        return removal.restore(queueEditPlayer())
    }

    internal fun discardQueueRemoval(removal: QueueRemoval) {
        if (pendingQueueRemoval === removal) pendingQueueRemoval = null
    }

    private fun queueEditPlayer(): Player =
        if (player.deviceInfo.playbackType == androidx.media3.common.DeviceInfo.PLAYBACK_TYPE_LOCAL) {
            localPlayer
        } else {
            player
        }

    fun moveQueueItemToNext(mediaItemIndex: Int) {
        val currentIndex = player.currentMediaItemIndex
        if (
            player.mediaItemCount < 2 ||
            currentIndex == C.INDEX_UNSET ||
            mediaItemIndex !in 0 until player.mediaItemCount ||
            mediaItemIndex == currentIndex
        ) {
            return
        }

        if (player.shuffleModeEnabled) {
            val shuffledIndices = player.getQueueWindows().map { it.firstPeriodIndex }.toMutableList()
            val sourcePosition = shuffledIndices.indexOf(mediaItemIndex)
            val currentPosition = shuffledIndices.indexOf(currentIndex)
            if (sourcePosition == -1 || currentPosition == -1) return

            val destinationPosition = (currentPosition + 1).coerceAtMost(shuffledIndices.lastIndex)
            if (sourcePosition == destinationPosition) return

            shuffledIndices.move(sourcePosition, destinationPosition)
            localPlayer.setShuffleOrder(
                DefaultShuffleOrder(
                    shuffledIndices.toIntArray(),
                    System.currentTimeMillis(),
                ),
            )
            return
        }

        val destinationIndex = (currentIndex + 1).coerceAtMost(player.mediaItemCount - 1)
        if (mediaItemIndex != destinationIndex) {
            player.moveMediaItem(mediaItemIndex, destinationIndex)
        }
    }

    fun addToQueue(items: List<MediaItem>) {
        val allowedItems =
            items
                .filterBlockedArtists(blockedArtistIds)
                .filterVideo(hideMusicVideos)
        if (allowedItems.isEmpty()) return
        val joined = togetherSessionState.value as? moe.rukamori.archivetune.together.TogetherSessionState.Joined
        if (joined?.role is moe.rukamori.archivetune.together.TogetherRole.Guest) {
            if (!joined.roomState.settings.allowGuestsToAddTracks) {
                return
            }
            val tracks =
                allowedItems.mapNotNull { it.metadata }.map { meta ->
                    moe.rukamori.archivetune.together.TogetherTrack(
                        id = meta.id,
                        title = meta.title,
                        artists = meta.artists.map { it.name },
                        durationSec = meta.duration,
                        thumbnailUrl = meta.thumbnailUrl,
                    )
                }
            tracks.forEach { track ->
                requestTogetherAddTrack(track, moe.rukamori.archivetune.together.AddTrackMode.ADD_TO_QUEUE)
            }
            return
        }
        suppressAutoPlayback = false
        player.addMediaItems(allowedItems.map { it.withQueueEntry(recommended = false, id = java.util.UUID.randomUUID().toString()) })
        player.prepare()
    }

    fun playFromVoiceSearch(query: String) {
        val trimmed = query.trim()
        if (trimmed.isBlank()) return
        ensureScopesActive()
        scope.launch(SilentHandler) {
            val mediaItems =
                withContext(Dispatchers.IO) {
                    mediaLibrarySessionCallback.resolveVoiceMediaItems(trimmed)
                }
            if (mediaItems.isEmpty()) return@launch
            playQueue(ListQueue(items = mediaItems))
        }
    }

    fun startTogetherHost(
        port: Int,
        displayName: String,
        settings: moe.rukamori.archivetune.together.TogetherRoomSettings,
    ) {
        ensureScopesActive()
        scope.launch(SilentHandler) {
            togetherSessionState.value = moe.rukamori.archivetune.together.TogetherSessionState.Idle
        }

        ioScope.launch(SilentHandler) {
            stopTogetherInternal()
            togetherIsOnlineSession = false

            val localIp = getLocalIpv4Address()
            val sessionId =
                java.util.UUID
                    .randomUUID()
                    .toString()
            val sessionKey =
                java.util.UUID
                    .randomUUID()
                    .toString()
            val joinInfo =
                moe.rukamori.archivetune.together.TogetherJoinInfo(
                    host = localIp ?: "127.0.0.1",
                    port = port,
                    sessionId = sessionId,
                    sessionKey = sessionKey,
                )
            val joinLink =
                moe.rukamori.archivetune.together.TogetherLink
                    .encode(joinInfo)

            val server =
                moe.rukamori.archivetune.together.TogetherServer(
                    scope = ioScope,
                    sessionId = sessionId,
                    sessionKey = sessionKey,
                    hostDisplayName = displayName.trim().ifBlank { getString(R.string.app_name) },
                    initialSettings = settings,
                    hostParticipantId = togetherHostId,
                )

            server.onEvent = { event ->
                ioScope.launch(SilentHandler) {
                    handleTogetherHostEvent(event) { server.currentSettings() }
                }
            }

            server.start(port)
            togetherServer = server
            scheduleTogetherHostInactivityTimeout(sessionId)

            scope.launch(SilentHandler) {
                togetherSessionState.value =
                    moe.rukamori.archivetune.together.TogetherSessionState.Hosting(
                        sessionId = sessionId,
                        joinLink = joinLink,
                        localAddressHint = localIp,
                        port = port,
                        settings = settings,
                        roomState = null,
                    )
            }

            togetherBroadcastJob =
                ioScope.launch(SilentHandler) {
                    while (togetherServer === server) {
                        if (togetherAuthorityParticipantId == null || togetherAuthorityParticipantId == togetherHostId) {
                            val state = buildTogetherRoomState(sessionId = sessionId, hostId = togetherHostId)
                            server.broadcastRoomState(state)
                            scope.launch(SilentHandler) {
                                val hosting = togetherSessionState.value as? moe.rukamori.archivetune.together.TogetherSessionState.Hosting
                                if (hosting?.sessionId == sessionId) {
                                    togetherSessionState.value =
                                        hosting.copy(
                                            settings = server.currentSettings(),
                                            roomState =
                                                state.copy(
                                                    participants = server.currentParticipants(),
                                                    settings = server.currentSettings(),
                                                ),
                                        )
                                }
                            }
                        }
                        kotlinx.coroutines.delay(TogetherPlaybackSync.BroadcastIntervalMs)
                    }
                }
        }
    }

    private fun togetherOnlineErrorMessage(t: Throwable): String {
        if (t is moe.rukamori.archivetune.together.TogetherOnlineApiException) {
            val code = t.statusCode
            return when {
                code == 404 -> getString(R.string.together_session_not_found)
                code != null && code in 500..599 -> getString(R.string.together_server_error)
                else -> t.message ?: getString(R.string.network_unavailable)
            }
        }
        val root = generateSequence(t) { it.cause }.lastOrNull() ?: t
        return when (root) {
            is UnknownHostException -> getString(R.string.together_server_unreachable)
            is ConnectException -> getString(R.string.together_server_unreachable)
            is SocketTimeoutException -> getString(R.string.together_connection_timed_out)
            is javax.net.ssl.SSLHandshakeException -> getString(R.string.together_server_unreachable)
            else -> getString(R.string.network_unavailable)
        }
    }

    fun startTogetherOnlineHost(
        displayName: String,
        settings: moe.rukamori.archivetune.together.TogetherRoomSettings,
    ) {
        ensureScopesActive()
        scope.launch(SilentHandler) {
            togetherSessionState.value = moe.rukamori.archivetune.together.TogetherSessionState.Idle
        }

        ioScope.launch(SilentHandler) {
            stopTogetherInternal()
            togetherIsOnlineSession = true

            val baseUrl =
                moe.rukamori.archivetune.together.TogetherOnlineEndpoint
                    .baseUrlOrNull(dataStore)
            if (baseUrl == null) {
                scope.launch(SilentHandler) {
                    togetherSessionState.value =
                        moe.rukamori.archivetune.together.TogetherSessionState.Error(
                            message = getString(R.string.together_online_not_configured),
                            recoverable = true,
                        )
                }
                return@launch
            }

            val togetherToken =
                moe.rukamori.archivetune.BuildConfig.TOGETHER_BEARER_TOKEN
                    .trim()
                    .takeIf { it.isNotBlank() }
            if (togetherToken == null) {
                scope.launch(SilentHandler) {
                    togetherSessionState.value =
                        moe.rukamori.archivetune.together.TogetherSessionState.Error(
                            message = getString(R.string.together_token_missing),
                            recoverable = true,
                        )
                }
                return@launch
            }

            val api =
                moe.rukamori.archivetune.together
                    .TogetherOnlineApi(baseUrl = baseUrl, bearerToken = togetherToken)
            val hostName = displayName.trim().ifBlank { getString(R.string.app_name) }

            val created =
                runCatching {
                    api.createSession(
                        hostDisplayName = hostName,
                        settings = settings,
                    )
                }.getOrElse { t ->
                    scope.launch(SilentHandler) {
                        togetherSessionState.value =
                            moe.rukamori.archivetune.together.TogetherSessionState.Error(
                                message = togetherOnlineErrorMessage(t),
                                recoverable = true,
                            )
                    }
                    reportException(t)
                    return@launch
                }

            val onlineHost =
                moe.rukamori.archivetune.together.TogetherOnlineHost(
                    externalScope = ioScope,
                    sessionId = created.sessionId,
                    sessionKey = created.hostKey,
                    hostId = togetherHostId,
                    hostDisplayName = hostName,
                    initialSettings = created.settings,
                    clientId = getOrCreateTogetherClientId(),
                    bearerToken = togetherToken,
                )

            onlineHost.onEvent = { event ->
                ioScope.launch(SilentHandler) {
                    handleTogetherHostEvent(event) { onlineHost.currentSettings() }
                }
            }

            togetherOnlineHost = onlineHost
            scheduleTogetherHostInactivityTimeout(created.sessionId) {
                api.endSession(
                    sessionId = created.sessionId,
                    hostKey = created.hostKey,
                )
            }

            scope.launch(SilentHandler) {
                togetherSessionState.value =
                    moe.rukamori.archivetune.together.TogetherSessionState.HostingOnline(
                        sessionId = created.sessionId,
                        code = created.code,
                        settings = created.settings,
                        roomState = null,
                    )
            }

            val wsUrl =
                moe.rukamori.archivetune.together.TogetherOnlineEndpoint.onlineWebSocketUrlOrNull(
                    rawWsUrl = created.wsUrl,
                    baseUrl = baseUrl,
                )
            if (wsUrl == null) {
                scope.launch(SilentHandler) {
                    togetherSessionState.value =
                        moe.rukamori.archivetune.together.TogetherSessionState.Error(
                            message = "Connection failed: Invalid server websocket URL",
                            recoverable = true,
                        )
                }
                ioScope.launch(SilentHandler) { stopTogetherInternal() }
                return@launch
            }

            togetherOnlineConnectJob?.cancel()
            togetherOnlineConnectJob =
                ioScope.launch(SilentHandler) {
                    onlineHost.connect(wsUrl)
                }

            togetherBroadcastJob =
                ioScope.launch(SilentHandler) {
                    while (togetherOnlineHost === onlineHost) {
                        val state =
                            if (togetherAuthorityParticipantId == null || togetherAuthorityParticipantId == togetherHostId) {
                                buildTogetherRoomState(
                                    sessionId = created.sessionId,
                                    hostId = togetherHostId,
                                )
                            } else {
                                null
                            }
                        if (state != null) {
                            onlineHost.broadcastRoomState(state)
                            scope.launch(SilentHandler) {
                                val hosting =
                                    togetherSessionState.value as? moe.rukamori.archivetune.together.TogetherSessionState.HostingOnline
                                if (hosting?.sessionId == created.sessionId) {
                                    val currentSettings = onlineHost.currentSettings()
                                    togetherSessionState.value =
                                        hosting.copy(
                                            settings = currentSettings,
                                            roomState =
                                                state.copy(
                                                    participants = onlineHost.currentParticipants(),
                                                    settings = currentSettings,
                                                ),
                                        )
                                }
                            }
                        }
                        kotlinx.coroutines.delay(TogetherPlaybackSync.BroadcastIntervalMs)
                    }
                }
        }
    }

    fun joinTogether(
        rawLink: String,
        displayName: String,
    ) {
        ensureScopesActive()
        val joinInfo =
            moe.rukamori.archivetune.together.TogetherLink
                .decode(rawLink)
        if (joinInfo == null) {
            scope.launch(SilentHandler) {
                togetherSessionState.value =
                    moe.rukamori.archivetune.together.TogetherSessionState.Error(
                        message = getString(R.string.invalid_link),
                        recoverable = true,
                    )
            }
            return
        }

        scope.launch(SilentHandler) {
            togetherSessionState.value =
                moe.rukamori.archivetune.together.TogetherSessionState
                    .Joining(joinInfo.toDeepLink())
        }

        ioScope.launch(SilentHandler) {
            stopTogetherInternal()
            togetherIsOnlineSession = false
            val client =
                moe.rukamori.archivetune.together.TogetherClient(
                    ioScope,
                    clientId = getOrCreateTogetherClientId(),
                )
            togetherClient = client
            togetherClock =
                moe.rukamori.archivetune.together
                    .TogetherClock()
            togetherSelfParticipantId = null
            togetherLastAppliedQueueHash = null

            togetherClientEventsJob?.cancel()
            togetherClientEventsJob =
                ioScope.launch(SilentHandler) {
                    client.events.collect { event ->
                        when (event) {
                            is moe.rukamori.archivetune.together.TogetherClientEvent.Welcome -> {
                                togetherSelfParticipantId = event.welcome.participantId
                                scope.launch(SilentHandler) {
                                    val state = togetherSessionState.value
                                    if (state is moe.rukamori.archivetune.together.TogetherSessionState.Joining) {
                                        val selfName = displayName.trim().ifBlank { getString(R.string.together_role_guest) }
                                        val initial =
                                            moe.rukamori.archivetune.together.TogetherRoomState(
                                                sessionId = joinInfo.sessionId,
                                                hostId = togetherHostId,
                                                participants =
                                                    listOf(
                                                        moe.rukamori.archivetune.together.TogetherParticipant(
                                                            id = event.welcome.participantId,
                                                            name = selfName,
                                                            isHost = false,
                                                            isPending = event.welcome.isPending,
                                                            isConnected = true,
                                                        ),
                                                    ),
                                                settings = event.welcome.settings,
                                                queue = emptyList(),
                                                queueHash = "",
                                                currentIndex = 0,
                                                isPlaying = false,
                                                positionMs = 0L,
                                                repeatMode = 0,
                                                shuffleEnabled = false,
                                                sentAtElapsedRealtimeMs = android.os.SystemClock.elapsedRealtime(),
                                            )
                                        togetherSessionState.value =
                                            moe.rukamori.archivetune.together.TogetherSessionState.Joined(
                                                role = moe.rukamori.archivetune.together.TogetherRole.Guest,
                                                sessionId = joinInfo.sessionId,
                                                selfParticipantId = event.welcome.participantId,
                                                roomState = initial,
                                            )
                                    }
                                }
                                startTogetherHeartbeat(joinInfo.sessionId, client)
                            }

                            is moe.rukamori.archivetune.together.TogetherClientEvent.RoomState -> {
                                applyRemoteRoomState(event.state)
                            }

                            is moe.rukamori.archivetune.together.TogetherClientEvent.HostTransferred -> {
                                handleTogetherClientHostTransferred(event.transfer)
                            }

                            is moe.rukamori.archivetune.together.TogetherClientEvent.ControlRequested -> {
                                val joined =
                                    togetherSessionState.value as? moe.rukamori.archivetune.together.TogetherSessionState.Joined
                                if (togetherAuthorityParticipantId == togetherSelfParticipantId &&
                                    joined?.roomState?.settings?.allowGuestsToControlPlayback == true
                                ) {
                                    applyHostControl(event.request.action)
                                }
                            }

                            is moe.rukamori.archivetune.together.TogetherClientEvent.AddTrackRequested -> {
                                val joined =
                                    togetherSessionState.value as? moe.rukamori.archivetune.together.TogetherSessionState.Joined
                                if (togetherAuthorityParticipantId == togetherSelfParticipantId &&
                                    joined?.roomState?.settings?.allowGuestsToAddTracks == true
                                ) {
                                    applyHostAddTrack(event.request.track, event.request.mode)
                                }
                            }

                            is moe.rukamori.archivetune.together.TogetherClientEvent.JoinDecision -> {
                                if (!event.decision.approved) {
                                    scope.launch(SilentHandler) {
                                        togetherSessionState.value =
                                            moe.rukamori.archivetune.together.TogetherSessionState.Error(
                                                message = getString(R.string.not_allowed),
                                                recoverable = true,
                                            )
                                    }
                                    ioScope.launch(SilentHandler) { stopTogetherInternal() }
                                }
                            }

                            is moe.rukamori.archivetune.together.TogetherClientEvent.ServerIssue -> {
                                Timber.tag("Together").w("server issue (lan) code=${event.code.orEmpty()} message=${event.message}")
                                when (event.code) {
                                    "GUEST_CONTROL_DISABLED" -> {
                                        showTogetherNotice(event.message, key = "GUEST_CONTROL_DISABLED")
                                        val joined =
                                            togetherSessionState.value as? moe.rukamori.archivetune.together.TogetherSessionState.Joined
                                        if (joined?.role is moe.rukamori.archivetune.together.TogetherRole.Guest) {
                                            togetherPendingGuestControl = null
                                            togetherLastSentControlAction = null
                                            restoreTogetherGuestPlayback()
                                        }
                                    }

                                    "GUEST_ADD_DISABLED" -> {
                                        showTogetherNotice(event.message, key = "GUEST_ADD_DISABLED")
                                    }

                                    "HOST_OFFLINE" -> {
                                        showTogetherNotice(event.message, key = "HOST_OFFLINE")
                                    }

                                    else -> {
                                        scope.launch(SilentHandler) {
                                            togetherSessionState.value =
                                                moe.rukamori.archivetune.together.TogetherSessionState.Error(
                                                    message = event.message,
                                                    recoverable = true,
                                                )
                                        }
                                        ioScope.launch(SilentHandler) { stopTogetherInternal() }
                                    }
                                }
                            }

                            is moe.rukamori.archivetune.together.TogetherClientEvent.HeartbeatPong -> {
                                val clock = togetherClock ?: return@collect
                                clock.onPong(
                                    sentAtElapsedMs = event.pong.clientElapsedRealtimeMs,
                                    receivedAtElapsedMs = event.receivedAtElapsedRealtimeMs,
                                    serverElapsedMs = event.pong.serverElapsedRealtimeMs,
                                )
                            }

                            is moe.rukamori.archivetune.together.TogetherClientEvent.Error -> {
                                scope.launch(SilentHandler) {
                                    togetherSessionState.value =
                                        moe.rukamori.archivetune.together.TogetherSessionState.Error(
                                            message = event.message,
                                            recoverable = true,
                                        )
                                }
                                ioScope.launch(SilentHandler) { stopTogetherInternal() }
                            }

                            moe.rukamori.archivetune.together.TogetherClientEvent.Disconnected -> {
                                val current = togetherSessionState.value
                                if (current is moe.rukamori.archivetune.together.TogetherSessionState.Idle) return@collect
                                scope.launch(SilentHandler) {
                                    val currentState = togetherSessionState.value
                                    togetherSessionState.value =
                                        moe.rukamori.archivetune.together.TogetherSessionState.Error(
                                            message =
                                                if (currentState is moe.rukamori.archivetune.together.TogetherSessionState.Joined &&
                                                    currentState.role is moe.rukamori.archivetune.together.TogetherRole.Guest
                                                ) {
                                                    getString(R.string.together_host_left_session)
                                                } else {
                                                    getString(R.string.network_unavailable)
                                                },
                                            recoverable = true,
                                        )
                                }
                                ioScope.launch(SilentHandler) { stopTogetherInternal() }
                            }
                        }
                    }
                }

            client.connect(joinInfo, displayName.trim().ifBlank { getString(R.string.together_role_guest) })
        }
    }

    fun joinTogetherOnline(
        code: String,
        displayName: String,
    ) {
        ensureScopesActive()
        val trimmedCode = code.trim()
        if (trimmedCode.isBlank()) {
            scope.launch(SilentHandler) {
                togetherSessionState.value =
                    moe.rukamori.archivetune.together.TogetherSessionState.Error(
                        message = getString(R.string.invalid_code),
                        recoverable = true,
                    )
            }
            return
        }

        scope.launch(SilentHandler) {
            togetherSessionState.value =
                moe.rukamori.archivetune.together.TogetherSessionState
                    .JoiningOnline(trimmedCode)
        }

        ioScope.launch(SilentHandler) {
            stopTogetherInternal()
            togetherIsOnlineSession = true

            val baseUrl =
                moe.rukamori.archivetune.together.TogetherOnlineEndpoint
                    .baseUrlOrNull(dataStore)
            if (baseUrl == null) {
                scope.launch(SilentHandler) {
                    togetherSessionState.value =
                        moe.rukamori.archivetune.together.TogetherSessionState.Error(
                            message = getString(R.string.together_online_not_configured),
                            recoverable = true,
                        )
                }
                return@launch
            }

            val togetherToken =
                moe.rukamori.archivetune.BuildConfig.TOGETHER_BEARER_TOKEN
                    .trim()
                    .takeIf { it.isNotBlank() }
            if (togetherToken == null) {
                scope.launch(SilentHandler) {
                    togetherSessionState.value =
                        moe.rukamori.archivetune.together.TogetherSessionState.Error(
                            message = getString(R.string.together_token_missing),
                            recoverable = true,
                        )
                }
                return@launch
            }

            val api =
                moe.rukamori.archivetune.together
                    .TogetherOnlineApi(baseUrl = baseUrl, bearerToken = togetherToken)
            val resolved =
                runCatching { api.resolveCode(trimmedCode) }
                    .getOrElse { t ->
                        scope.launch(SilentHandler) {
                            togetherSessionState.value =
                                moe.rukamori.archivetune.together.TogetherSessionState.Error(
                                    message = togetherOnlineErrorMessage(t),
                                    recoverable = true,
                                )
                        }
                        reportException(t)
                        return@launch
                    }

            val client =
                moe.rukamori.archivetune.together.TogetherClient(
                    ioScope,
                    clientId = getOrCreateTogetherClientId(),
                    bearerToken = togetherToken,
                )
            togetherClient = client
            togetherClock =
                moe.rukamori.archivetune.together
                    .TogetherClock()
            togetherSelfParticipantId = null
            togetherLastAppliedQueueHash = null

            togetherClientEventsJob?.cancel()
            togetherClientEventsJob =
                ioScope.launch(SilentHandler) {
                    client.events.collect { event ->
                        when (event) {
                            is moe.rukamori.archivetune.together.TogetherClientEvent.Welcome -> {
                                togetherSelfParticipantId = event.welcome.participantId
                                scope.launch(SilentHandler) {
                                    val state = togetherSessionState.value
                                    if (state is moe.rukamori.archivetune.together.TogetherSessionState.JoiningOnline) {
                                        val selfName = displayName.trim().ifBlank { getString(R.string.together_role_guest) }
                                        val initial =
                                            moe.rukamori.archivetune.together.TogetherRoomState(
                                                sessionId = resolved.sessionId,
                                                hostId = togetherHostId,
                                                participants =
                                                    listOf(
                                                        moe.rukamori.archivetune.together.TogetherParticipant(
                                                            id = event.welcome.participantId,
                                                            name = selfName,
                                                            isHost = false,
                                                            isPending = event.welcome.isPending,
                                                            isConnected = true,
                                                        ),
                                                    ),
                                                settings = event.welcome.settings,
                                                queue = emptyList(),
                                                queueHash = "",
                                                currentIndex = 0,
                                                isPlaying = false,
                                                positionMs = 0L,
                                                repeatMode = 0,
                                                shuffleEnabled = false,
                                                sentAtElapsedRealtimeMs = android.os.SystemClock.elapsedRealtime(),
                                            )
                                        togetherSessionState.value =
                                            moe.rukamori.archivetune.together.TogetherSessionState.Joined(
                                                role = moe.rukamori.archivetune.together.TogetherRole.Guest,
                                                sessionId = resolved.sessionId,
                                                selfParticipantId = event.welcome.participantId,
                                                roomState = initial,
                                            )
                                    }
                                }
                                startTogetherHeartbeat(resolved.sessionId, client)
                            }

                            is moe.rukamori.archivetune.together.TogetherClientEvent.RoomState -> {
                                applyRemoteRoomState(event.state)
                            }

                            is moe.rukamori.archivetune.together.TogetherClientEvent.HostTransferred -> {
                                handleTogetherClientHostTransferred(event.transfer)
                            }

                            is moe.rukamori.archivetune.together.TogetherClientEvent.ControlRequested -> {
                                val joined =
                                    togetherSessionState.value as? moe.rukamori.archivetune.together.TogetherSessionState.Joined
                                if (togetherAuthorityParticipantId == togetherSelfParticipantId &&
                                    joined?.roomState?.settings?.allowGuestsToControlPlayback == true
                                ) {
                                    applyHostControl(event.request.action)
                                }
                            }

                            is moe.rukamori.archivetune.together.TogetherClientEvent.AddTrackRequested -> {
                                val joined =
                                    togetherSessionState.value as? moe.rukamori.archivetune.together.TogetherSessionState.Joined
                                if (togetherAuthorityParticipantId == togetherSelfParticipantId &&
                                    joined?.roomState?.settings?.allowGuestsToAddTracks == true
                                ) {
                                    applyHostAddTrack(event.request.track, event.request.mode)
                                }
                            }

                            is moe.rukamori.archivetune.together.TogetherClientEvent.JoinDecision -> {
                                if (!event.decision.approved) {
                                    scope.launch(SilentHandler) {
                                        togetherSessionState.value =
                                            moe.rukamori.archivetune.together.TogetherSessionState.Error(
                                                message = getString(R.string.not_allowed),
                                                recoverable = true,
                                            )
                                    }
                                    ioScope.launch(SilentHandler) { stopTogetherInternal() }
                                }
                            }

                            is moe.rukamori.archivetune.together.TogetherClientEvent.ServerIssue -> {
                                Timber.tag("Together").w("server issue (online) code=${event.code.orEmpty()} message=${event.message}")
                                when (event.code) {
                                    "GUEST_CONTROL_DISABLED" -> {
                                        showTogetherNotice(event.message, key = "GUEST_CONTROL_DISABLED")
                                        val joined =
                                            togetherSessionState.value as? moe.rukamori.archivetune.together.TogetherSessionState.Joined
                                        if (joined?.role is moe.rukamori.archivetune.together.TogetherRole.Guest) {
                                            togetherPendingGuestControl = null
                                            togetherLastSentControlAction = null
                                            restoreTogetherGuestPlayback()
                                        }
                                    }

                                    "GUEST_ADD_DISABLED" -> {
                                        showTogetherNotice(event.message, key = "GUEST_ADD_DISABLED")
                                    }

                                    "HOST_OFFLINE" -> {
                                        showTogetherNotice(event.message, key = "HOST_OFFLINE")
                                    }

                                    else -> {
                                        scope.launch(SilentHandler) {
                                            togetherSessionState.value =
                                                moe.rukamori.archivetune.together.TogetherSessionState.Error(
                                                    message = event.message,
                                                    recoverable = true,
                                                )
                                        }
                                        ioScope.launch(SilentHandler) { stopTogetherInternal() }
                                    }
                                }
                            }

                            is moe.rukamori.archivetune.together.TogetherClientEvent.HeartbeatPong -> {
                                val clock = togetherClock ?: return@collect
                                clock.onPong(
                                    sentAtElapsedMs = event.pong.clientElapsedRealtimeMs,
                                    receivedAtElapsedMs = event.receivedAtElapsedRealtimeMs,
                                    serverElapsedMs = event.pong.serverElapsedRealtimeMs,
                                )
                            }

                            is moe.rukamori.archivetune.together.TogetherClientEvent.Error -> {
                                scope.launch(SilentHandler) {
                                    togetherSessionState.value =
                                        moe.rukamori.archivetune.together.TogetherSessionState.Error(
                                            message = event.message,
                                            recoverable = true,
                                        )
                                }
                                ioScope.launch(SilentHandler) { stopTogetherInternal() }
                            }

                            moe.rukamori.archivetune.together.TogetherClientEvent.Disconnected -> {
                                val current = togetherSessionState.value
                                if (current is moe.rukamori.archivetune.together.TogetherSessionState.Idle) return@collect
                                scope.launch(SilentHandler) {
                                    val currentState = togetherSessionState.value
                                    togetherSessionState.value =
                                        moe.rukamori.archivetune.together.TogetherSessionState.Error(
                                            message =
                                                if (currentState is moe.rukamori.archivetune.together.TogetherSessionState.Joined &&
                                                    currentState.role is moe.rukamori.archivetune.together.TogetherRole.Guest
                                                ) {
                                                    getString(R.string.together_host_left_session)
                                                } else {
                                                    getString(R.string.network_unavailable)
                                                },
                                            recoverable = true,
                                        )
                                }
                                ioScope.launch(SilentHandler) { stopTogetherInternal() }
                            }
                        }
                    }
                }

            val wsUrl =
                moe.rukamori.archivetune.together.TogetherOnlineEndpoint.onlineWebSocketUrlOrNull(
                    rawWsUrl = resolved.wsUrl,
                    baseUrl = baseUrl,
                )
            if (wsUrl == null) {
                scope.launch(SilentHandler) {
                    togetherSessionState.value =
                        moe.rukamori.archivetune.together.TogetherSessionState.Error(
                            message = "Connection failed: Invalid server websocket URL",
                            recoverable = true,
                        )
                }
                ioScope.launch(SilentHandler) { stopTogetherInternal() }
                return@launch
            }

            client.connect(
                wsUrl = wsUrl,
                sessionId = resolved.sessionId,
                sessionKey = resolved.guestKey,
                displayName = displayName.trim().ifBlank { getString(R.string.together_role_guest) },
            )
        }
    }

    fun leaveTogether() {
        ensureScopesActive()
        scope.launch(SilentHandler) {
            togetherSessionState.value = moe.rukamori.archivetune.together.TogetherSessionState.Idle
        }
        ioScope.launch(SilentHandler) { stopTogetherInternal() }
    }

    fun updateTogetherSettings(settings: moe.rukamori.archivetune.together.TogetherRoomSettings) {
        val server = togetherServer
        val onlineHost = togetherOnlineHost
        if (server == null && onlineHost == null) return
        ioScope.launch(SilentHandler) {
            server?.updateSettings(settings)
            onlineHost?.updateSettings(settings)
        }
    }

    fun approveTogetherParticipant(
        participantId: String,
        approved: Boolean,
    ) {
        val server = togetherServer
        val onlineHost = togetherOnlineHost
        if (server == null && onlineHost == null) return
        ioScope.launch(SilentHandler) {
            server?.approveParticipant(participantId, approved)
            onlineHost?.approveParticipant(participantId, approved)
        }
    }

    fun kickTogetherParticipant(
        participantId: String,
        reason: String? = null,
    ) {
        val onlineHost = togetherOnlineHost ?: return
        ioScope.launch(SilentHandler) {
            onlineHost.kickParticipant(participantId, reason)
        }
    }

    fun banTogetherParticipant(
        participantId: String,
        reason: String? = null,
    ) {
        val onlineHost = togetherOnlineHost ?: return
        ioScope.launch(SilentHandler) {
            onlineHost.banParticipant(participantId, reason)
        }
    }

    fun transferTogetherHostOwnership(participantId: String) {
        val targetId = participantId.trim()
        if (targetId.isBlank() || targetId == togetherHostId || targetId == togetherSelfParticipantId) return
        val server = togetherServer
        val onlineHost = togetherOnlineHost
        val client = togetherClient
        val joined = togetherSessionState.value as? moe.rukamori.archivetune.together.TogetherSessionState.Joined
        ioScope.launch(SilentHandler) {
            when {
                server != null -> {
                    server.transferHostOwnership(targetId)
                }

                onlineHost != null -> {
                    onlineHost.transferHostOwnership(targetId)
                }

                joined?.role is moe.rukamori.archivetune.together.TogetherRole.Host && client != null -> {
                    client.transferHostOwnership(joined.sessionId, targetId)
                }
            }
        }
    }

    fun requestTogetherControl(action: moe.rukamori.archivetune.together.ControlAction) {
        val client =
            togetherClient ?: run {
                showTogetherNotice(getString(R.string.network_unavailable), key = "TOGETHER_CLIENT_MISSING")
                return
            }
        val state = togetherSessionState.value as? moe.rukamori.archivetune.together.TogetherSessionState.Joined ?: return
        if (state.role !is moe.rukamori.archivetune.together.TogetherRole.Guest) return
        if (!state.roomState.settings.allowGuestsToControlPlayback) {
            Timber.tag("Together").i("control blocked locally (disabled) action=${action::class.java.simpleName}")
            showTogetherNotice(getString(R.string.not_allowed), key = "GUEST_CONTROL_DISABLED_LOCAL")
            return
        }
        val now = android.os.SystemClock.elapsedRealtime()
        val lastAction = togetherLastSentControlAction
        val lastAt = togetherLastSentControlAtElapsedMs
        if (lastAction == action && now - lastAt < 350L) return
        togetherLastSentControlAction = action
        togetherLastSentControlAtElapsedMs = now

        val timeout = if (togetherIsOnlineSession) 5000L else 2000L
        togetherPendingGuestControl =
            when (action) {
                moe.rukamori.archivetune.together.ControlAction.Play -> {
                    TogetherPendingGuestControl(desiredIsPlaying = true, requestedAtElapsedMs = now, expiresAtElapsedMs = now + timeout)
                }

                moe.rukamori.archivetune.together.ControlAction.Pause -> {
                    TogetherPendingGuestControl(desiredIsPlaying = false, requestedAtElapsedMs = now, expiresAtElapsedMs = now + timeout)
                }

                is moe.rukamori.archivetune.together.ControlAction.SeekToIndex -> {
                    TogetherPendingGuestControl(
                        desiredIndex = action.index.coerceAtLeast(0),
                        requestedAtElapsedMs = now,
                        expiresAtElapsedMs =
                            now + timeout,
                    )
                }

                is moe.rukamori.archivetune.together.ControlAction.SeekToTrack -> {
                    TogetherPendingGuestControl(
                        desiredTrackId = action.trackId.trim().ifBlank { null },
                        requestedAtElapsedMs = now,
                        expiresAtElapsedMs = now + timeout,
                    )
                }

                else -> {
                    togetherPendingGuestControl
                }
            }
        client.requestControl(state.sessionId, action)
    }

    fun requestTogetherAddTrack(
        track: moe.rukamori.archivetune.together.TogetherTrack,
        mode: moe.rukamori.archivetune.together.AddTrackMode,
    ) {
        val client = togetherClient ?: return
        val state = togetherSessionState.value as? moe.rukamori.archivetune.together.TogetherSessionState.Joined ?: return
        if (state.role !is moe.rukamori.archivetune.together.TogetherRole.Guest) return
        if (!state.roomState.settings.allowGuestsToAddTracks) {
            Timber.tag("Together").i("add blocked locally (disabled) mode=$mode trackId=${track.id}")
            showTogetherNotice(getString(R.string.not_allowed), key = "GUEST_ADD_DISABLED_LOCAL")
            return
        }
        client.requestAddTrack(state.sessionId, track, mode)
    }

    private suspend fun handleTogetherHostEvent(
        event: moe.rukamori.archivetune.together.TogetherServerEvent,
        currentSettings: suspend () -> moe.rukamori.archivetune.together.TogetherRoomSettings,
    ) {
        when (event) {
            is moe.rukamori.archivetune.together.TogetherServerEvent.ControlRequested -> {
                val settings = currentSettings()
                if (!settings.allowGuestsToControlPlayback) return
                applyHostControl(event.request.action)
            }

            is moe.rukamori.archivetune.together.TogetherServerEvent.AddTrackRequested -> {
                val settings = currentSettings()
                if (!settings.allowGuestsToAddTracks) return
                applyHostAddTrack(event.request.track, event.request.mode)
            }

            is moe.rukamori.archivetune.together.TogetherServerEvent.ParticipantJoined -> {
                val participant = event.participant
                if (!participant.isHost && !participant.isPending) {
                    togetherParticipantNames[participant.id] = participant.name
                    cancelTogetherHostInactivityTimeout()
                    showTogetherParticipantNotification(participant.name, joined = true)
                }
            }

            is moe.rukamori.archivetune.together.TogetherServerEvent.ParticipantLeft -> {
                val participantName =
                    togetherParticipantNames.remove(event.participantId)
                        ?: return
                showTogetherParticipantNotification(participantName, joined = false)
                if (togetherParticipantNames.isEmpty()) {
                    val sessionId =
                        when (val state = togetherSessionState.value) {
                            is moe.rukamori.archivetune.together.TogetherSessionState.Hosting -> {
                                state.sessionId
                            }

                            is moe.rukamori.archivetune.together.TogetherSessionState.HostingOnline -> {
                                state.sessionId
                            }

                            is moe.rukamori.archivetune.together.TogetherSessionState.Joined -> {
                                state.sessionId.takeIf {
                                    state.role is moe.rukamori.archivetune.together.TogetherRole.Host
                                }
                            }

                            else -> {
                                null
                            }
                        }
                    if (sessionId != null) {
                        scheduleTogetherHostInactivityTimeout(sessionId)
                    }
                }
            }

            is moe.rukamori.archivetune.together.TogetherServerEvent.HostTransferred -> {
                val currentState = togetherSessionState.value
                val sessionId =
                    when (currentState) {
                        is moe.rukamori.archivetune.together.TogetherSessionState.Hosting -> currentState.sessionId
                        is moe.rukamori.archivetune.together.TogetherSessionState.HostingOnline -> currentState.sessionId
                        is moe.rukamori.archivetune.together.TogetherSessionState.Joined -> currentState.sessionId
                        else -> null
                    }
                if (event.participantId == togetherHostId &&
                    togetherParticipantNames.isEmpty() &&
                    sessionId != null
                ) {
                    scheduleTogetherHostInactivityTimeout(sessionId)
                } else {
                    cancelTogetherHostInactivityTimeout()
                    togetherHostInactivityEndSession = null
                }
                handleTogetherHostTransferred(event.participantId)
            }

            is moe.rukamori.archivetune.together.TogetherServerEvent.RoomStateReceived -> {
                if (event.state.hostId != togetherHostId) {
                    togetherSelfParticipantId = togetherHostId
                    applyRemoteRoomState(event.state, force = true)
                }
            }

            is moe.rukamori.archivetune.together.TogetherServerEvent.Error -> {
                val current = togetherSessionState.value
                if (current is moe.rukamori.archivetune.together.TogetherSessionState.Idle) return
                togetherSessionState.value =
                    moe.rukamori.archivetune.together.TogetherSessionState.Error(
                        message = event.message,
                        recoverable = true,
                    )
                ioScope.launch(SilentHandler) { stopTogetherInternal() }
            }

            else -> {
                Unit
            }
        }
    }

    private suspend fun applyHostControl(action: moe.rukamori.archivetune.together.ControlAction) {
        withContext(Dispatchers.Main) {
            when (action) {
                moe.rukamori.archivetune.together.ControlAction.Play -> {
                    if (!player.playWhenReady) {
                        player.prepare()
                        player.playWhenReady = true
                    }
                }

                moe.rukamori.archivetune.together.ControlAction.Pause -> {
                    if (player.playWhenReady) {
                        player.playWhenReady = false
                    }
                }

                is moe.rukamori.archivetune.together.ControlAction.SeekTo -> {
                    player.seekTo(action.positionMs.coerceAtLeast(0L))
                    player.prepare()
                }

                moe.rukamori.archivetune.together.ControlAction.SkipNext -> {
                    if (player.hasNextMediaItem()) {
                        player.seekToNext()
                        player.prepare()
                        player.playWhenReady = true
                    }
                }

                moe.rukamori.archivetune.together.ControlAction.SkipPrevious -> {
                    if (player.hasPreviousMediaItem()) {
                        player.seekToPrevious()
                        player.prepare()
                        player.playWhenReady = true
                    }
                }

                is moe.rukamori.archivetune.together.ControlAction.SeekToTrack -> {
                    val trackId = action.trackId.trim()
                    if (trackId.isNotBlank()) {
                        val idx =
                            player.mediaItems.indexOfFirst {
                                val metaId = it.metadata?.id
                                it.mediaId == trackId || metaId == trackId
                            }
                        if (idx >= 0 && idx < player.mediaItemCount) {
                            player.seekTo(idx, action.positionMs.coerceAtLeast(0L))
                            player.prepare()
                        }
                    }
                }

                is moe.rukamori.archivetune.together.ControlAction.SeekToIndex -> {
                    val idx = action.index.coerceAtLeast(0)
                    if (idx < player.mediaItemCount) {
                        player.seekTo(idx, action.positionMs.coerceAtLeast(0L))
                        player.prepare()
                    }
                }

                is moe.rukamori.archivetune.together.ControlAction.SetRepeatMode -> {
                    if (player.repeatMode != action.repeatMode) {
                        player.repeatMode = action.repeatMode
                    }
                }

                is moe.rukamori.archivetune.together.ControlAction.SetShuffleEnabled -> {
                    if (player.shuffleModeEnabled != action.shuffleEnabled) {
                        player.shuffleModeEnabled = action.shuffleEnabled
                    }
                }
            }
        }
    }

    private suspend fun applyHostAddTrack(
        track: moe.rukamori.archivetune.together.TogetherTrack,
        mode: moe.rukamori.archivetune.together.AddTrackMode,
    ) {
        val mediaItem = track.toMediaMetadata().toMediaItem()
        withContext(Dispatchers.Main) {
            when (mode) {
                moe.rukamori.archivetune.together.AddTrackMode.PLAY_NEXT -> playNext(listOf(mediaItem))
                moe.rukamori.archivetune.together.AddTrackMode.ADD_TO_QUEUE -> addToQueue(listOf(mediaItem))
            }
        }
    }

    private suspend fun buildTogetherRoomState(
        sessionId: String,
        hostId: String,
    ): moe.rukamori.archivetune.together.TogetherRoomState =
        withContext(Dispatchers.Main) {
            val tracks =
                player.mediaItems.mapNotNull { it.metadata }.map { meta ->
                    moe.rukamori.archivetune.together.TogetherTrack(
                        id = meta.id,
                        title = meta.title,
                        artists = meta.artists.map { it.name },
                        durationSec = meta.duration,
                        thumbnailUrl = meta.thumbnailUrl,
                    )
                }

            val queueHash =
                moe.rukamori.archivetune.utils
                    .md5(tracks.joinToString(separator = "|") { it.id })

            moe.rukamori.archivetune.together.TogetherRoomState(
                sessionId = sessionId,
                hostId = hostId,
                settings =
                    moe.rukamori.archivetune.together
                        .TogetherRoomSettings(),
                participants = emptyList(),
                queue = tracks,
                queueHash = queueHash,
                currentIndex = player.currentMediaItemIndex.coerceAtLeast(0),
                isPlaying = player.playWhenReady && player.playbackState != Player.STATE_ENDED,
                positionMs = player.currentPosition.coerceAtLeast(0L),
                repeatMode = player.repeatMode,
                shuffleEnabled = player.shuffleModeEnabled,
                sentAtElapsedRealtimeMs = android.os.SystemClock.elapsedRealtime(),
            )
        }

    private fun markTogetherHostParticipant(
        state: moe.rukamori.archivetune.together.TogetherRoomState,
        hostId: String,
    ): moe.rukamori.archivetune.together.TogetherRoomState =
        state.copy(
            hostId = hostId,
            participants =
                state.participants.map { participant ->
                    participant.copy(isHost = participant.id == hostId)
                },
        )

    private fun handleTogetherHostTransferred(participantId: String) {
        togetherAuthorityParticipantId = participantId
        if (participantId != togetherHostId) {
            togetherSelfParticipantId = togetherHostId
        }
        scope.launch(SilentHandler) {
            when (val current = togetherSessionState.value) {
                is moe.rukamori.archivetune.together.TogetherSessionState.Hosting -> {
                    val roomState = current.roomState?.let { markTogetherHostParticipant(it, participantId) }
                    togetherSessionState.value =
                        moe.rukamori.archivetune.together.TogetherSessionState.Joined(
                            role =
                                if (participantId == togetherHostId) {
                                    moe.rukamori.archivetune.together.TogetherRole.Host
                                } else {
                                    moe.rukamori.archivetune.together.TogetherRole.Guest
                                },
                            sessionId = current.sessionId,
                            selfParticipantId = togetherHostId,
                            roomState =
                                roomState
                                    ?: moe.rukamori.archivetune.together.TogetherRoomState(
                                        sessionId = current.sessionId,
                                        hostId = participantId,
                                    ),
                        )
                }

                is moe.rukamori.archivetune.together.TogetherSessionState.HostingOnline -> {
                    val roomState = current.roomState?.let { markTogetherHostParticipant(it, participantId) }
                    togetherSessionState.value =
                        moe.rukamori.archivetune.together.TogetherSessionState.Joined(
                            role =
                                if (participantId == togetherHostId) {
                                    moe.rukamori.archivetune.together.TogetherRole.Host
                                } else {
                                    moe.rukamori.archivetune.together.TogetherRole.Guest
                                },
                            sessionId = current.sessionId,
                            selfParticipantId = togetherHostId,
                            roomState =
                                roomState
                                    ?: moe.rukamori.archivetune.together.TogetherRoomState(
                                        sessionId = current.sessionId,
                                        hostId = participantId,
                                    ),
                        )
                }

                is moe.rukamori.archivetune.together.TogetherSessionState.Joined -> {
                    togetherSessionState.value =
                        current.copy(
                            role =
                                if (current.selfParticipantId == participantId) {
                                    moe.rukamori.archivetune.together.TogetherRole.Host
                                } else {
                                    moe.rukamori.archivetune.together.TogetherRole.Guest
                                },
                            roomState = markTogetherHostParticipant(current.roomState, participantId),
                        )
                }

                else -> {
                    Unit
                }
            }
        }
    }

    private fun handleTogetherClientHostTransferred(transfer: moe.rukamori.archivetune.together.HostTransferred) {
        val participantId = transfer.participantId
        handleTogetherHostTransferred(participantId)
        val client = togetherClient ?: return
        if (participantId != togetherSelfParticipantId) return
        startTogetherAuthorityBroadcast(transfer.sessionId, participantId, client)
    }

    private fun startTogetherAuthorityBroadcast(
        sessionId: String,
        participantId: String,
        client: moe.rukamori.archivetune.together.TogetherClient,
    ) {
        togetherBroadcastJob?.cancel()
        togetherBroadcastJob =
            ioScope.launch(SilentHandler) {
                while (togetherClient === client && togetherAuthorityParticipantId == participantId) {
                    val state = buildTogetherRoomState(sessionId = sessionId, hostId = participantId)
                    client.sendRoomState(state)
                    kotlinx.coroutines.delay(TogetherPlaybackSync.BroadcastIntervalMs)
                }
            }
    }

    private fun restoreTogetherGuestPlayback() {
        scope.launch(SilentHandler) {
            val joined = togetherSessionState.value as? moe.rukamori.archivetune.together.TogetherSessionState.Joined
            if (joined?.role is moe.rukamori.archivetune.together.TogetherRole.Guest && !isTogetherApplyingRemote()) {
                applyRemoteRoomState(joined.roomState, force = true)
            }
        }
    }

    private suspend fun applyRemoteRoomState(
        state: moe.rukamori.archivetune.together.TogetherRoomState,
        force: Boolean = false,
    ) = withContext(Dispatchers.Main) {
        val pid = togetherSelfParticipantId ?: return@withContext
        val now = android.os.SystemClock.elapsedRealtime()

        val pending = togetherPendingGuestControl
        if (force) {
            togetherPendingGuestControl = null
        } else if (pending != null) {
            val currentTrackId = state.queue.getOrNull(state.currentIndex.coerceAtLeast(0))?.id
            val mismatch =
                (pending.desiredIsPlaying != null && state.isPlaying != pending.desiredIsPlaying) ||
                    (pending.desiredIndex != null && state.currentIndex != pending.desiredIndex) ||
                    (pending.desiredTrackId != null && currentTrackId != pending.desiredTrackId)
            if (now >= pending.expiresAtElapsedMs) {
                if ((pending.desiredIndex != null || pending.desiredTrackId != null) &&
                    now - pending.requestedAtElapsedMs >= 1200L &&
                    mismatch
                ) {
                    showTogetherNotice(getString(R.string.together_song_change_failed), key = "GUEST_SEEK_TIMEOUT")
                }
                togetherPendingGuestControl = null
            } else {
                if (mismatch) return@withContext
                togetherPendingGuestControl = null
            }
        }

        val sentAt = state.sentAtElapsedRealtimeMs
        if (TogetherPlaybackSync.isStaleRoomState(
                sentAtElapsedRealtimeMs = sentAt,
                lastAppliedSentAtElapsedRealtimeMs = togetherLastAppliedRoomStateSentAtElapsedMs,
                force = force,
            )
        ) {
            return@withContext
        }

        val targetPos =
            TogetherPlaybackSync.targetPositionMs(
                state = state,
                isOnlineSession = togetherIsOnlineSession,
                clockSnapshot = if (togetherIsOnlineSession) null else togetherClock?.snapshot(),
                nowElapsedRealtimeMs = now,
            )

        togetherApplyingRemote = true
        togetherSuppressEchoUntilElapsedMs =
            TogetherPlaybackSync.echoSuppressionUntil(
                android.os.SystemClock.elapsedRealtime(),
            )
        try {
            val desiredItems = state.queue.map { it.toMediaMetadata().toMediaItem().withQueueEntry(recommended = false) }
            val desiredIds = state.queue.map { it.id }
            val desiredHash = state.queueHash
            val localIds = player.mediaItems.mapNotNull { it.metadata?.id ?: it.mediaId }.filter { it.isNotBlank() }
            val localHash =
                if (localIds.isEmpty()) {
                    ""
                } else {
                    moe.rukamori.archivetune.utils
                        .md5(localIds.joinToString(separator = "|"))
                }
            val needsRebuild =
                TogetherPlaybackSync.needsQueueRebuild(
                    desiredHash = desiredHash,
                    desiredIds = desiredIds,
                    localHash = localHash,
                    localIds = localIds,
                )

            if (desiredItems.isNotEmpty() && needsRebuild) {
                initialQueueJob?.cancel()
                cancelInfiniteQueueBootstrap()
                queuePageJob?.cancel()
                queuePageJob = null
                resetQueueRecommendations()
                togetherLastAppliedQueueHash = desiredHash.ifBlank { localHash }
                val startIndex = state.currentIndex.coerceIn(0, desiredItems.lastIndex)
                suppressAutoPlayback = false
                currentQueue =
                    moe.rukamori.archivetune.playback.queues.ListQueue(
                        title = getString(R.string.music_player),
                        items = desiredItems,
                        startIndex = startIndex,
                        position = targetPos,
                    )
                queueTitle = null
                player.setMediaItems(desiredItems, startIndex, targetPos)
                player.prepare()
                player.repeatMode = state.repeatMode
                player.shuffleModeEnabled = state.shuffleEnabled
                player.playWhenReady = state.isPlaying
                togetherLastRemoteAppliedIndex = startIndex
            } else {
                val index =
                    if (player.mediaItemCount > 0) {
                        state.currentIndex.coerceIn(0, player.mediaItemCount - 1)
                    } else {
                        0
                    }
                val indexChanged = player.mediaItemCount > 0 && index != player.currentMediaItemIndex

                if (indexChanged) {
                    if (player.repeatMode != state.repeatMode) player.repeatMode = state.repeatMode
                    if (player.shuffleModeEnabled != state.shuffleEnabled) player.shuffleModeEnabled = state.shuffleEnabled
                    player.seekTo(index, targetPos)
                    player.prepare()
                    player.playWhenReady = state.isPlaying
                } else {
                    val playbackStateChanged = player.playWhenReady != state.isPlaying
                    if (player.repeatMode != state.repeatMode) player.repeatMode = state.repeatMode
                    if (player.shuffleModeEnabled != state.shuffleEnabled) player.shuffleModeEnabled = state.shuffleEnabled
                    if (playbackStateChanged) player.playWhenReady = state.isPlaying
                    val shouldSeekForDrift =
                        TogetherPlaybackSync.shouldSeekForDrift(
                            currentPositionMs = player.currentPosition,
                            targetPositionMs = targetPos,
                            isPlaying = state.isPlaying,
                            isOnlineSession = togetherIsOnlineSession,
                        )
                    if (shouldSeekForDrift || (playbackStateChanged && !state.isPlaying)) {
                        player.seekTo(targetPos)
                        player.prepare()
                    }
                }
                togetherLastRemoteAppliedIndex = index
            }
            togetherLastRemoteAppliedPlayWhenReady = state.isPlaying
            togetherLastAppliedRoomStateSentAtElapsedMs = sentAt

            togetherSessionState.value =
                moe.rukamori.archivetune.together.TogetherSessionState.Joined(
                    role = moe.rukamori.archivetune.together.TogetherRole.Guest,
                    sessionId = state.sessionId,
                    selfParticipantId = pid,
                    roomState = state,
                )
        } finally {
            togetherApplyingRemote = false
        }
    }

    private fun startTogetherHeartbeat(
        sessionId: String,
        client: moe.rukamori.archivetune.together.TogetherClient,
    ) {
        togetherHeartbeatJob?.cancel()
        togetherHeartbeatJob =
            ioScope.launch(SilentHandler) {
                var pingId = 0L
                while (togetherClient === client) {
                    val now = android.os.SystemClock.elapsedRealtime()
                    client.sendHeartbeat(sessionId = sessionId, pingId = pingId++, clientElapsedRealtimeMs = now)
                    kotlinx.coroutines.delay(2000)
                }
            }
    }

    private suspend fun stopTogetherInternal() {
        cancelTogetherHostInactivityTimeout()
        togetherHostInactivityEndSession = null

        togetherBroadcastJob?.cancel()
        togetherBroadcastJob = null

        togetherOnlineConnectJob?.cancel()
        togetherOnlineConnectJob = null

        togetherClientEventsJob?.cancel()
        togetherClientEventsJob = null

        togetherHeartbeatJob?.cancel()
        togetherHeartbeatJob = null

        togetherClock = null
        togetherSelfParticipantId = null
        togetherAuthorityParticipantId = null
        togetherParticipantNames.clear()
        togetherLastAppliedQueueHash = null
        togetherIsOnlineSession = false
        togetherApplyingRemote = false
        togetherSuppressEchoUntilElapsedMs = 0L
        togetherLastAppliedRoomStateSentAtElapsedMs = 0L
        togetherLastRemoteAppliedPlayWhenReady = null
        togetherLastRemoteAppliedIndex = -1
        togetherLastSentControlAtElapsedMs = 0L
        togetherLastSentControlAction = null
        togetherPendingGuestControl = null

        try {
            togetherClient?.disconnect()
        } catch (_: Exception) {
        }
        togetherClient = null

        try {
            togetherOnlineHost?.disconnect()
        } catch (_: Exception) {
        }
        togetherOnlineHost = null

        try {
            togetherServer?.stop()
        } catch (_: Exception) {
        }
        togetherServer = null
    }

    private fun moe.rukamori.archivetune.together.TogetherTrack.toMediaMetadata(): moe.rukamori.archivetune.models.MediaMetadata =
        moe.rukamori.archivetune.models.MediaMetadata(
            id = id,
            title = title,
            artists =
                artists.map { name ->
                    moe.rukamori.archivetune.models.MediaMetadata
                        .Artist(id = null, name = name)
                },
            duration = durationSec,
            thumbnailUrl = thumbnailUrl,
            album = null,
            setVideoId = null,
            explicit = false,
            liked = false,
            likedDate = null,
            inLibrary = null,
        )

    private fun getLocalIpv4Address(): String? =
        runCatching {
            java.net.NetworkInterface
                .getNetworkInterfaces()
                .toList()
                .asSequence()
                .filter { it.isUp && !it.isLoopback }
                .flatMap { it.inetAddresses.toList().asSequence() }
                .filterIsInstance<java.net.Inet4Address>()
                .map { it.hostAddress }
                .firstOrNull { it.isNotBlank() && it != "127.0.0.1" }
        }.getOrNull()

    private fun toggleLibrary() {
        database.query {
            currentSong.value?.let {
                update(it.song.toggleLibrary())
            }
        }
    }

    fun toggleLike() {
        val mediaMetadata = currentMediaMetadata.value ?: return
        ioScope.launch {
            try {
                val result =
                    toggleLikeMutex.withLock {
                        val requestedSong =
                            database.withTransaction {
                                val currentSongEntity =
                                    getSongById(mediaMetadata.id)
                                        ?: run {
                                            insert(mediaMetadata) {
                                                it.copy(isLocal = mediaMetadata.id.isLocalMediaId())
                                            }
                                            getSongById(mediaMetadata.id)
                                        }
                                        ?: return@withTransaction null
                                currentSongEntity.song.toggleLike()
                            } ?: return@withLock null
                        syncUtils.likeSong(requestedSong)
                    } ?: return@launch
                val song =
                    result.getOrElse { error ->
                        reportException(error)
                        withContext(Dispatchers.Main) {
                            Toast.makeText(this@MusicService, R.string.error_unknown, Toast.LENGTH_SHORT).show()
                        }
                        return@launch
                    }

                // Check if auto-download on like is enabled and the song is now liked
                if (!song.isLocal && dataStore.get(AutoDownloadOnLikeKey, false) && song.liked) {
                    // Trigger download for the liked song
                    val downloadRequest =
                        androidx.media3.exoplayer.offline.DownloadRequest
                            .Builder(song.id, song.id.toUri())
                            .setCustomCacheKey(song.id)
                            .setData(song.title.toByteArray())
                            .build()
                    androidx.media3.exoplayer.offline.DownloadService.sendAddDownload(
                        this@MusicService,
                        ExoDownloadService::class.java,
                        downloadRequest,
                        false,
                    )
                }
            } catch (error: CancellationException) {
                throw error
            } catch (error: Exception) {
                reportException(error)
            }
        }
    }

    fun toggleStartRadio() {
        startRadioSeamlessly()
    }

    private fun decodeBandLevelsMb(raw: String?): List<Int> {
        if (raw.isNullOrBlank()) return emptyList()
        return runCatching { EqualizerJson.json.decodeFromString<List<Int>>(raw) }.getOrNull() ?: emptyList()
    }

    private fun encodeBandLevelsMb(levelsMb: List<Int>): String =
        runCatching {
            EqualizerJson.json.encodeToString(levelsMb)
        }.getOrNull().orEmpty()

    private fun readEqSettingsFromPrefs(prefs: Preferences): EqSettings {
        val levels = decodeBandLevelsMb(prefs[EqualizerBandLevelsMbKey])
        return EqSettings(
            enabled = prefs[EqualizerEnabledKey] ?: false,
            bandLevelsMb = levels,
            outputGainEnabled = prefs[EqualizerOutputGainEnabledKey] ?: false,
            outputGainMb = prefs[EqualizerOutputGainMbKey] ?: 0,
            bassBoostEnabled = prefs[EqualizerBassBoostEnabledKey] ?: false,
            bassBoostStrength = (prefs[EqualizerBassBoostStrengthKey] ?: 0).coerceIn(0, 1000),
            virtualizerEnabled = prefs[EqualizerVirtualizerEnabledKey] ?: false,
            virtualizerStrength = (prefs[EqualizerVirtualizerStrengthKey] ?: 0).coerceIn(0, 1000),
            autoHeadroomEnabled = prefs[EqualizerAutoHeadroomEnabledKey] ?: false,
        )
    }

    fun applyEqFlatPreset() {
        ioScope.launch {
            val caps = eqCapabilities.value
            val bandCount =
                caps?.bandCount ?: equalizer?.let { readAudioEffectValue("equalizer band count") { it.numberOfBands.toInt() } } ?: 0
            val encoded = encodeBandLevelsMb(List(bandCount.coerceAtLeast(0)) { 0 })
            dataStore.edit { prefs ->
                prefs[EqualizerEnabledKey] = true
                prefs[EqualizerBandLevelsMbKey] = encoded
                prefs[EqualizerSelectedProfileIdKey] = "flat"
            }
        }
    }

    fun applySystemEqPreset(presetIndex: Int) {
        scope.launch {
            ensureAudioEffects(localPlayer.audioSessionId)
            val eq = equalizer ?: return@launch
            val maxPreset = readAudioEffectValue("equalizer preset count") { eq.numberOfPresets.toInt() } ?: 0
            if (presetIndex !in 0 until maxPreset) return@launch

            runCatching { eq.usePreset(presetIndex.toShort()) }.getOrNull() ?: return@launch

            val bandCount = readAudioEffectValue("equalizer band count") { eq.numberOfBands.toInt() } ?: 0
            val levels =
                (0 until bandCount).map { band ->
                    readAudioEffectValue("equalizer band level for band $band") {
                        eq.getBandLevel(band.toShort()).toInt()
                    } ?: 0
                }

            val encoded = encodeBandLevelsMb(levels)
            if (encoded.isBlank()) return@launch

            ioScope.launch {
                dataStore.edit { prefs ->
                    prefs[EqualizerEnabledKey] = true
                    prefs[EqualizerBandLevelsMbKey] = encoded
                    prefs[EqualizerSelectedProfileIdKey] = "system:$presetIndex"
                }
            }
        }
    }

    private fun resampleLevelsByIndex(
        levelsMb: List<Int>,
        targetCount: Int,
    ): List<Int> {
        if (targetCount <= 0) return emptyList()
        if (levelsMb.isEmpty()) return List(targetCount) { 0 }
        if (levelsMb.size == targetCount) return levelsMb
        if (targetCount == 1) return listOf(levelsMb.sum() / levelsMb.size)

        val lastIndex = levelsMb.lastIndex.toFloat().coerceAtLeast(1f)
        return List(targetCount) { i ->
            val pos = i.toFloat() * lastIndex / (targetCount - 1).toFloat()
            val lo =
                kotlin.math
                    .floor(pos)
                    .toInt()
                    .coerceIn(0, levelsMb.lastIndex)
            val hi =
                kotlin.math
                    .ceil(pos)
                    .toInt()
                    .coerceIn(0, levelsMb.lastIndex)
            val t = (pos - lo.toFloat()).coerceIn(0f, 1f)
            val a = levelsMb[lo]
            val b = levelsMb[hi]
            (a + ((b - a) * t)).toInt()
        }
    }

    private inline fun <T> readAudioEffectValue(
        operation: String,
        block: () -> T,
    ): T? =
        runCatching(block)
            .onFailure { error ->
                Timber.tag("MusicService").w(error, "Audio effect query failed: %s", operation)
            }.getOrNull()

    private fun updateEqCapabilitiesFromEffect(eq: Equalizer) {
        val bandCount = readAudioEffectValue("equalizer band count") { eq.numberOfBands.toInt().coerceAtLeast(0) } ?: 0
        val range = readAudioEffectValue("equalizer band range") { eq.bandLevelRange }
        val minMb = range?.getOrNull(0)?.toInt() ?: -1500
        val maxMb = range?.getOrNull(1)?.toInt() ?: 1500
        val center =
            (0 until bandCount).map { band ->
                (
                    readAudioEffectValue("equalizer center frequency for band $band") {
                        eq.getCenterFreq(band.toShort())
                    } ?: 0
                ) / 1000
            }
        val presetCount = readAudioEffectValue("equalizer preset count") { eq.numberOfPresets.toInt().coerceAtLeast(0) } ?: 0
        val presets =
            (0 until presetCount).map { idx ->
                readAudioEffectValue("equalizer preset name for preset $idx") {
                    eq.getPresetName(idx.toShort()).toString()
                } ?: "Preset ${idx + 1}"
            }
        val capabilities =
            EqCapabilities(
                bandCount = bandCount,
                minBandLevelMb = minMb,
                maxBandLevelMb = maxMb,
                centerFreqHz = center,
                systemPresets = presets,
            )
        eqCapabilities.value = capabilities
        equalizerPlaybackController.updateCapabilities(capabilities)
    }

    private fun releaseAudioEffectInstances() {
        audioEffectsSessionId = null
        try {
            equalizer?.release()
        } catch (_: Exception) {
        }
        try {
            bassBoost?.release()
        } catch (_: Exception) {
        }
        try {
            virtualizer?.release()
        } catch (_: Exception) {
        }
        try {
            loudnessEnhancer?.release()
        } catch (_: Exception) {
        }
        equalizer = null
        bassBoost = null
        virtualizer = null
        loudnessEnhancer = null
        eqCapabilities.value = null
        equalizerPlaybackController.updateCapabilities(null)
    }

    private fun releaseAudioEffects() {
        audioEffectsInitializationJob?.cancel()
        audioEffectsInitializationJob = null
        releaseAudioEffectInstances()
    }

    private fun ensureAudioEffects(sessionId: Int) {
        if (sessionId <= 0) return
        if (audioEffectsSessionId == sessionId && equalizer != null) return

        audioEffectsInitializationJob?.cancel()
        audioEffectsInitializationJob = null
        if (initializeAudioEffects(sessionId)) return

        audioEffectsInitializationJob =
            scope.launch {
                repeat(AUDIO_EFFECT_INITIALIZATION_MAX_ATTEMPTS - 1) {
                    delay(AUDIO_EFFECT_INITIALIZATION_RETRY_DELAY_MS)
                    if (localPlayer.audioSessionId != sessionId || !shouldKeepAudioEffectSessionOpen()) {
                        return@launch
                    }
                    if (initializeAudioEffects(sessionId)) return@launch
                }
            }
    }

    private fun initializeAudioEffects(sessionId: Int): Boolean {
        releaseAudioEffectInstances()
        audioEffectsSessionId = sessionId

        equalizer = createAudioEffect("Equalizer", sessionId) { Equalizer(0, sessionId) }
        bassBoost = createAudioEffect("BassBoost", sessionId) { BassBoost(0, sessionId) }
        virtualizer = createAudioEffect("Virtualizer", sessionId) { Virtualizer(0, sessionId) }
        loudnessEnhancer = createAudioEffect("LoudnessEnhancer", sessionId) { LoudnessEnhancer(sessionId) }

        equalizer?.let(::updateEqCapabilitiesFromEffect)
        applyEqSettingsToEffects(desiredEqSettings.value)
        return equalizer != null
    }

    private inline fun <T> createAudioEffect(
        name: String,
        sessionId: Int,
        factory: () -> T,
    ): T? =
        runCatching(factory)
            .onFailure { error ->
                Timber.tag(TAG).w(error, "%s initialization failed for audio session %d", name, sessionId)
            }.getOrNull()

    private fun applyEqSettingsToEffects(settings: EqSettings) {
        val eq = equalizer ?: return
        val caps = eqCapabilities.value
        val bandCount = caps?.bandCount ?: readAudioEffectValue("equalizer band count") { eq.numberOfBands.toInt() } ?: 0
        val minMb =
            caps?.minBandLevelMb ?: readAudioEffectValue("equalizer minimum band level") { eq.bandLevelRange.getOrNull(0)?.toInt() }
                ?: -1500
        val maxMb =
            caps?.maxBandLevelMb ?: readAudioEffectValue("equalizer maximum band level") { eq.bandLevelRange.getOrNull(1)?.toInt() } ?: 1500

        val levels = resampleLevelsByIndex(settings.bandLevelsMb, bandCount)
        runCatching { eq.enabled = settings.enabled }

        for (band in 0 until bandCount) {
            val levelMb = levels.getOrNull(band)?.coerceIn(minMb, maxMb) ?: 0
            runCatching { eq.setBandLevel(band.toShort(), levelMb.toShort()) }
        }

        bassBoost?.let { bb ->
            runCatching { bb.enabled = settings.enabled && settings.bassBoostEnabled }
            runCatching { bb.setStrength(settings.bassBoostStrength.toShort()) }
        }

        virtualizer?.let { v ->
            runCatching { v.enabled = settings.enabled && settings.virtualizerEnabled }
            runCatching { v.setStrength(settings.virtualizerStrength.toShort()) }
        }

        loudnessEnhancer?.let { le ->
            val automaticHeadroomMb = -(levels.maxOrNull()?.coerceAtLeast(0) ?: 0)
            val gainMb =
                when {
                    settings.autoHeadroomEnabled -> automaticHeadroomMb
                    settings.outputGainEnabled -> settings.outputGainMb.coerceIn(-1500, 1500)
                    else -> 0
                }
            runCatching { le.setTargetGain(gainMb) }
            runCatching { le.enabled = settings.enabled && (settings.autoHeadroomEnabled || settings.outputGainEnabled) }
        }
    }

    private fun shouldKeepAudioEffectSessionOpen(): Boolean {
        val playbackState = localPlayer.playbackState
        return playbackState == Player.STATE_BUFFERING || playbackState == Player.STATE_READY
    }

    private fun reconcileAudioEffectSession() {
        if (!shouldKeepAudioEffectSessionOpen()) {
            closeAudioEffectSession()
            return
        }

        val sessionId = localPlayer.audioSessionId
        if (sessionId > 0) {
            rebindAudioEffectSession(sessionId)
        }
    }

    private fun openAudioEffectSession() {
        if (isAudioEffectSessionOpened) return
        val sessionId = localPlayer.audioSessionId
        if (sessionId <= 0) return
        isAudioEffectSessionOpened = true
        openedAudioSessionId = sessionId
        ensureAudioEffects(sessionId)
        sendOpenAudioEffectSessionBroadcast(sessionId)
    }

    private fun closeAudioEffectSession() {
        if (!isAudioEffectSessionOpened) return
        isAudioEffectSessionOpened = false
        val sessionId = openedAudioSessionId ?: localPlayer.audioSessionId
        openedAudioSessionId = null
        releaseAudioEffects()
        if (sessionId <= 0) return
        sendCloseAudioEffectSessionBroadcast(sessionId)
    }

    private fun rebindAudioEffectSession(newSessionId: Int) {
        if (newSessionId <= 0 || !shouldKeepAudioEffectSessionOpen()) return
        val oldSessionId = openedAudioSessionId
        if (!isAudioEffectSessionOpened) {
            openAudioEffectSession()
            return
        }
        if (oldSessionId == newSessionId) {
            ensureAudioEffects(newSessionId)
            return
        }

        if (oldSessionId != null && oldSessionId > 0) {
            sendCloseAudioEffectSessionBroadcast(oldSessionId)
        }
        openedAudioSessionId = newSessionId
        ensureAudioEffects(newSessionId)
        sendOpenAudioEffectSessionBroadcast(newSessionId)
    }

    private fun sendOpenAudioEffectSessionBroadcast(sessionId: Int) {
        sendBroadcast(
            Intent(AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION).apply {
                putExtra(AudioEffect.EXTRA_AUDIO_SESSION, sessionId)
                putExtra(AudioEffect.EXTRA_PACKAGE_NAME, packageName)
                putExtra(AudioEffect.EXTRA_CONTENT_TYPE, AudioEffect.CONTENT_TYPE_MUSIC)
            },
        )
    }

    private fun sendCloseAudioEffectSessionBroadcast(sessionId: Int) {
        sendBroadcast(
            Intent(AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION).apply {
                putExtra(AudioEffect.EXTRA_AUDIO_SESSION, sessionId)
                putExtra(AudioEffect.EXTRA_PACKAGE_NAME, packageName)
            },
        )
    }

    private fun historyThresholdMs(): Long =
        (runCatching { dataStore[HistoryDuration] }.getOrNull() ?: HISTORY_DURATION_DEFAULT)
            .coerceIn(HISTORY_DURATION_MIN, HISTORY_DURATION_MAX)
            .toLong() * 1000L

    private fun currentHistoryPlayedMs(nowElapsedMs: Long = android.os.SystemClock.elapsedRealtime()): Long {
        val runningPlayMs =
            currentHistoryStartedAtElapsedMs
                ?.let { (nowElapsedMs - it).coerceAtLeast(0L) }
                ?: 0L
        return currentHistoryAccumulatedPlayMs + runningPlayMs
    }

    private fun flushCurrentHistoryPlayedTime(nowElapsedMs: Long = android.os.SystemClock.elapsedRealtime()) {
        currentHistoryAccumulatedPlayMs = currentHistoryPlayedMs(nowElapsedMs)
        currentHistoryStartedAtElapsedMs = null
    }

    private fun updatePendingHistoryFinalization(
        mediaId: String,
        sessionToken: Long,
        result: ImmediateHistoryResult,
    ) {
        val pendingSessions = pendingHistoryFinalizations[mediaId] ?: return
        val index = pendingSessions.indexOfFirst { it.sessionToken == sessionToken }
        if (index == -1) return

        val existing = pendingSessions[index]
        pendingSessions[index] =
            existing.copy(
                eventId = result.eventId ?: existing.eventId,
                remoteRegistered = existing.remoteRegistered || result.remoteRegistered,
            )
    }

    private fun enqueueCurrentHistorySessionForFinalization() {
        val mediaId = currentHistoryMediaId ?: return
        if (currentHistorySessionQueued) return

        pendingHistoryFinalizations
            .getOrPut(mediaId) { mutableListOf() }
            .add(
                PendingHistoryFinalization(
                    sessionToken = currentHistorySessionToken,
                    eventId = currentHistoryEventId,
                    remoteRegistered = currentHistoryRemoteRegistered,
                ),
            )
        currentHistorySessionQueued = true
    }

    private fun popPendingHistoryFinalization(mediaId: String): PendingHistoryFinalization? {
        val pendingSessions = pendingHistoryFinalizations[mediaId] ?: return null
        val pending = pendingSessions.firstOrNull() ?: return null
        pendingSessions.removeAt(0)
        if (pendingSessions.isEmpty()) {
            pendingHistoryFinalizations.remove(mediaId)
        }
        return pending
    }

    private fun beginHistorySession(
        mediaId: String?,
        forceNew: Boolean = false,
    ) {
        val normalizedMediaId = mediaId?.trim()?.takeIf { it.isNotEmpty() }
        if (!forceNew && currentHistoryMediaId == normalizedMediaId && currentHistorySessionToken != 0L) {
            updateHistoryTrackingPlaybackState()
            return
        }

        historyThresholdJob?.cancel()
        historyThresholdJob = null
        flushCurrentHistoryPlayedTime()
        enqueueCurrentHistorySessionForFinalization()

        currentHistorySessionToken = ++nextHistorySessionToken
        currentHistoryMediaId = normalizedMediaId
        currentHistoryAccumulatedPlayMs = 0L
        currentHistoryStartedAtElapsedMs = null
        currentHistoryEventId = null
        currentHistoryRemoteRegistered = false
        currentHistoryImmediateAttempted = false
        currentHistorySessionQueued = false

        updateHistoryTrackingPlaybackState()
    }

    private fun updateHistoryTrackingPlaybackState() {
        val mediaId = currentHistoryMediaId
        if (mediaId == null || currentHistorySessionQueued) {
            historyThresholdJob?.cancel()
            historyThresholdJob = null
            currentHistoryStartedAtElapsedMs = null
            return
        }

        if (player.isPlaying) {
            if (currentHistoryStartedAtElapsedMs == null) {
                currentHistoryStartedAtElapsedMs = android.os.SystemClock.elapsedRealtime()
            }
        } else {
            flushCurrentHistoryPlayedTime()
        }

        syncHistoryThresholdJob()
    }

    private fun syncHistoryThresholdJob() {
        historyThresholdJob?.cancel()
        historyThresholdJob = null

        val mediaId = currentHistoryMediaId ?: return
        if (currentHistorySessionQueued) return
        if (dataStore.get(PauseListenHistoryKey, false)) return
        if (currentHistoryEventId != null && currentHistoryRemoteRegistered) return

        val thresholdMs = historyThresholdMs()
        val playedMs = currentHistoryPlayedMs()
        if (playedMs >= thresholdMs) {
            if (!currentHistoryImmediateAttempted) {
                maybeRecordCurrentPlaybackHistory()
            }
            return
        }
        if (!player.isPlaying) return

        historyThresholdJob =
            scope.launch {
                delay((thresholdMs - playedMs).coerceAtLeast(0L))
                maybeRecordCurrentPlaybackHistory()
            }
    }

    private fun maybeRecordCurrentPlaybackHistory() {
        val mediaId = currentHistoryMediaId ?: return
        if (currentHistorySessionQueued) return
        if (dataStore.get(PauseListenHistoryKey, false)) return

        val thresholdMs = historyThresholdMs()
        val playedMs = currentHistoryPlayedMs()
        if (playedMs < thresholdMs) {
            syncHistoryThresholdJob()
            return
        }

        val sessionToken = currentHistorySessionToken
        if (historyRecordingJobs.containsKey(sessionToken)) return
        currentHistoryImmediateAttempted = true

        val eventIdSnapshot = currentHistoryEventId
        val remoteRegisteredSnapshot = currentHistoryRemoteRegistered
        val mediaMetadataSnapshot = player.currentMetadata?.takeIf { it.id == mediaId }

        val deferred =
            scope.async {
                withContext(Dispatchers.IO) {
                    val resolvedEventId =
                        eventIdSnapshot
                            ?: insertPlaybackHistoryEvent(
                                mediaId = mediaId,
                                playTimeMs = playedMs,
                                mediaMetadata = mediaMetadataSnapshot,
                            )
                    val remoteRegistered = remoteRegisteredSnapshot || registerRemotePlaybackHistory(mediaId)
                    ImmediateHistoryResult(
                        eventId = resolvedEventId,
                        remoteRegistered = remoteRegistered,
                    )
                }
            }

        historyRecordingJobs[sessionToken] = deferred
        scope.launch {
            val result =
                runCatching { deferred.await() }
                    .onFailure(::reportException)
                    .getOrNull()

            historyRecordingJobs.remove(sessionToken)

            if (result != null) {
                if (currentHistorySessionToken == sessionToken &&
                    !currentHistorySessionQueued &&
                    currentHistoryMediaId == mediaId
                ) {
                    currentHistoryEventId = result.eventId ?: currentHistoryEventId
                    currentHistoryRemoteRegistered = currentHistoryRemoteRegistered || result.remoteRegistered
                } else {
                    updatePendingHistoryFinalization(mediaId, sessionToken, result)
                }
            }

            syncHistoryThresholdJob()
        }
    }

    private suspend fun insertPlaybackHistoryEvent(
        mediaId: String,
        playTimeMs: Long,
        mediaMetadata: moe.rukamori.archivetune.models.MediaMetadata?,
    ): Long? =
        try {
            database.withTransaction {
                if (song(mediaId).first() == null && mediaMetadata != null) {
                    insert(mediaMetadata)
                }

                insert(
                    Event(
                        songId = mediaId,
                        timestamp = LocalDateTime.now(),
                        playTime = playTimeMs,
                    ),
                ).takeIf { it > 0L }
            }
        } catch (_: SQLException) {
            null
        } catch (throwable: Throwable) {
            reportException(throwable)
            null
        }

    private suspend fun registerRemotePlaybackHistory(mediaId: String): Boolean {
        if (activeModuleAudio.containsKey(mediaId)) return false
        if (database
                .song(mediaId)
                .first()
                ?.song
                ?.isLocal == true
        ) {
            return false
        }

        suspend fun registerTracking(playbackTrackingUrl: String): Boolean =
            YouTube
                .registerPlayback(
                    playlistId = null,
                    playbackTracking = playbackTrackingUrl,
                ).onFailure { throwable ->
                    if (throwable is CancellationException) {
                        throw throwable
                    }
                    Timber.tag("MusicService").w(
                        throwable,
                        "Failed to register remote playback history for %s",
                        mediaId,
                    )
                }.onSuccess {
                    YouTube.notifyHistorySynced()
                }.isSuccess

        remotePlaybackTrackingUrlCache[mediaId]?.let { cachedPlaybackTrackingUrl ->
            if (registerTracking(cachedPlaybackTrackingUrl)) {
                return true
            }
            remotePlaybackTrackingUrlCache.remove(mediaId, cachedPlaybackTrackingUrl)
        }

        val remotePlaybackTracking =
            retryWithoutPlaybackLoginContext {
                YTPlayerUtils.playerResponseForMetadata(mediaId)
            }.onFailure { throwable ->
                if (throwable is CancellationException) {
                    throw throwable
                }
                when (throwable) {
                    is YTPlayerUtils.InvalidPlaybackLoginContextException -> {
                        promptLoginRecovery(mediaId, throwable.targetUrl)
                    }

                    is YTPlayerUtils.LoginRequiredForPlaybackException -> {
                        Timber.tag("MusicService").w(
                            throwable,
                            "Playback confirmation is required before refreshing remote playback tracking for %s",
                            mediaId,
                        )
                    }

                    else -> {
                        Timber.tag("MusicService").w(
                            throwable,
                            "Failed to refresh remote playback tracking for %s",
                            mediaId,
                        )
                    }
                }
            }.getOrNull()
                ?.playbackTracking

        val refreshedPlaybackTrackingUrl = remotePlaybackTracking?.remotePlaybackTrackingUrl()
        if (refreshedPlaybackTrackingUrl != null) {
            remotePlaybackTrackingUrlCache[mediaId] = refreshedPlaybackTrackingUrl
            return registerTracking(refreshedPlaybackTrackingUrl)
        }

        return false
    }

    override fun onMediaItemTransition(
        mediaItem: MediaItem?,
        reason: Int,
    ) {
        super.onMediaItemTransition(mediaItem, reason)

        if (sleepTimer.pauseWhenSongEnd) {
            pauseFromSleepTimer()
            return
        }

        crossfadeSuppressedMediaId = null

        beginHistorySession(mediaItem?.mediaId, forceNew = true)

        val joined = togetherSessionState.value as? moe.rukamori.archivetune.together.TogetherSessionState.Joined
        if (joined?.role is moe.rukamori.archivetune.together.TogetherRole.Guest &&
            reason == Player.MEDIA_ITEM_TRANSITION_REASON_SEEK &&
            !isTogetherApplyingRemote()
        ) {
            if (!joined.roomState.settings.allowGuestsToControlPlayback) {
                restoreTogetherGuestPlayback()
                return
            }
            val now = android.os.SystemClock.elapsedRealtime()
            val index = player.currentMediaItemIndex.coerceAtLeast(0)
            val isEcho =
                isTogetherApplyingRemote() ||
                    (now < togetherSuppressEchoUntilElapsedMs && togetherLastRemoteAppliedIndex == index)
            if (!isEcho) {
                val trackId = (mediaItem?.metadata ?: player.currentMetadata)?.id?.trim().orEmpty()
                requestTogetherControl(
                    if (trackId.isBlank()) {
                        moe.rukamori.archivetune.together.ControlAction.SeekToIndex(
                            index = index,
                            positionMs = player.currentPosition.coerceAtLeast(0L),
                        )
                    } else {
                        moe.rukamori.archivetune.together.ControlAction.SeekToTrack(
                            trackId = trackId,
                            positionMs = player.currentPosition.coerceAtLeast(0L),
                        )
                    },
                )
            }
        }

        if (recommendationRequest?.isActive == true && recommendationSeed != null &&
            recommendationSeed != mediaItem?.mediaId
        ) {
            recommendationGeneration++
            recommendationRequest?.cancel()
            recommendationRequest = null
            recommendationSeed = null
            queueRecommendations.value = queueRecommendations.value.copy(loading = false, pendingChipId = null)
        }

        val timelineEmpty = player.currentTimeline.isEmpty || player.mediaItemCount == 0 || player.currentMediaItem == null
        currentMediaMetadata.value = if (timelineEmpty) null else (mediaItem?.metadata ?: player.currentMetadata)

        widgetUpdater.update()

        scrobbleManager?.onSongStop()

        if (!suppressAutoPlayback &&
            !timelineEmpty &&
            currentMediaMetadata.value?.isPodcast != true &&
            dataStore.get(AutoLoadMoreKey, true) &&
            player.mediaItemCount - player.getCurrentQueueIndex() <= 5 &&
            currentQueue.hasNextPage() &&
            (!currentQueue.recommendationOnlyContinuation ||
                (reason != Player.MEDIA_ITEM_TRANSITION_REASON_REPEAT && player.repeatMode == REPEAT_MODE_OFF))
        ) {
            extendExplicitQueue()
        }

        if (!suppressAutoPlayback &&
            !timelineEmpty &&
            dataStore.get(AutoLoadMoreKey, true) &&
            reason != Player.MEDIA_ITEM_TRANSITION_REASON_REPEAT &&
            player.repeatMode == REPEAT_MODE_OFF &&
            player.mediaItemCount - player.currentMediaItemIndex <= 3 &&
            !currentQueue.hasNextPage()
        ) {
            onInfiniteQueueEnabled()
        }

        if (player.playWhenReady && player.playbackState == Player.STATE_READY && player.currentMetadata?.isPodcast != true) {
            scrobbleManager?.onSongStart(player.currentMetadata, duration = player.duration)
        }

        scope.launch {
            val shouldSave = withContext(Dispatchers.IO) { dataStore.get(PersistentQueueKey, true) }
            if (shouldSave) {
                saveQueueToDisk()
            }
        }
        ensurePresenceManager()
        scheduleCrossfade()
    }

    private fun isCurrentPlaybackItemLocal(currentMediaMetadata: MediaMetadata): Boolean =
        currentSong.value?.song?.isLocal == true ||
            currentMediaMetadata.id.trim().isLocalMediaId() ||
            player.currentMediaItem
                ?.localConfiguration
                ?.uri
                ?.shouldBypassPlayerCache() == true

    override fun onTracksChanged(tracks: Tracks) {
        val mediaId = player.currentMediaItem?.mediaId ?: return
        val selection = activeModuleAudio[mediaId] ?: return
        val sampleRate =
            tracks.groups
                .firstOrNull { it.type == C.TRACK_TYPE_AUDIO && it.isSelected }
                ?.takeIf { it.length > 0 }
                ?.getTrackFormat(0)
                ?.sampleRate
                ?.takeIf { it > 0 }
        ioScope.launch {
            val stored = database.getFormatByIdBlocking(mediaId) ?: return@launch
            if (sampleRate != null && stored.sampleRate == null) {
                database.updateLocalAudioMetadata(mediaId, stored.bitrate, sampleRate)
            }
            if (stored.contentLength <= 0) {
                val size = moduleStreamSize(selection)
                if (size > 0) database.updateFormatContentLength(mediaId, size)
            }
        }
    }

    private fun moduleStreamSize(selection: ModuleAudioSelection): Long {
        ContentMetadata
            .getContentLength(playerCache.getContentMetadata(selection.cacheKey))
            .takeIf { it > 0 }
            ?.let { return it }
        val completed =
            moduleDownloadUtil.downloadManager.downloadIndex
                .getDownload(selection.originalId)
                ?.state == androidx.media3.exoplayer.offline.Download.STATE_COMPLETED
        if (!completed) return 0
        return downloadCache.getCachedSpans(selection.cacheKey).sumOf { span -> span.length.coerceAtLeast(0L) }
    }

    override fun onPlaybackStateChanged(
        @Player.State playbackState: Int,
    ) {
        super.onPlaybackStateChanged(playbackState)

        updateHistoryTrackingPlaybackState()
        if (playbackState == Player.STATE_ENDED || playbackState == Player.STATE_IDLE) {
            enqueueCurrentHistorySessionForFinalization()
            cancelCrossfade(resetVolume = true)
            if (playbackState == Player.STATE_ENDED &&
                !suppressAutoPlayback &&
                player.currentMetadata?.isPodcast != true &&
                dataStore.get(AutoLoadMoreKey, true) &&
                player.repeatMode == REPEAT_MODE_OFF &&
                player.currentMediaItem != null
            ) {
                onInfiniteQueueEnabled()
            }
        } else if (playbackState == Player.STATE_READY) {
            scheduleCrossfade()
        }

        widgetUpdater.update()
        widgetUpdater.updateProgressTracking()

        scope.launch {
            val shouldSave = withContext(Dispatchers.IO) { dataStore.get(PersistentQueueKey, true) }
            if (shouldSave) {
                saveQueueToDisk()
            }
        }
    }

    override fun onPlayWhenReadyChanged(
        playWhenReady: Boolean,
        reason: Int,
    ) {
        super.onPlayWhenReadyChanged(playWhenReady, reason)
        scheduleCrossfade()
    }

    override fun onIsPlayingChanged(isPlaying: Boolean) {
        super.onIsPlayingChanged(isPlaying)
        if (isPlaying) {
            scheduleCrossfade()
        }
        updateAudiblePlaybackRecovery()

        widgetUpdater.update()
        widgetUpdater.updateProgressTracking()
    }

    private fun updateNextStreamPreload() {
        val configuration = playbackPreloadConfiguration
        if (configuration == null || !configuration.enabled || player.playbackState != Player.STATE_READY) {
            nextStreamPreloader.cancel()
            return
        }

        val nextMediaItemIndex = player.nextMediaItemIndex
        if (nextMediaItemIndex == C.INDEX_UNSET ||
            nextMediaItemIndex == player.currentMediaItemIndex ||
            nextMediaItemIndex !in 0 until player.mediaItemCount
        ) {
            nextStreamPreloader.cancel()
            return
        }

        val nextMediaItem = player.getMediaItemAt(nextMediaItemIndex)
        val nextMediaId =
            (nextMediaItem.localConfiguration?.customCacheKey ?: nextMediaItem.mediaId)
                .trim()
                .takeIf(String::isNotEmpty)
        val currentMediaId =
            player.currentMediaItem
                ?.let { mediaItem -> mediaItem.localConfiguration?.customCacheKey ?: mediaItem.mediaId }
                ?.trim()
                ?.takeIf(String::isNotEmpty)
        val nextUri = nextMediaItem.localConfiguration?.uri
        if (nextMediaId == null ||
            nextMediaId == currentMediaId ||
            nextMediaId.isLocalMediaId() ||
            nextUri == null ||
            nextUri.shouldBypassYouTubeResolver()
        ) {
            nextStreamPreloader.cancel()
            return
        }

        nextStreamPreloader.updateTarget(
            request =
                AudioStreamRequest(
                    mediaId = nextMediaId,
                    playlistId = null,
                    quality = configuration.quality,
                    networkMetered = false,
                    purpose = StreamPurpose.PLAYBACK,
                    authState = configuration.authState,
                    pinnedFormatId = null,
                    moduleMetadata = nextMediaItem.metadata?.moduleMatchMetadata(),
                ),
        )
    }

    override fun onEvents(
        player: Player,
        events: Player.Events,
    ) {
        if (events.containsAny(
                Player.EVENT_PLAYBACK_STATE_CHANGED,
                Player.EVENT_MEDIA_ITEM_TRANSITION,
                Player.EVENT_TIMELINE_CHANGED,
                Player.EVENT_SHUFFLE_MODE_ENABLED_CHANGED,
                Player.EVENT_REPEAT_MODE_CHANGED,
            )
        ) {
            updateNextStreamPreload()
        }
        val currentMediaId = player.currentMediaItem?.mediaId
        if (currentMediaId == null && currentHistoryMediaId != null) {
            beginHistorySession(null, forceNew = true)
        } else if (currentHistoryMediaId == null && currentMediaId != null) {
            beginHistorySession(currentMediaId)
        }
        if (player.playerError == null &&
            events.containsAny(Player.EVENT_MEDIA_ITEM_TRANSITION, Player.EVENT_POSITION_DISCONTINUITY)
        ) {
            playbackErrorRecoveryJob?.cancel()
            playbackErrorRecoveryJob = null
        }
        if (events.contains(Player.EVENT_MEDIA_ITEM_TRANSITION)) {
            playbackStreamRecoveryTracker.onMediaItemChanged(currentMediaId)
        }
        if (
            (events.contains(Player.EVENT_PLAYBACK_STATE_CHANGED) && player.playbackState == Player.STATE_READY) ||
            (events.contains(Player.EVENT_IS_PLAYING_CHANGED) && player.isPlaying)
        ) {
            if (player.isPlaying || (player.playbackState == Player.STATE_READY && !player.playWhenReady)) {
                playbackStreamRecoveryTracker.onPlaybackRecovered(currentMediaId)
            }
            ensureAudiblePlaybackVolume("player_event")
        }
        if (events.containsAny(
                Player.EVENT_PLAYBACK_STATE_CHANGED,
                Player.EVENT_PLAY_WHEN_READY_CHANGED,
                Player.EVENT_IS_PLAYING_CHANGED,
            )
        ) {
            updateAudiblePlaybackRecovery()
        }
        if (events.contains(Player.EVENT_MEDIA_METADATA_CHANGED)) {
            currentMediaMetadata.value = player.currentMetadata
        }
        if (events.containsAny(
                Player.EVENT_PLAYBACK_STATE_CHANGED,
                Player.EVENT_PLAY_WHEN_READY_CHANGED,
                Player.EVENT_IS_PLAYING_CHANGED,
            )
        ) {
            updateHistoryTrackingPlaybackState()
        }
        val joined = togetherSessionState.value as? moe.rukamori.archivetune.together.TogetherSessionState.Joined
        if (joined?.role is moe.rukamori.archivetune.together.TogetherRole.Guest &&
            events.contains(Player.EVENT_PLAY_WHEN_READY_CHANGED) &&
            !isTogetherApplyingRemote()
        ) {
            if (!joined.roomState.settings.allowGuestsToControlPlayback) {
                restoreTogetherGuestPlayback()
            } else {
                val now = android.os.SystemClock.elapsedRealtime()
                val playWhenReady = this.player.playWhenReady
                val isEcho =
                    isTogetherApplyingRemote() ||
                        (
                            now < togetherSuppressEchoUntilElapsedMs &&
                                togetherLastRemoteAppliedPlayWhenReady != null &&
                                togetherLastRemoteAppliedPlayWhenReady == playWhenReady
                        )
                if (!isEcho) {
                    val action =
                        if (playWhenReady) {
                            moe.rukamori.archivetune.together.ControlAction.Play
                        } else {
                            moe.rukamori.archivetune.together.ControlAction.Pause
                        }
                    requestTogetherControl(action)
                }
            }
        }
        if (events.contains(Player.EVENT_DEVICE_VOLUME_CHANGED)) {
            handleDeviceMuteStateChanged()
        }
        if (events.contains(Player.EVENT_PLAY_WHEN_READY_CHANGED) && isDeviceMutedNow() && this.player.playWhenReady) {
            handleDeviceMuteStateChanged(playbackRequestedWhileMuted = true)
        }
        if (events.contains(Player.EVENT_PLAYBACK_STATE_CHANGED) &&
            (this.player.playbackState == Player.STATE_IDLE || this.player.playbackState == Player.STATE_ENDED)
        ) {
            wasAutoPausedByDeviceMute = false
            unregisterMuteRecoveryObserver()
            updateAudiblePlaybackRecovery()
        }
        if (events.contains(Player.EVENT_PLAYBACK_STATE_CHANGED) &&
            isDeviceMutedNow() &&
            this.player.playWhenReady
        ) {
            handleDeviceMuteStateChanged(playbackRequestedWhileMuted = true)
        }
        if (events.containsAny(
                Player.EVENT_PLAYBACK_STATE_CHANGED,
                Player.EVENT_PLAY_WHEN_READY_CHANGED,
            )
        ) {
            if (player.playWhenReady && shouldKeepAudioEffectSessionOpen()) {
                ensureAudioFocusForActivePlayback()
            }
            updateWakeLock()
            if (player.playWhenReady) {
                ensureForegroundPlaybackService()
            }
            if (hasResumablePlaybackNotification()) {
                cancelIdleStop()
            } else {
                scheduleStopIfIdle()
            }
        }

        if (events.containsAny(EVENT_TIMELINE_CHANGED, EVENT_POSITION_DISCONTINUITY)) {
            currentMediaMetadata.value = player.currentMetadata
            requestDiscordSync(
                reason = "timeline_or_position_discontinuity",
                force = true,
            )
            val currentMediaId = player.currentMediaItem?.mediaId
            val currentMetadata = player.currentMetadata
            val currentDuration = player.duration
            val currentPosition = player.currentPosition
            scope.launch {
                try {
                    if (currentMetadata?.isPodcast == true) return@launch
                    val song = if (currentMediaId != null) withContext(Dispatchers.IO) { database.song(currentMediaId).first() } else null
                    val finalSong =
                        resolvePresenceSong(
                            dbSong = song,
                            mediaMetadata = currentMetadata,
                            durationMs = currentDuration,
                        ) ?: return@launch
                    try {
                        val lbEnabled = dataStore.get(ListenBrainzEnabledKey, false)
                        val lbToken = dataStore.get(ListenBrainzTokenKey, "")
                        val historyPaused = dataStore.get(PauseListenHistoryKey, false)
                        if (lbEnabled && !lbToken.isNullOrBlank() && !historyPaused) {
                            scope.launch(Dispatchers.IO) {
                                try {
                                    ListenBrainzManager.submitPlayingNow(
                                        this@MusicService,
                                        lbToken,
                                        finalSong,
                                        currentPosition,
                                    )
                                } catch (ie: Exception) {
                                    Timber.tag("MusicService").v(ie, "ListenBrainz playing_now submit failed on transition")
                                }
                            }
                        }

                        // Last.fm now playing - handled by ScrobbleManager
                    } catch (_: Exception) {
                    }
                } catch (e: Exception) {
                    Timber.tag("MusicService").v(e, "timeline/position follow-up work failed")
                }
            }
        }
        if (events.contains(EVENT_TIMELINE_CHANGED)) {
            scheduleCrossfade()
        }

        // Also handle immediate update for play state and media item transition events explicitly
        if (events.containsAny(
                Player.EVENT_PLAYBACK_STATE_CHANGED,
                Player.EVENT_PLAY_WHEN_READY_CHANGED,
                Player.EVENT_IS_PLAYING_CHANGED,
                Player.EVENT_MEDIA_ITEM_TRANSITION,
            )
        ) {
            if (events.contains(Player.EVENT_MEDIA_ITEM_TRANSITION)) {
                currentMediaMetadata.value = player.currentMetadata
            }
            requestDiscordSync(
                reason = "is_playing_or_media_item_transition",
                force = true,
            )
            // Capture player state on Main thread
            val currentMediaId = player.currentMediaItem?.mediaId
            val currentMetadata = player.currentMetadata
            val currentPosition = player.currentPosition
            val currentDuration = player.duration
            val isPlaying = player.isPlaying

            scope.launch {
                try {
                    if (currentMetadata?.isPodcast == true) return@launch
                    val song =
                        if (currentMediaId !=
                            null
                        ) {
                            withContext(Dispatchers.IO) { database.song(currentMediaId).first() }
                        } else {
                            null
                        }
                    val finalSong =
                        resolvePresenceSong(
                            dbSong = song,
                            mediaMetadata = currentMetadata,
                            durationMs = currentDuration,
                        ) ?: return@launch
                    try {
                        val lbEnabled = withContext(Dispatchers.IO) { dataStore.get(ListenBrainzEnabledKey, false) }
                        val lbToken = withContext(Dispatchers.IO) { dataStore.get(ListenBrainzTokenKey, "") }
                        val historyPaused = withContext(Dispatchers.IO) { dataStore.get(PauseListenHistoryKey, false) }
                        if (lbEnabled && !lbToken.isNullOrBlank() && !historyPaused) {
                            scope.launch(Dispatchers.IO) {
                                try {
                                    ListenBrainzManager.submitPlayingNow(this@MusicService, lbToken, finalSong, currentPosition)
                                } catch (ie: Exception) {
                                    Timber
                                        .tag(
                                            "MusicService",
                                        ).v(ie, "ListenBrainz playing_now submit failed for isPlaying/mediaTransition")
                                }
                            }
                        }

                        // Last.fm now playing - handled by ScrobbleManager
                    } catch (_: Exception) {
                    }
                } catch (e: Exception) {
                    Timber.tag("MusicService").v(e, "isPlaying/mediaTransition follow-up work failed")
                }
            }
        }

        if (events.containsAny(Player.EVENT_IS_PLAYING_CHANGED)) {
            // Scrobble: Track play/pause state
            if (player.currentMetadata?.isPodcast != true) {
                scrobbleManager?.onPlayerStateChanged(player.isPlaying, player.currentMetadata, duration = player.duration)
            }
        }

        // Persist queue on play/pause so a force-stop right after pausing still restores the correct position
        if (events.contains(Player.EVENT_PLAY_WHEN_READY_CHANGED) && player.mediaItemCount > 0) {
            scope.launch(SilentHandler) {
                if (withContext(Dispatchers.IO) { dataStore.get(PersistentQueueKey, true) }) {
                    saveQueueToDisk()
                }
            }
        }
    }

    override fun onPositionDiscontinuity(
        oldPosition: Player.PositionInfo,
        newPosition: Player.PositionInfo,
        reason: Int,
    ) {
        super.onPositionDiscontinuity(oldPosition, newPosition, reason)
        val isSeekDiscontinuity =
            reason == Player.DISCONTINUITY_REASON_SEEK || reason == Player.DISCONTINUITY_REASON_SEEK_ADJUSTMENT
        if (isSeekDiscontinuity) {
            crossfadeHandler?.finishFade()
        }
        scheduleCrossfade()
    }

    override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
        updateNotification()
        val joined = togetherSessionState.value as? moe.rukamori.archivetune.together.TogetherSessionState.Joined
        if (joined?.role is moe.rukamori.archivetune.together.TogetherRole.Guest) {
            if (!isTogetherApplyingRemote()) {
                if (!joined.roomState.settings.allowGuestsToControlPlayback) {
                    restoreTogetherGuestPlayback()
                    return
                }
                requestTogetherControl(
                    moe.rukamori.archivetune.together.ControlAction.SetShuffleEnabled(
                        shuffleEnabled = shuffleModeEnabled,
                    ),
                )
            }
            return
        }
        if (shuffleModeEnabled) {
            applyCurrentFirstShuffleOrder()
        }

        // Save state when shuffle mode changes - must be on Main thread to access player
        scope.launch {
            if (dataStore.get(PersistentQueueKey, true)) {
                saveQueueToDisk()
            }
        }
        scheduleCrossfade()
    }

    override fun onRepeatModeChanged(repeatMode: Int) {
        updateNotification()
        val joined = togetherSessionState.value as? moe.rukamori.archivetune.together.TogetherSessionState.Joined
        if (joined?.role is moe.rukamori.archivetune.together.TogetherRole.Guest) {
            if (!isTogetherApplyingRemote()) {
                if (!joined.roomState.settings.allowGuestsToControlPlayback) {
                    restoreTogetherGuestPlayback()
                    return
                }
                requestTogetherControl(
                    moe.rukamori.archivetune.together.ControlAction.SetRepeatMode(
                        repeatMode = repeatMode,
                    ),
                )
            }
            return
        }
        scope.launch {
            dataStore.edit { settings ->
                settings[RepeatModeKey] = repeatMode
            }
        }

        // Save state when repeat mode changes - must be on Main thread to access player
        scope.launch {
            if (dataStore.get(PersistentQueueKey, true)) {
                saveQueueToDisk()
            }
        }
        scheduleCrossfade()
    }

    override fun onPlayerErrorChanged(error: PlaybackException?) {
        super.onPlayerErrorChanged(error)
        if (_unrecoveredPlaybackError.value !== error) {
            _unrecoveredPlaybackError.value = null
        }
    }

    override fun onPlayerError(error: PlaybackException) {
        super.onPlayerError(error)
        val snapshot =
            capturePlaybackRecoverySnapshot() ?: run {
                surfaceUnrecoveredPlaybackError(error)
                return
            }
        playbackErrorRecoveryJob?.cancel()
        playbackErrorRecoveryJob = scope.launch {
            handlePlaybackError(error, snapshot)
        }
    }

    private fun surfaceUnrecoveredPlaybackError(error: PlaybackException) {
        if (player.playerError === error) {
            _unrecoveredPlaybackError.value = error
        }
    }

    private suspend fun finishUnrecoveredPlaybackError(error: PlaybackException) {
        if (dataStore.get(AutoSkipNextOnErrorKey, false)) skipOnError() else stopOnError()
        surfaceUnrecoveredPlaybackError(error)
    }

    private suspend fun handlePlaybackError(
        error: PlaybackException,
        recoverySnapshot: PlaybackRecoverySnapshot,
    ) {
        val currentMediaId = recoverySnapshot.mediaId
        if (activeModuleAudio.containsKey(currentMediaId)) {
            finishUnrecoveredPlaybackError(error)
            return
        }
        val isLocalMedia = currentMediaId.isLocalMediaId() ||
            player.currentMediaItem?.localConfiguration?.uri?.shouldBypassPlayerCache() == true
        val (isFullyDownloadedMedia, hasAnyCachedData) = withContext(Dispatchers.IO) {
            if (isLocalMedia || currentMediaId in cacheBypassMediaIds) {
                false to false
            } else {
                try {
                    downloadCache.isFullyCached(currentMediaId) to
                        (downloadCache.getCachedSpans(currentMediaId).isNotEmpty() ||
                            playerCache.getCachedSpans(currentMediaId).isNotEmpty())
                } catch (failure: IOException) {
                    Timber.tag("MusicService").w(failure, "Failed to inspect playback cache for %s", currentMediaId)
                    false to true
                }
            }
        }
        if (player.currentMediaItem?.mediaId != currentMediaId || player.playerError !== error) return

        if (!isLocalMedia && isCacheCorruptionError(error, hasAnyCachedData)) {
            if (!isNetworkCurrentlyConnected()) {
                waitOnNetworkError()
                surfaceUnrecoveredPlaybackError(error)
                return
            }
            if (cacheBypassMediaIds.add(currentMediaId)) {
                Timber.tag("MusicService").w(
                    error,
                    "Retrying %s from the network after a cache or truncated stream failure",
                    currentMediaId,
                )
                resolveAudioStream.invalidate(currentMediaId)
                YTPlayerUtils.invalidateCachedStreamUrls(currentMediaId)
                withContext(Dispatchers.IO) {
                    try {
                        playerCache.removeResource(currentMediaId)
                    } catch (failure: IOException) {
                        Timber.tag("MusicService").w(failure, "Failed to remove damaged streaming cache for %s", currentMediaId)
                    }
                }
                if (player.currentMediaItem?.mediaId != currentMediaId || player.playerError !== error) return
                val retrySnapshot =
                    capturePlaybackRecoverySnapshot() ?: run {
                        surfaceUnrecoveredPlaybackError(error)
                        return
                    }
                player.stop()
                if (preparePlaybackFromSnapshot(retrySnapshot)) return
            }
            finishUnrecoveredPlaybackError(error)
            return
        }

        if (!isLocalMedia && !isFullyDownloadedMedia && !isNetworkCurrentlyConnected()) {
            waitOnNetworkError()
            surfaceUnrecoveredPlaybackError(error)
            return
        }

        if (!isLocalMedia &&
            !isFullyDownloadedMedia &&
            error.isTransientNetworkFailure() &&
            retryPlaybackAfterNetworkFailure(currentMediaId, isFullyDownloadedMedia)
        ) {
            return
        }

        val streamHttpFailure = findStreamHttpFailure(error)
        if (streamHttpFailure != null) {
            if (streamHttpFailure.responseCode in RETRYABLE_STREAM_RESPONSE_CODES &&
                retryPlaybackAfterStreamFailure(currentMediaId, isFullyDownloadedMedia, streamHttpFailure)
            ) {
                return
            }
        }

        if (!isLocalMedia && !isFullyDownloadedMedia && YTPlayerUtils.isBotDetectionException(error)) {
            resolveAudioStream.invalidate(currentMediaId)
            YTPlayerUtils.invalidateCachedStreamUrls(currentMediaId)
        }

        if (!isLocalMedia && !isFullyDownloadedMedia && YTPlayerUtils.isBadStreamPlayerResponseException(error)) {
            resolveAudioStream.invalidate(currentMediaId)
            YTPlayerUtils.invalidateCachedStreamUrls(currentMediaId)
            if (playbackStreamRecoveryTracker.registerRetryAttempt(currentMediaId)) {
                withContext(Dispatchers.IO) {
                    try {
                        YTPlayerUtils.recoverFromBadStreamPlayerResponse(currentMediaId)
                    } catch (cancellation: CancellationException) {
                        throw cancellation
                    } catch (failure: Exception) {
                        Timber.tag("MusicService").w(
                            failure,
                            "Failed to refresh stream session for %s after all stream clients failed",
                            currentMediaId,
                        )
                        reportException(failure)
                    }
                }
                if (player.currentMediaItem?.mediaId != currentMediaId || player.playerError !== error) return
                Timber.tag("MusicService").i(
                    "Retrying playback for %s after refreshing stream session",
                    currentMediaId,
                )
                if (preparePlaybackFromSnapshot(capturePlaybackRecoverySnapshot())) return
            }
        }

        if (!isLocalMedia && !isFullyDownloadedMedia && isRetryableRemoteParserFailure(error)) {
            val recoverySnapshot = capturePlaybackRecoverySnapshot()
            resolveAudioStream.invalidate(currentMediaId)
            YTPlayerUtils.invalidateCachedStreamUrls(currentMediaId)
            if (playbackStreamRecoveryTracker.registerRetryAttempt(currentMediaId)) {
                Timber.tag("MusicService").i(
                    "Retrying playback for %s after parser source error %d",
                    currentMediaId,
                    error.errorCode,
                )
                if (preparePlaybackFromSnapshot(recoverySnapshot)) return
            }
        }

        finishUnrecoveredPlaybackError(error)
    }

    private suspend fun trimPlayerCacheToBytes(limitBytes: Long) {
        if (limitBytes <= 0L) return

        withContext(Dispatchers.IO) {
            val cacheDir = StorageLocationRepository.cacheDirectory(this@MusicService, StorageFolderKind.SONG_CACHE)
            val currentSpace = runCatching { playerCache.cacheSpace }.getOrNull() ?: 0L
            var totalBytes = if (currentSpace > 0L) currentSpace else cacheDir.directorySizeBytes()
            if (totalBytes <= limitBytes) return@withContext

            data class Candidate(
                val key: String,
                val lastTouchTimestamp: Long,
                val sizeBytes: Long,
            )

            val candidates =
                runCatching {
                    playerCache.keys
                        .mapNotNull { key ->
                            runCatching {
                                val spans = playerCache.getCachedSpans(key)
                                if (spans.isEmpty()) return@runCatching null
                                val oldestTouch = spans.minOf { it.lastTouchTimestamp }
                                val sizeBytes = spans.sumOf { it.length }
                                Candidate(key = key, lastTouchTimestamp = oldestTouch, sizeBytes = sizeBytes)
                            }.getOrNull()
                        }.sortedBy { it.lastTouchTimestamp }
                }.getOrNull().orEmpty()

            for (candidate in candidates) {
                if (totalBytes <= limitBytes) break
                val removedSize = candidate.sizeBytes.coerceAtLeast(0L)
                runCatching { playerCache.removeResource(candidate.key) }
                totalBytes -= removedSize
            }
        }
    }

    private fun createPlayerCacheDataSourceFactory(cacheWriteEnabled: Boolean): CacheDataSource.Factory =
        CacheDataSource
            .Factory()
            .setCache(playerCache)
            .setUpstreamDataSourceFactory(createResolvedUpstreamDataSourceFactory())
            .apply {
                if (!cacheWriteEnabled) {
                    setCacheWriteDataSinkFactory(null)
                }
            }.setFlags(FLAG_IGNORE_CACHE_ON_ERROR)

    private fun createDataSourceFactory(): DataSource.Factory {
        val downloadedFactory =
            CacheDataSource.Factory()
                .setCache(downloadCache)
                .setCacheWriteDataSinkFactory(null)
        val streamingFactory = DataSource.Factory {
            createPlayerCacheDataSourceFactory(
                cacheWriteEnabled = !isLowDataModeActive(),
            ).createDataSource()
        }
        val directFactory = createResolvedUpstreamDataSourceFactory()

        return DataSource.Factory {
            SchemeRoutingDataSource { dataSpec ->
                val mediaId = dataSpec.key
                when {
                    dataSpec.uri.shouldBypassPlayerCache() || (mediaId != null && mediaId in cacheBypassMediaIds) -> directFactory
                    else -> {
                        if (mediaId != null) {
                            database.getFormatByIdBlocking(mediaId)?.let { format ->
                                format.toCastMimeType()?.let { castMimeTypeCache.put(mediaId, it) }
                                audioNormalizationFactorCache[mediaId] =
                                    calculateAudioNormalizationFactor(format, normalizeAudio = true)
                            }
                            scope.launch(Dispatchers.IO) { recoverSong(mediaId) }
                        }
                        if (mediaId != null && downloadCache.isFullyCached(mediaId)) {
                            downloadedFactory
                        } else {
                            streamingFactory
                        }
                    }
                }
            }
        }
    }

    private fun Cache.isFullyCached(mediaId: String): Boolean {
        val contentLength = ContentMetadata.getContentLength(getContentMetadata(mediaId))
        return contentLength > 0L && isCached(mediaId, 0L, contentLength)
    }

    private fun createResolvedUpstreamDataSourceFactory(): DataSource.Factory {
        val httpFactory = OkHttpDataSource.Factory(
            PlaybackHttpClient(this, mediaOkHttpClient),
        )
        val chunkedFactory = DataSource.Factory {
            ChunkedDataSource(httpFactory.createDataSource(), CHUNK_LENGTH)
        }
        val mediaFactory = DefaultDataSource.Factory(this, chunkedFactory)
        return ResolvingDataSource.Factory(mediaFactory, ::resolvePlaybackDataSpec)
    }

    private fun String?.toCastMimeType(): String? {
        val normalized = this?.trim()?.takeIf(String::isNotEmpty) ?: return null
        val baseType = normalized.substringBefore(';').trim()
        return normalized.takeIf {
            baseType.contains('/') && !baseType.endsWith("/*")
        }
    }

    private fun FormatEntity.toCastMimeType(): String? {
        val normalizedMimeType = mimeType.toCastMimeType() ?: return null
        val normalizedCodecs = codecs.trim()
        return if (normalizedCodecs.isEmpty() || normalizedMimeType.contains("codecs=", ignoreCase = true)) {
            normalizedMimeType
        } else {
            "$normalizedMimeType; codecs=\"$normalizedCodecs\""
        }
    }

    private fun resolveMediaItemForCast(
        mediaItem: MediaItem,
        blocking: Boolean,
    ): MediaItem {
        val localConfiguration = mediaItem.localConfiguration ?: return mediaItem
        val uri = localConfiguration.uri
        if (uri.shouldBypassYouTubeResolver()) return mediaItem
        val mediaId = localConfiguration.customCacheKey ?: mediaItem.mediaId
        val lowDataModeActive = isLowDataModeActive()
        val request =
            AudioStreamRequest(
                mediaId = mediaId,
                quality = if (lowDataModeActive) AudioQuality.LOW else audioQuality,
                networkMetered = lowDataModeActive,
                purpose = StreamPurpose.PLAYBACK,
                authState = YouTube.currentPlaybackAuthState(),
                allowModules = false,
            )
        val resolved =
            if (blocking) {
                resolveAudioStream.resolveBlocking(request)
            } else {
                resolveAudioStream.peek(request) ?: return mediaItem
            }
        val resolvedMimeType =
            localConfiguration.mimeType.toCastMimeType()
                ?: castMimeTypeCache.get(mediaId)
                ?: resolved.castMimeType()
        return mediaItem
            .buildUpon()
            .setUri(resolved.url)
            .apply { resolvedMimeType?.let(::setMimeType) }
            .build()
    }

    private fun ResolvedAudioStream.castMimeType(): String? =
        if (codecs.isBlank()) mimeType.toCastMimeType() else "$mimeType; codecs=\"$codecs\"".toCastMimeType()

    private fun resolvePlaybackDataSpec(dataSpec: DataSpec): DataSpec {
        if (dataSpec.uri.shouldBypassYouTubeResolver()) {
            return dataSpec
        }
        val mediaId = dataSpec.key ?: return dataSpec
        val storedFormat = database.getFormatByIdBlocking(mediaId)
        storedFormat?.let { format ->
            format.toCastMimeType()?.let { castMimeTypeCache.put(mediaId, it) }
            audioNormalizationFactorCache[mediaId] = calculateAudioNormalizationFactor(format, normalizeAudio = true)
        }
        val cachedMetadata =
            if (mediaId !in cacheBypassMediaIds && playerCache.getCachedSpans(mediaId).isNotEmpty()) {
                playerCache.getContentMetadata(mediaId)
            } else {
                null
            }
        val pinnedFormatId = cachedMetadata?.let { metadata ->
            metadata.get(PLAYBACK_FORMAT_ID_METADATA_KEY, -1L).toInt().takeIf { it > 0 }
                ?: storedFormat?.itag?.takeIf { it > 0 }
        }

        val lowDataModeActive = isLowDataModeActive()
        var resolvedRequestHeaders: Map<String, String> = emptyMap()
        val playbackData =
            runCatching {
                resolveAudioStream
                    .resolveBlocking(
                        AudioStreamRequest(
                            mediaId = mediaId,
                            quality = if (lowDataModeActive) AudioQuality.LOW else audioQuality,
                            networkMetered = lowDataModeActive,
                            purpose = StreamPurpose.PLAYBACK,
                            authState = YouTube.currentPlaybackAuthState(),
                            pinnedFormatId = pinnedFormatId,
                            allowModules = false,
                        ),
                    ).also { resolved ->
                        resolvedRequestHeaders = resolved.requestHeaders
                    }.toPlaybackData(mediaId)
            }.getOrElse { throwable ->
                if (throwable is CancellationException) throw throwable
                when {
                    throwable is YTPlayerUtils.InvalidPlaybackLoginContextException -> {
                        promptLoginRecovery(mediaId, throwable.targetUrl)
                        throw IOException(
                            getString(R.string.playback_requires_youtube_music_login_refresh),
                            throwable,
                        )
                    }

                    throwable is YTPlayerUtils.LoginRequiredForPlaybackException -> {
                        throw IOException(
                            getString(R.string.playback_requires_youtube_music_confirmation),
                            throwable,
                        )
                    }

                    throwable is YTPlayerUtils.BotDetectionPlaybackException -> {
                        throw IOException(
                            getString(R.string.error_no_stream),
                            throwable,
                        )
                    }

                    throwable is YTPlayerUtils.BadStreamPlayerResponseException -> {
                        throw DataSourceException(
                            getString(R.string.error_no_stream),
                            throwable,
                            PlaybackException.ERROR_CODE_IO_UNSPECIFIED,
                        )
                    }

                    throwable is PlaybackException -> {
                        throw DataSourceException(
                            throwable.message,
                            throwable,
                            PlaybackException.ERROR_CODE_IO_UNSPECIFIED,
                        )
                    }

                    throwable.isNetworkConnectionFailure() -> {
                        throw DataSourceException(
                            getString(R.string.playback_error_no_internet),
                            throwable,
                            PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED,
                        )
                    }

                    throwable.isRequestTimeout() -> {
                        throw DataSourceException(
                            getString(R.string.error_timeout),
                            throwable,
                            PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT,
                        )
                    }

                    throwable is IOException -> throw throwable

                    else -> {
                        throw DataSourceException(
                            getString(R.string.playback_error_unknown),
                            throwable,
                            PlaybackException.ERROR_CODE_IO_UNSPECIFIED,
                        )
                    }
                }
            }

        val nonNullPlayback =
            requireNotNull(playbackData) {
                getString(R.string.playback_error_unknown)
            }
        nonNullPlayback.playbackTracking
            ?.remotePlaybackTrackingUrl()
            ?.let { remotePlaybackTrackingUrlCache[mediaId] = it }
        val format = nonNullPlayback.format
        format.mimeType.toCastMimeType()?.let { castMimeTypeCache.put(mediaId, it) }
        val loudnessDb = nonNullPlayback.audioConfig?.loudnessDb ?: storedFormat?.loudnessDb
        val perceptualLoudnessDb =
            nonNullPlayback.audioConfig?.perceptualLoudnessDb ?: storedFormat?.perceptualLoudnessDb
        val resolvedContentLength =
            format.contentLength?.takeIf { it > 0L } ?: 0L
        val resolvedCodecs =
            format.mimeType
                .substringAfter("codecs=", "")
                .removeSurrounding("\"")
                .substringBefore("\"")
                .ifBlank { storedFormat?.codecs.orEmpty() }
        val cachedContentLength = cachedMetadata?.let(ContentMetadata::getContentLength)
        if (cachedMetadata != null &&
            ((pinnedFormatId != null && format.itag != pinnedFormatId) ||
                (cachedContentLength != null && cachedContentLength > 0L &&
                    resolvedContentLength > 0L && cachedContentLength != resolvedContentLength))
        ) {
            throw Cache.CacheException("Cached audio does not match the resolved stream")
        }
        if (mediaId !in cacheBypassMediaIds) {
            val mutations = ContentMetadataMutations()
                .set(PLAYBACK_FORMAT_ID_METADATA_KEY, format.itag.toLong())
            if (resolvedContentLength > 0L) {
                ContentMetadataMutations.setContentLength(mutations, resolvedContentLength)
            }
            playerCache.applyContentMetadataMutations(mediaId, mutations)
        }

        Timber
            .tag(
                "AudioNormalization",
            ).d("Storing format for $mediaId with loudnessDb: $loudnessDb, perceptualLoudnessDb: $perceptualLoudnessDb")
        if (loudnessDb == null && perceptualLoudnessDb == null) {
            Timber.tag("AudioNormalization").w("No loudness data available from YouTube for video: $mediaId")
        }

        val formatEntity =
            FormatEntity(
                id = mediaId,
                itag = format.itag.takeIf { it > 0 } ?: storedFormat?.itag ?: -1,
                mimeType = format.mimeType.split(";")[0],
                codecs = resolvedCodecs,
                bitrate = format.bitrate.takeIf { it > 0 } ?: storedFormat?.bitrate ?: 0,
                sampleRate = format.audioSampleRate ?: storedFormat?.sampleRate,
                contentLength = resolvedContentLength,
                loudnessDb = loudnessDb,
                perceptualLoudnessDb = perceptualLoudnessDb,
                playbackUrl =
                    nonNullPlayback.playbackTracking?.videostatsPlaybackUrl?.baseUrl
                        ?: storedFormat?.playbackUrl,
            )
        val resolvedNormalizationFactor = calculateAudioNormalizationFactor(formatEntity, normalizeAudio = true)
        audioNormalizationFactorCache[mediaId] = resolvedNormalizationFactor
        scope.launch {
            if (currentMediaMetadata.value?.id == mediaId &&
                dataStore.get(AudioNormalizationKey, true)
            ) {
                normalizeFactor.value = resolvedNormalizationFactor
            }
        }

        database.query {
            upsert(
                formatEntity,
            )
        }
        scope.launch(Dispatchers.IO) { recoverSong(mediaId, nonNullPlayback) }

        val streamUrl = nonNullPlayback.streamUrl

        val resolvedDataSpec =
            dataSpec
                .buildUpon()
                .setUri(streamUrl.toUri())
                .setHttpRequestHeaders(dataSpec.httpRequestHeaders + resolvedRequestHeaders)
                .build()
        if (resolvedContentLength > 0L && dataSpec.position == resolvedContentLength) {
            return resolvedDataSpec.buildUpon().setLength(C.LENGTH_UNSET.toLong()).build()
        }
        val remainingLength = (resolvedContentLength - dataSpec.position).takeIf { it > 0L }
        val length = remainingLength?.let { remaining ->
            if (dataSpec.length == C.LENGTH_UNSET.toLong()) remaining else minOf(dataSpec.length, remaining)
        }
        return length?.let { resolvedDataSpec.subrange(0L, it) } ?: resolvedDataSpec
    }

    private fun Uri.shouldBypassYouTubeResolver(): Boolean {
        val normalizedScheme = scheme?.lowercase(Locale.US)
        return normalizedScheme == "content" ||
            normalizedScheme == "file" ||
            normalizedScheme == "android.resource" ||
            normalizedScheme == "http" ||
            normalizedScheme == "https"
    }

    private fun Uri.shouldBypassPlayerCache(): Boolean {
        val normalizedScheme = scheme?.lowercase(Locale.US)
        return normalizedScheme == "content" ||
            normalizedScheme == "file" ||
            normalizedScheme == "android.resource"
    }

    private fun deviceSupportsMimeType(mimeType: String): Boolean =
        runCatching {
            val codecList = MediaCodecList(MediaCodecList.ALL_CODECS)
            codecList.codecInfos.any { info ->
                !info.isEncoder && info.supportedTypes.any { it.equals(mimeType, ignoreCase = true) }
            }
        }.getOrDefault(false)

    private fun createMediaSourceFactory(): androidx.media3.exoplayer.source.MediaSource.Factory =
        ModuleMediaSourceFactory(
            delegate = DefaultMediaSourceFactory(createDataSourceFactory(), DefaultExtractorsFactory()),
            resolver = moduleAudio,
            bindings = moduleBindings,
            storage = moduleStorage,
            completedDownload = { id ->
                moduleDownloadUtil.downloadManager.downloadIndex.getDownload(id)?.state == androidx.media3.exoplayer.offline.Download.STATE_COMPLETED
            },
            selected = ::onModuleAudioSelected,
        )

    private fun onModuleAudioSelected(mediaId: String, selection: ModuleAudioSelection?) {
        if (selection == null) {
            activeModuleAudio.remove(mediaId)
        } else {
            activeModuleAudio[mediaId] = selection
            if (activeModuleAudio.size > 256) {
                activeModuleAudio.keys.filter { it != mediaId }.take(activeModuleAudio.size - 256).forEach(activeModuleAudio::remove)
            }
            remotePlaybackTrackingUrlCache.remove(mediaId)
            audioNormalizationFactorCache[mediaId] = 1f
            selection.stream.mimeType.toCastMimeType()?.let { castMimeTypeCache.put(mediaId, it) }
            scope.launch {
                if (currentMediaMetadata.value?.id == mediaId) normalizeFactor.value = 1f
            }
        }
    }

    private class SchemeRoutingDataSource(
        private val selectFactory: (DataSpec) -> DataSource.Factory,
    ) : DataSource {
        private val transferListeners = mutableListOf<TransferListener>()
        private var delegate: DataSource? = null

        override fun addTransferListener(transferListener: TransferListener) {
            transferListeners += transferListener
            delegate?.addTransferListener(transferListener)
        }

        override fun open(dataSpec: DataSpec): Long {
            val selectedFactory = selectFactory(dataSpec)
            val selectedDataSource = selectedFactory.createDataSource()
            transferListeners.forEach(selectedDataSource::addTransferListener)
            delegate = selectedDataSource
            return selectedDataSource.open(dataSpec)
        }

        override fun read(
            buffer: ByteArray,
            offset: Int,
            length: Int,
        ): Int = checkNotNull(delegate).read(buffer, offset, length)

        override fun getUri(): Uri? = delegate?.uri

        override fun getResponseHeaders(): Map<String, List<String>> = delegate?.responseHeaders ?: emptyMap()

        override fun close() {
            val selected = delegate
            delegate = null
            selected?.close()
        }
    }

    private fun updateAudioOffload(enabled: Boolean) {
        val effectiveEnabled = enabled && !crossfadeEnabled
        runCatching {
            val builder = localPlayer.trackSelectionParameters.buildUpon()
            val audioOffloadPrefsClass = Class.forName("androidx.media3.common.AudioOffloadPreferences")
            val audioOffloadPrefsBuilderClass = Class.forName("androidx.media3.common.AudioOffloadPreferences\$Builder")

            val modeFieldName = if (effectiveEnabled) "AUDIO_OFFLOAD_MODE_ENABLED" else "AUDIO_OFFLOAD_MODE_DISABLED"
            val mode = audioOffloadPrefsClass.getField(modeFieldName).getInt(null)

            val prefsBuilder = audioOffloadPrefsBuilderClass.getDeclaredConstructor().newInstance()
            audioOffloadPrefsBuilderClass.getMethod("setAudioOffloadMode", Int::class.javaPrimitiveType).invoke(prefsBuilder, mode)
            val prefs = audioOffloadPrefsBuilderClass.getMethod("build").invoke(prefsBuilder)

            val setMethod =
                builder.javaClass.methods.firstOrNull { method ->
                    method.name == "setAudioOffloadPreferences" && method.parameterTypes.size == 1
                }
            if (setMethod != null) {
                setMethod.invoke(builder, prefs)
                localPlayer.trackSelectionParameters = builder.build()
            }
        }
        localPlayer.setOffloadEnabled(effectiveEnabled)
    }

    private fun updateWakeLock() {
        val wl = wakeLock ?: return
        val shouldHold = wakelockEnabled && player.isPlaying
        if (shouldHold && !wl.isHeld) {
            wl.acquire()
        } else if (!shouldHold && wl.isHeld) {
            wl.release()
        }
    }

    private fun createPrimaryLoadControl(): DefaultLoadControl =
        DefaultLoadControl
            .Builder()
            .setBufferDurationsMs(
                PRIMARY_MIN_BUFFER_MS,
                PRIMARY_MAX_BUFFER_MS,
                PRIMARY_BUFFER_FOR_PLAYBACK_MS,
                PRIMARY_BUFFER_FOR_PLAYBACK_AFTER_REBUFFER_MS,
            ).setPrioritizeTimeOverSizeThresholds(true)
            .build()

    private fun createRenderersFactory() =
        object : DefaultRenderersFactory(this) {
            override fun buildAudioSink(
                context: Context,
                enableFloatOutput: Boolean,
                enableAudioTrackPlaybackParams: Boolean,
            ): AudioSink {
                val standardSink =
                    DefaultAudioSink
                        .Builder(context)
                        .setEnableFloatOutput(false)
                        .setEnableAudioTrackPlaybackParams(enableAudioTrackPlaybackParams)
                        .setAudioProcessorChain(
                            DefaultAudioSink.DefaultAudioProcessorChain(
                                SilenceSkippingAudioProcessor(
                                    1_500_000L,
                                    0.35f,
                                    500_000L,
                                    10,
                                    150.toShort(),
                                ),
                                SonicAudioProcessor(),
                            ),
                        ).build()
                return BitPerfectRoutingSink(standardSink, BitPerfectAudioSink(bitPerfectOutput))
            }
        }

    override fun onPlaybackStatsReady(
        eventTime: AnalyticsListener.EventTime,
        playbackStats: PlaybackStats,
    ) {
        val mediaItem = eventTime.timeline.getWindow(eventTime.windowIndex, Timeline.Window()).mediaItem
        val mediaId = mediaItem.mediaId
        val thresholdMs = historyThresholdMs()
        val pendingSession = popPendingHistoryFinalization(mediaId)
        val alreadyPersistedForSession = pendingSession?.eventId != null || pendingSession?.remoteRegistered == true
        val reachedHistoryThreshold =
            playbackStats.totalPlayTimeMs >= thresholdMs &&
                !dataStore.get(PauseListenHistoryKey, false)
        val shouldPersistHistory = alreadyPersistedForSession || reachedHistoryThreshold
        val fallbackMetadata = mediaItem.metadata

        if (shouldPersistHistory) {
            ioScope.launch {
                val pendingResult =
                    pendingSession?.let { session ->
                        historyRecordingJobs[session.sessionToken]
                            ?.let { deferred ->
                                runCatching { deferred.await() }
                                    .onFailure(::reportException)
                                    .getOrNull()
                            }?.let { result ->
                                session.copy(
                                    eventId = result.eventId ?: session.eventId,
                                    remoteRegistered = session.remoteRegistered || result.remoteRegistered,
                                )
                            }
                            ?: session
                    }

                val eventId =
                    pendingResult?.eventId ?: insertPlaybackHistoryEvent(
                        mediaId = mediaId,
                        playTimeMs = playbackStats.totalPlayTimeMs,
                        mediaMetadata = fallbackMetadata,
                    )

                if (eventId != null) {
                    runCatching {
                        database.updateEventPlayTime(eventId, playbackStats.totalPlayTimeMs)
                    }.onFailure(::reportException)
                }

                try {
                    database.withTransaction {
                        incrementTotalPlayTime(mediaId, playbackStats.totalPlayTimeMs)
                    }
                } catch (_: SQLException) {
                } catch (throwable: Throwable) {
                    reportException(throwable)
                }

                if (pendingResult?.remoteRegistered != true) {
                    registerRemotePlaybackHistory(mediaId)
                }
            }

            if (fallbackMetadata?.isPodcast != true) {
                ioScope.launch {
                    try {
                        val song =
                            database.song(mediaId).first()
                                ?: return@launch
                        if (song.song.isPodcast) return@launch

                        val lbEnabled = dataStore.get(ListenBrainzEnabledKey, false)
                        val lbToken = dataStore.get(ListenBrainzTokenKey, "")
                        val historyPaused = dataStore.get(PauseListenHistoryKey, false)
                        if (lbEnabled && !lbToken.isNullOrBlank() && !historyPaused) {
                            val endMs = System.currentTimeMillis()
                            val startMs = endMs - playbackStats.totalPlayTimeMs
                            try {
                                ListenBrainzManager.submitFinished(this@MusicService, lbToken, song, startMs, endMs)
                            } catch (ie: Exception) {
                                Timber.tag("MusicService").v(ie, "ListenBrainz finished submit failed")
                            }
                        }
                    } catch (_: Exception) {
                    }
                }
            }
        }
    }

    private fun currentPresenceSong(): Song? =
        resolvePresenceSong(
            dbSong = currentSong.value,
            mediaMetadata = player.currentMetadata,
            durationMs = player.duration,
        )

    private fun resolvePresenceSong(
        dbSong: Song?,
        mediaMetadata: MediaMetadata?,
        durationMs: Long,
    ): Song? {
        if (mediaMetadata?.isPodcast == true || dbSong?.song?.isPodcast == true) return null
        val metadataSong = mediaMetadata?.let { createTransientSongFromMedia(it) }
        val song =
            when {
                dbSong == null -> metadataSong
                metadataSong == null -> dbSong
                else -> dbSong.withPresenceMetadata(metadataSong)
            }

        return song.withResolvedPresenceDuration(durationMs)
    }

    private fun Song.withPresenceMetadata(metadataSong: Song): Song {
        val resolvedArtists =
            metadataSong.artists
                .takeIf { metadataArtists ->
                    metadataArtists.any { it.hasRemotePresenceId() }
                }?.map { metadataArtist ->
                    val persistedArtist =
                        artists.firstOrNull { artist ->
                            artist.id == metadataArtist.id || artist.channelId == metadataArtist.id
                        }
                    metadataArtist.copy(
                        thumbnailUrl = metadataArtist.thumbnailUrl ?: persistedArtist?.thumbnailUrl,
                        channelId = metadataArtist.channelId ?: persistedArtist?.channelId,
                    )
                } ?: artists

        return copy(
            song =
                song.copy(
                    thumbnailUrl = song.thumbnailUrl ?: metadataSong.song.thumbnailUrl,
                    albumId = song.albumId ?: metadataSong.song.albumId,
                    albumName = song.albumName ?: metadataSong.song.albumName,
                ),
            artists = resolvedArtists,
            album = album ?: metadataSong.album,
        )
    }

    private fun Song?.withResolvedPresenceDuration(durationMs: Long): Song? {
        val song = this ?: return null
        if (song.song.duration > 0 || durationMs <= 0) return song
        val durationSeconds =
            (durationMs / 1000L)
                .coerceAtLeast(1L)
                .coerceAtMost(Int.MAX_VALUE.toLong())
                .toInt()
        return song.copy(song = song.song.copy(duration = durationSeconds))
    }

    private fun ArtistEntity.hasRemotePresenceId(): Boolean = channelId.isRemotePresenceId() || id.isRemotePresenceId()

    private fun String?.isRemotePresenceId(): Boolean {
        val id = this?.trim()?.takeIf { it.isNotBlank() } ?: return false
        return !id.isLocalMediaId() &&
            !id.startsWith("LOCAL_ARTIST_") &&
            !id.startsWith("LA") &&
            !id.contains("privately_owned_artist", ignoreCase = true)
    }

    // Create a transient Song object from current Player MediaMetadata when the DB doesn't have it.
    private fun createTransientSongFromMedia(media: MediaMetadata): Song {
        val songEntity =
            SongEntity(
                id = media.id,
                title = media.title,
                duration = media.duration,
                thumbnailUrl = media.thumbnailUrl,
                albumId = media.album?.id,
                albumName = media.album?.title,
                explicit = media.explicit,
                isMusicVideo = media.isMusicVideo,
                isPodcast = media.isPodcast,
                isLocal = media.id.isLocalMediaId(),
            )

        val artists =
            media.artists.map { artist ->
                ArtistEntity(
                    id = artist.id ?: "LA_unknown_${artist.name}",
                    name = artist.name,
                    thumbnailUrl = artist.thumbnailUrl,
                    isLocal = artist.id == null || artist.id.isLocalMediaId(),
                )
            }

        val album =
            media.album?.let { alb ->
                AlbumEntity(
                    id = alb.id,
                    playlistId = null,
                    title = alb.title,
                    year = null,
                    thumbnailUrl = media.thumbnailUrl,
                    themeColor = null,
                    songCount = 1,
                    duration = media.duration,
                    isLocal = media.id.isLocalMediaId(),
                )
            }

        return Song(
            song = songEntity,
            artists = artists,
            album = album,
            format = null,
        )
    }

    private inline fun <reified T> readPersistentObject(fileName: String): T? {
        val persistentFile = filesDir.resolve(fileName)
        if (!persistentFile.exists() || !persistentFile.isFile) return null

        return synchronized(persistentStateLock) {
            runCatching {
                persistentFile.inputStream().use { fis ->
                    ObjectInputStream(fis).use { input ->
                        val payload = input.readObject()
                        check(payload is T) { "Unexpected persistent payload type for $fileName" }
                        payload
                    }
                }
            }.onFailure {
                Timber.tag(TAG).w(it, "Failed to read persistent file: $fileName")
            }.getOrNull()
        }
    }

    private fun clearPersistedQueueFiles() {
        persistentSaveGeneration.incrementAndGet()
        synchronized(persistentStateLock) {
            listOf(
                PERSISTENT_QUEUE_FILE,
                PERSISTENT_PLAYER_STATE_FILE,
                PERSISTENT_AUTOMIX_FILE,
            ).forEach { fileName ->
                val persistentFile = filesDir.resolve(fileName)
                val tempFile = filesDir.resolve("$fileName.tmp")
                runCatching {
                    if (persistentFile.exists() && !persistentFile.delete()) {
                        Timber.tag(TAG).w("Failed to delete persistent file: $fileName")
                    }
                    if (tempFile.exists() && !tempFile.delete()) {
                        Timber.tag(TAG).w("Failed to delete temporary persistent file: $fileName")
                    }
                }.onFailure {
                    Timber.tag(TAG).w(it, "Failed to clear persistent file: $fileName")
                }
            }
        }
    }

    private fun writePersistentObject(
        fileName: String,
        payload: Serializable,
    ) {
        val persistentFile = filesDir.resolve(fileName)
        val tempFile = filesDir.resolve("$fileName.tmp")

        synchronized(persistentStateLock) {
            runCatching {
                FileOutputStream(tempFile).use { fos ->
                    ObjectOutputStream(fos).use { output ->
                        output.writeObject(payload)
                        output.flush()
                    }
                }

                if (!tempFile.renameTo(persistentFile)) {
                    if (persistentFile.exists() && !persistentFile.delete()) {
                        error("Could not replace $fileName")
                    }
                    if (!tempFile.renameTo(persistentFile)) {
                        error("Could not atomically move $fileName")
                    }
                }
            }.onFailure {
                runCatching { tempFile.delete() }
                reportException(it)
            }
        }
    }

    private fun MediaItem.toPersistableMetadata(): moe.rukamori.archivetune.models.MediaMetadata? {
        val tagged = metadata
        if (tagged != null) return tagged

        val id =
            mediaId
                .trim()
                .ifBlank {
                    localConfiguration
                        ?.uri
                        ?.toString()
                        ?.trim()
                        .orEmpty()
                }.takeIf { it.isNotBlank() } ?: return null

        val title =
            mediaMetadata.title
                ?.toString()
                ?.trim()
                .takeIf { !it.isNullOrBlank() }
                ?: id

        val artistText =
            mediaMetadata.artist
                ?.toString()
                ?.trim()
                .takeIf { !it.isNullOrBlank() }
                ?: mediaMetadata.subtitle
                    ?.toString()
                    ?.trim()
                    .takeIf { !it.isNullOrBlank() }

        val artists =
            artistText
                ?.split(",")
                ?.mapNotNull { it.trim().takeIf(String::isNotBlank) }
                ?.map { name ->
                    moe.rukamori.archivetune.models.MediaMetadata
                        .Artist(id = null, name = name)
                }.orEmpty()

        val thumbnailUrl = mediaMetadata.artworkUri?.toString()
        val albumTitle =
            mediaMetadata.albumTitle
                ?.toString()
                ?.trim()
                .takeIf { !it.isNullOrBlank() }
        val album =
            albumTitle?.let { titleValue ->
                moe.rukamori.archivetune.models.MediaMetadata
                    .Album(id = titleValue, title = titleValue)
            }

        return moe.rukamori.archivetune.models.MediaMetadata(
            id = id,
            title = title,
            artists = artists,
            duration = -1,
            thumbnailUrl = thumbnailUrl,
            album = album,
            explicit = false,
            liked = false,
            likedDate = null,
            inLibrary = null,
        )
    }

    private suspend fun saveQueueToDisk() {
        val saveGeneration = persistentSaveGeneration.get()
        val snapshot =
            withContext(Dispatchers.Main.immediate) {
                if (
                    saveGeneration != persistentSaveGeneration.get() ||
                    isRestoringPersistentState ||
                    isHydratingRestoredQueue
                ) {
                    return@withContext null
                }

                val entrySnapshot = player.mediaItems.mapNotNull { item -> item.toPersistableMetadata()?.let { it to item } }
                val mediaItemsSnapshot = entrySnapshot.map { it.first }
                if (mediaItemsSnapshot.isEmpty()) return@withContext null

                val currentMediaItemIndex = player.currentMediaItemIndex
                val currentPosition = player.currentPosition
                val persistQueue =
                    currentQueue.toPersistQueue(
                        title = queueTitle,
                        items = mediaItemsSnapshot,
                        mediaItemIndex = currentMediaItemIndex,
                        position = currentPosition,
                    ).copy(
                        entryMetadata = entrySnapshot.map { (_, item) ->
                            moe.rukamori.archivetune.models.PersistQueueEntry(item.queueEntryId ?: java.util.UUID.randomUUID().toString(), item.isQueueRecommendation)
                        },
                        recommendationData = recommendationQueue?.let { queue ->
                            moe.rukamori.archivetune.models.QueueData.YouTubeData(
                                videoId = queue.endpoint.videoId,
                                playlistId = queue.endpoint.playlistId,
                                endpointParams = queue.endpoint.params,
                                followAutomixPreview = queue.followAutomixPreview,
                                continuation = queue.continuation,
                            )
                        },
                    )
                val persistPlayerState =
                    PersistPlayerState(
                        playWhenReady = player.playWhenReady,
                        repeatMode = player.repeatMode,
                        shuffleModeEnabled = player.shuffleModeEnabled,
                        volume = playerVolume.value,
                        currentPosition = currentPosition,
                        currentMediaItemIndex = currentMediaItemIndex,
                        playbackState = player.playbackState,
                    )

                persistQueue to persistPlayerState
            } ?: return

        withContext(Dispatchers.IO) {
            if (saveGeneration != persistentSaveGeneration.get()) return@withContext
            writePersistentObject(PERSISTENT_QUEUE_FILE, snapshot.first)
            if (saveGeneration != persistentSaveGeneration.get()) return@withContext
            writePersistentObject(PERSISTENT_PLAYER_STATE_FILE, snapshot.second)
        }
    }

    override fun onDestroy() {
        binder.release()
        equalizerPlaybackController.detach(this)
        sponsorBlockPlaybackController.detach()
        discordServiceStopping = true
        requestDiscordSync(
            reason = "service_destroy",
            force = true,
        )
        super.onDestroy()
        playbackErrorRecoveryJob?.cancel()
        effectiveVolumeRampJob?.cancel()
        effectiveVolumeRampJob = null
        cancelCrossfade(resetVolume = false)
        audioRouteRecoveryJob?.cancel()
        if (audioDeviceCallbackRegistered) {
            audioManager.unregisterAudioDeviceCallback(audioDeviceCallback)
            audioDeviceCallbackRegistered = false
        }
        unregisterBluetoothReceiver()
        unregisterMuteRecoveryObserver()
        try {
            scope.launch { stopTogetherInternal() }
        } catch (_: Exception) {
        }
        try {
            connectivityObserver.unregister()
        } catch (_: Exception) {
        }
        abandonAudioFocus()
        try {
            releaseAudioEffects()
        } catch (_: Exception) {
        }
        try {
            if (dataStore.get(PersistentQueueKey, true) && player.mediaItemCount > 0) {
                runBlocking {
                    saveQueueToDisk()
                }
            }
        } catch (_: Exception) {
        }
        mediaLibrarySessionCallback.release()
        try {
            mediaSession.release()
        } catch (_: Exception) {
        }
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (_: Exception) {
        }
        try {
            localPlaybackPlayer.removeListener(audioEffectPlayerListener)
            player.removeListener(this)
            player.removeListener(sleepTimer)
            player.release()
        } catch (_: Exception) {
        }
        nextStreamPreloader.cancel()
        scopeJob.cancel()
    }

    override fun onBind(intent: Intent?): android.os.IBinder? {
        boundClientCount++
        cancelIdleStop()
        val result = super.onBind(intent) ?: binder
        if (player.mediaItemCount > 0 && player.currentMediaItem != null) {
            currentMediaMetadata.value = player.currentMetadata
            scope.launch {
                delay(50)
                updateNotification()
            }
        }
        return result
    }

    override fun onUnbind(intent: Intent?): Boolean {
        boundClientCount = (boundClientCount - 1).coerceAtLeast(0)
        scheduleStopIfIdle()
        return super.onUnbind(intent)
    }

    override fun onRebind(intent: Intent?) {
        boundClientCount++
        cancelIdleStop()
        super.onRebind(intent)
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)

        val stopMusicOnTaskClearEnabled = dataStore.get(StopMusicOnTaskClearKey, false)

        try {
            val state = togetherSessionState.value
            val isHostSessionActive =
                state is moe.rukamori.archivetune.together.TogetherSessionState.Hosting ||
                    state is moe.rukamori.archivetune.together.TogetherSessionState.HostingOnline ||
                    (
                        state is moe.rukamori.archivetune.together.TogetherSessionState.Joined &&
                            state.role is moe.rukamori.archivetune.together.TogetherRole.Host
                    )

            val isPlaybackInactive = player.playbackState == Player.STATE_IDLE || player.mediaItemCount == 0

            if (shouldStopServiceOnTaskRemoved(stopMusicOnTaskClearEnabled, isHostSessionActive, isPlaybackInactive)) {
                if (stopMusicOnTaskClearEnabled) {
                    discordServiceStopping = true
                    requestDiscordSync(
                        reason = "task_removed_stop_music_on_task_clear",
                        force = true,
                    )
                    runCatching { stopAndClearPlayback(clearPersistentState = true) }
                    stopForegroundAndSelf()
                    return
                }

                if (isHostSessionActive && isPlaybackInactive) {
                    discordServiceStopping = true
                    requestDiscordSync(
                        reason = "task_removed_host_inactive",
                        force = true,
                    )
                    runCatching { scope.launch { stopTogetherInternal() } }
                    runCatching { togetherSessionState.value = moe.rukamori.archivetune.together.TogetherSessionState.Idle }
                    stopSelf()
                    return
                }
            }

            if (dataStore.get(PersistentQueueKey, true) && player.mediaItemCount > 0) {
                runBlocking { saveQueueToDisk() }
            }
        } catch (_: Exception) {
        }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo) = mediaSession

    private fun handleMediaNotificationDismissed(intent: Intent) {
        val originalDeleteIntent =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                intent.getParcelableExtra(
                    EXTRA_MEDIA_NOTIFICATION_DELETE_INTENT,
                    PendingIntent::class.java,
                )
            } else {
                intent.getParcelableExtra(EXTRA_MEDIA_NOTIFICATION_DELETE_INTENT)
            }

        val isForeground = isAppInForeground()
        if (!player.isPlaying && !isForeground) {
            pausedPresenceGate = PausedPresenceGate.HiddenByNotificationDismiss
            requestDiscordSync(
                reason = "notification_dismissed_while_paused_background",
                force = true,
            )
        } else if (!player.isPlaying) {
            Timber.tag(DISCORD_SYNC_TAG).d(
                "notification dismissed while paused but app is foreground; keeping paused RPC visible",
            )
        }

        runCatching {
            originalDeleteIntent?.send()
        }.onFailure {
            Timber.tag(DISCORD_SYNC_TAG).w(it, "failed to forward original notification delete intent")
        }

        if (notificationConfiguration.stopOnDismiss && !player.isPlaying) {
            closePlaybackFromNotification()
        }
    }

    override fun onStartCommand(
        intent: Intent?,
        flags: Int,
        startId: Int,
    ): Int {
        isPlaybackServiceStarted = true
        if (intent?.action == ACTION_MEDIA_NOTIFICATION_DISMISSED) {
            handleMediaNotificationDismissed(intent)
            return START_NOT_STICKY
        }

        enterForegroundForStartCommand()
        if (!hasResumablePlaybackNotification()) {
            scheduleStopIfIdle()
        }
        when (intent?.action) {
            WidgetServiceActions.PLAY_PAUSE -> {
                if (player.isPlaying) player.pause() else player.play()
            }

            WidgetServiceActions.SKIP_NEXT -> {
                if (player.hasNextMediaItem()) {
                    player.seekToNext()
                    player.prepare()
                    player.play()
                }
            }

            WidgetServiceActions.SKIP_PREV -> {
                if (player.hasPreviousMediaItem()) {
                    player.seekToPrevious()
                    player.prepare()
                    player.play()
                }
            }

            WidgetServiceActions.PLAY_QUEUE_ITEM -> playWidgetQueueItem(intent)

            WidgetServiceActions.PLAY_SONG -> playWidgetSong(intent)
        }
        super.onStartCommand(intent, flags, startId)
        return START_NOT_STICKY
    }

    // ── Widget Support ────────────────────────────────────────────────────────────

    fun updateWidget() {
        widgetUpdater.update()
        widgetUpdater.updateProgressTracking()
    }

    private fun playWidgetQueueItem(intent: Intent) {
        val mediaId = intent.getStringExtra(WidgetServiceActions.EXTRA_MEDIA_ID) ?: return
        val itemCount = player.mediaItemCount
        val hintedIndex = intent.getIntExtra(WidgetServiceActions.EXTRA_QUEUE_INDEX, C.INDEX_UNSET)
        val index =
            if (hintedIndex in 0 until itemCount && player.getMediaItemAt(hintedIndex).mediaId == mediaId) {
                hintedIndex
            } else {
                (0 until itemCount).firstOrNull { player.getMediaItemAt(it).mediaId == mediaId }
            } ?: return
        player.seekTo(index, 0L)
        player.prepare()
        player.play()
    }

    private fun playWidgetSong(intent: Intent) {
        val songId = intent.getStringExtra(WidgetServiceActions.EXTRA_MEDIA_ID) ?: return
        if (player.currentMediaItem?.mediaId == songId) {
            if (player.isPlaying) player.pause() else player.play()
            return
        }
        scope.launch(SilentHandler) {
            val song = withContext(Dispatchers.IO) { database.song(songId).first() } ?: return@launch
            playQueue(
                if (song.song.isLocal) {
                    ListQueue(items = listOf(song.toMediaItem()))
                } else {
                    YouTubeQueue.radio(song.toMediaMetadata())
                },
            )
        }
    }

    class MusicBinder internal constructor(service: MusicService) : Binder() {
        @Volatile
        private var serviceReference: MusicService? = service

        val service: MusicService
            get() = checkNotNull(serviceReference) { "MusicService has been destroyed" }

        internal fun release() {
            serviceReference = null
        }
    }

    companion object {
        internal fun shouldStopServiceOnTaskRemoved(
            stopMusicOnTaskClearEnabled: Boolean,
            isHostSessionActive: Boolean,
            isPlaybackInactive: Boolean,
        ): Boolean = (isHostSessionActive && isPlaybackInactive) || stopMusicOnTaskClearEnabled

        const val ROOT = "root"
        const val HOME = "home"
        const val LIBRARY = "library"
        const val HOME_QUICK_PICKS = "home_quick_picks"
        const val HOME_FORGOTTEN_FAVORITES = "home_forgotten_favorites"
        const val HOME_KEEP_LISTENING = "home_keep_listening"
        const val HOME_SUGGESTED_SONGS = "home_suggested_songs"
        const val HOME_MIXES_AND_RADIOS = "home_mixes_and_radios"
        const val QUICK_PICKS = "quick_picks"
        const val RECENT = "recent"
        const val LIKED = "liked"
        const val DOWNLOADED = "downloaded"
        const val SONG = "song"
        const val ARTIST = "artist"
        const val ALBUM = "album"
        const val PLAYLIST = "playlist"
        const val ONLINE_PLAYLIST = "online_playlist"
        const val SPOTIFY_PLAYLIST = "spotify_playlist"
        const val SPOTIFY_LIKED = "spotify_liked"

        private const val TAG = "MusicService"
        private const val AUDIO_EFFECT_INITIALIZATION_MAX_ATTEMPTS = 4
        private const val AUDIO_EFFECT_INITIALIZATION_RETRY_DELAY_MS = 250L
        private const val DISCORD_SYNC_TAG = "DiscordSync"
        private const val DISCORD_HOLD_TIMEOUT_MS = 7_000L
        const val CHANNEL_ID = "music_channel_01"
        const val ACTION_MEDIA_NOTIFICATION_DISMISSED =
            "moe.rukamori.archivetune.action.MEDIA_NOTIFICATION_DISMISSED"
        const val EXTRA_MEDIA_NOTIFICATION_DELETE_INTENT =
            "moe.rukamori.archivetune.extra.MEDIA_NOTIFICATION_DELETE_INTENT"
        const val NOTIFICATION_ID = 888
        private const val TOGETHER_NOTIFICATION_CHANNEL_ID = "together_room_events"
        private const val TOGETHER_PARTICIPANT_NOTIFICATION_ID = 891
        private const val TOGETHER_INACTIVITY_NOTIFICATION_ID = 892
        private const val TOGETHER_HOST_INACTIVITY_TIMEOUT_MS = 10 * 60 * 1000L
        const val ERROR_CODE_NO_STREAM = 1000001
        private const val PLAYBACK_FORMAT_ID_METADATA_KEY = "archivetune_playback_format_id"
        const val CHUNK_LENGTH = 8 * 1024 * 1024L
        val RETRYABLE_STREAM_RESPONSE_CODES = setOf(403, 404, 410, 416)
        const val PERSISTENT_QUEUE_FILE = "persistent_queue.data"
        const val PERSISTENT_AUTOMIX_FILE = "persistent_automix.data"
        const val PERSISTENT_PLAYER_STATE_FILE = "persistent_player_state.data"
        const val MAX_CONSECUTIVE_ERR = 5
        const val AUDIO_ROUTE_CHANGE_DEBOUNCE_MS = 350L
        const val AUDIO_EFFECT_ROUTE_REBIND_DELAY_MS = 200L
        const val AUDIO_ROUTE_RECOVERY_MIN_INTERVAL_MS = 1_500L
        const val AUDIO_ROUTE_RECOVERY_RESUME_DELAY_MS = 150L
        const val DEVICE_MUTE_PLAYBACK_NOTICE_INTERVAL_MS = 1_200L
        const val MIN_AUDIO_FOCUS_VOLUME_FACTOR = 0.2f
        const val MIN_AUDIO_NORMALIZATION_FACTOR = 0.25f
        const val MAX_AUDIO_NORMALIZATION_FACTOR = 1.414f
        const val EFFECTIVE_VOLUME_RAMP_FRAME_MS = 16L
        const val EFFECTIVE_VOLUME_RAMP_UP_MS = 350L
        const val EFFECTIVE_VOLUME_RAMP_DOWN_MS = 180L
        const val EFFECTIVE_VOLUME_RAMP_MIN_DELTA = 0.015f
        const val PRIMARY_MIN_BUFFER_MS = 20_000
        const val PRIMARY_MAX_BUFFER_MS = 60_000
        const val PRIMARY_BUFFER_FOR_PLAYBACK_MS = 750
        const val PRIMARY_BUFFER_FOR_PLAYBACK_AFTER_REBUFFER_MS = 2_500
        const val MIN_AUDIBLE_EFFECTIVE_VOLUME = 0.01f
        const val STUCK_MUTED_VOLUME_EPSILON = 0.001f
        const val AUDIBLE_PLAYBACK_VOLUME_CHECK_MS = 2_000L
    }
}
