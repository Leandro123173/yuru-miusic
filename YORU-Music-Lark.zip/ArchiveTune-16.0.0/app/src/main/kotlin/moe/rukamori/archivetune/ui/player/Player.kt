/*
 * ArchiveTune (2026)
 * © Rukamori — github.com/rukamori
 * GPL-3.0 License | Contributors: see git history
 * Do not remove or alter this notice. - Per GPL-3.0 Section 4 & Section 5
 */

@file:OptIn(ExperimentalMaterial3ExpressiveApi::class)

package moe.rukamori.archivetune.ui.player

import android.content.Context
import android.database.ContentObserver
import android.graphics.Bitmap
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusGroup
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.painter.BitmapPainter
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.isShiftPressed
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.C
import androidx.media3.common.Player.STATE_BUFFERING
import androidx.media3.common.Player.STATE_ENDED
import androidx.media3.common.Player.STATE_READY
import androidx.navigation.NavController
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.palette.graphics.Palette
import coil3.compose.AsyncImage
import coil3.imageLoader
import coil3.request.CachePolicy
import coil3.request.ImageRequest
import coil3.request.SuccessResult
import coil3.request.allowHardware
import coil3.toBitmap
import dev.chrisbanes.haze.HazeState
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.withContext
import moe.rukamori.archivetune.LocalDownloadUtil
import moe.rukamori.archivetune.LocalPlayerConnection
import moe.rukamori.archivetune.R
import moe.rukamori.archivetune.canvas.CanvasPlaybackRequest
import moe.rukamori.archivetune.ui.utils.LocalIsTvDevice
import moe.rukamori.archivetune.ui.utils.navigateToAlbum
import moe.rukamori.archivetune.ui.utils.navigateToArtist
import moe.rukamori.archivetune.viewmodels.CanvasPlaybackViewModel
import moe.rukamori.archivetune.viewmodels.CanvasPlaybackState
import moe.rukamori.archivetune.viewmodels.ImmersivePlayerViewModel
import moe.rukamori.archivetune.viewmodels.LyricsSyncOffsetViewModel
import moe.rukamori.archivetune.viewmodels.QueueViewModel
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import moe.rukamori.archivetune.constants.BackdropBlurAmountKey
import moe.rukamori.archivetune.constants.BackdropEnabledKey
import moe.rukamori.archivetune.constants.BlurRadiusKey
import moe.rukamori.archivetune.constants.DarkModeKey
import moe.rukamori.archivetune.constants.DisableBlurKey
import moe.rukamori.archivetune.constants.EnableHapticFeedbackKey
import moe.rukamori.archivetune.constants.NavigationBarMode
import moe.rukamori.archivetune.constants.PlayerBackgroundStyle
import moe.rukamori.archivetune.ui.theme.LarkColors
import moe.rukamori.archivetune.constants.PlayerBackgroundStyleKey
import moe.rukamori.archivetune.constants.PlayerButtonsStyle
import moe.rukamori.archivetune.constants.PlayerButtonsStyleKey
import moe.rukamori.archivetune.constants.PlayerCustomBlurKey
import moe.rukamori.archivetune.constants.PlayerCustomBrightnessKey
import moe.rukamori.archivetune.constants.PlayerCustomContrastKey
import moe.rukamori.archivetune.constants.PlayerCustomImageUriKey
import moe.rukamori.archivetune.constants.PlayerDesignStyle
import moe.rukamori.archivetune.constants.PlayerDesignStyleKey
import moe.rukamori.archivetune.constants.QueuePeekHeight
import moe.rukamori.archivetune.constants.ShowPlayerVolumeBarKey
import moe.rukamori.archivetune.constants.SliderStyle
import moe.rukamori.archivetune.constants.SliderStyleKey
import moe.rukamori.archivetune.constants.ThumbnailCornerRadiusKey
import moe.rukamori.archivetune.extensions.metadata
import moe.rukamori.archivetune.extensions.togglePlayPause
import moe.rukamori.archivetune.models.MediaMetadata
import moe.rukamori.archivetune.ui.back.BackOwnershipPolicy
import moe.rukamori.archivetune.ui.component.BottomSheet
import moe.rukamori.archivetune.ui.component.BottomSheetState
import moe.rukamori.archivetune.ui.component.LocalBottomSheetPageState
import moe.rukamori.archivetune.ui.component.LocalMenuState
import moe.rukamori.archivetune.ui.component.EXPANDED_ANCHOR
import moe.rukamori.archivetune.ui.menu.AddToPlaylistDialog
import moe.rukamori.archivetune.ui.menu.PlayerMenu
import moe.rukamori.archivetune.ui.player.immersive.ImmersivePlayerEvent
import moe.rukamori.archivetune.ui.player.immersive.ImmersivePlayerScreen
import moe.rukamori.archivetune.ui.screens.LOGIN_ROUTE
import moe.rukamori.archivetune.ui.screens.buildLoginRoute
import moe.rukamori.archivetune.ui.screens.settings.DarkMode
import moe.rukamori.archivetune.ui.theme.PlayerColorExtractor
import android.widget.Toast
import com.materialkolor.ktx.toHct
import com.materialkolor.ktx.toColor
import moe.rukamori.archivetune.ui.utils.highRes
import moe.rukamori.archivetune.ui.utils.ShowMediaInfo
import moe.rukamori.archivetune.ui.utils.YtimgResizePolicy
import moe.rukamori.archivetune.ui.utils.getNextFallbackUrl
import moe.rukamori.archivetune.ui.utils.resize
import moe.rukamori.archivetune.ui.utils.tvFocusIndicationOrNull
import moe.rukamori.archivetune.utils.ImageBlurUtils
import moe.rukamori.archivetune.utils.makeTimeString
import moe.rukamori.archivetune.utils.rememberEnumPreference
import moe.rukamori.archivetune.utils.rememberLowDataModeActive
import moe.rukamori.archivetune.utils.rememberPreference
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.roundToLong

private const val SeekbarSettleToleranceMs = 1_500L
private const val V8BackdropArtworkSizePx = 1_024

@Stable
internal class DeviceMusicVolumeController(
    private val audioManager: AudioManager,
) {
    private var minVolume by mutableIntStateOf(readMinVolume())
    private var maxVolume by mutableIntStateOf(readMaxVolume())
    var volumeFraction by mutableFloatStateOf(readVolumeFraction())
        private set

    fun refresh() {
        minVolume = readMinVolume()
        maxVolume = readMaxVolume()
        volumeFraction = readVolumeFraction()
    }

    @JvmName("setDeviceMusicVolumeFraction")
    fun setVolumeFraction(fraction: Float) {
        val safeFraction = fraction.takeIf { it.isFinite() }?.coerceIn(0f, 1f) ?: volumeFraction
        val volumeRange = (maxVolume - minVolume).coerceAtLeast(1)
        val targetVolume =
            (minVolume + (safeFraction * volumeRange).roundToInt())
                .coerceIn(minVolume, maxVolume)

        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, targetVolume, 0)
        refresh()
    }

    private fun readVolumeFraction(): Float {
        val currentVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        val volumeRange = (maxVolume - minVolume).coerceAtLeast(1)
        return ((currentVolume - minVolume).toFloat() / volumeRange.toFloat()).coerceIn(0f, 1f)
    }

    private fun readMaxVolume(): Int {
        val streamMinVolume = readMinVolume()
        return audioManager
            .getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            .coerceAtLeast(streamMinVolume + 1)
    }

    private fun readMinVolume(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            audioManager.getStreamMinVolume(AudioManager.STREAM_MUSIC)
        } else {
            0
        }
}

@Composable
internal fun rememberDeviceMusicVolumeController(): DeviceMusicVolumeController {
    val context = LocalContext.current
    val audioManager =
        remember(context) {
            context.applicationContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        }
    val controller =
        remember(audioManager) {
            DeviceMusicVolumeController(audioManager)
        }

    DisposableEffect(context, controller) {
        val observer =
            object : ContentObserver(Handler(Looper.getMainLooper())) {
                override fun onChange(selfChange: Boolean) {
                    controller.refresh()
                }
            }
        val contentResolver = context.applicationContext.contentResolver
        contentResolver.registerContentObserver(Settings.System.CONTENT_URI, true, observer)
        controller.refresh()
        onDispose {
            contentResolver.unregisterContentObserver(observer)
        }
    }

    return controller
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BottomSheetPlayer(
    state: BottomSheetState,
    navController: NavController,
    hazeState: HazeState,
    modifier: Modifier = Modifier,
    pureBlack: Boolean,
    navigationProximityProvider: () -> Float = { 0f },
    navigationBarMode: NavigationBarMode = NavigationBarMode.CONNECTED,
    canvasViewModel: CanvasPlaybackViewModel = hiltViewModel(),
    immersivePlayerViewModel: ImmersivePlayerViewModel = hiltViewModel(),
    queueViewModel: QueueViewModel = hiltViewModel(),
    lyricsSyncOffsetViewModel: LyricsSyncOffsetViewModel = hiltViewModel(),
    focusRequester: FocusRequester = remember { FocusRequester() },
    exitLeftFocusRequester: FocusRequester? = null,
) {
    val context = LocalContext.current
    val menuState = LocalMenuState.current

    val bottomSheetPageState = LocalBottomSheetPageState.current

    val playerConnection = LocalPlayerConnection.current ?: return
    val immersivePlayerState by immersivePlayerViewModel.state.collectAsStateWithLifecycle()
    DisposableEffect(immersivePlayerViewModel, playerConnection) {
        immersivePlayerViewModel.bind(playerConnection)
        onDispose { immersivePlayerViewModel.unbind(playerConnection) }
    }
    val playbackError by playerConnection.error.collectAsStateWithLifecycle()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route
    val retryPlayback =
        remember(playerConnection) {
            {
                playerConnection.player.prepare()
                playerConnection.player.play()
            }
        }
    val dismissPlaybackError =
        remember(playerConnection) {
            playerConnection::dismissPlaybackError
        }
    val navigateToLogin: (String?) -> Unit =
        remember(navController) {
            { recoveryUrl ->
                navController.navigate(buildLoginRoute(recoveryUrl)) {
                    launchSingleTop = true
                }
            }
        }
    val playerDesignStyle by rememberEnumPreference(
        key = PlayerDesignStyleKey,
        defaultValue = PlayerDesignStyle.V4,
    )
    val showPlayerVolumeBar by rememberPreference(
        key = ShowPlayerVolumeBarKey,
        defaultValue = true,
    )

    val storedPlayerBackground by rememberEnumPreference(
        key = PlayerBackgroundStyleKey,
        defaultValue = PlayerBackgroundStyle.DEFAULT,
    )
    val playerUsesFixedBackground =
        playerDesignStyle == PlayerDesignStyle.V8 ||
            playerDesignStyle == PlayerDesignStyle.V9 ||
            playerDesignStyle == PlayerDesignStyle.V10 ||
            playerDesignStyle == PlayerDesignStyle.V11
    val playerBackground =
        if (playerUsesFixedBackground) PlayerBackgroundStyle.DEFAULT else storedPlayerBackground

    // Custom background preferences (image + effects)
    val (playerCustomImageUri) = rememberPreference(PlayerCustomImageUriKey, "")
    val (playerCustomBlur) = rememberPreference(PlayerCustomBlurKey, 0f)
    val (playerCustomContrast) = rememberPreference(PlayerCustomContrastKey, 1f)
    val (playerCustomBrightness) = rememberPreference(PlayerCustomBrightnessKey, 1f)

    val (disableBlur) = rememberPreference(DisableBlurKey, false)
    val (blurRadius) = rememberPreference(BlurRadiusKey, 48f)
    val (backdropEnabled) = rememberPreference(BackdropEnabledKey, defaultValue = true)
    val (backdropBlurAmount) = rememberPreference(BackdropBlurAmountKey, defaultValue = 60)
    val (showCodecOnPlayer) = rememberPreference(booleanPreferencesKey("show_codec_on_player"), false)
    val (incrementalSeekSkipEnabled) = rememberPreference(moe.rukamori.archivetune.constants.SeekExtraSeconds, defaultValue = false)
    var keyboardSkipMultiplier by remember { mutableStateOf(1) }
    var lastKeyboardTapTime by remember { mutableLongStateOf(0L) }

    val playerButtonsStyle by rememberEnumPreference(
        key = PlayerButtonsStyleKey,
        defaultValue = PlayerButtonsStyle.DEFAULT,
    )

    val isSystemInDarkTheme = isSystemInDarkTheme()
    val darkTheme by rememberEnumPreference(DarkModeKey, defaultValue = DarkMode.AUTO)
    val useDarkTheme =
        remember(darkTheme, isSystemInDarkTheme) {
            if (darkTheme == DarkMode.AUTO) isSystemInDarkTheme else darkTheme == DarkMode.ON
        }
    val onBackgroundColor =
        when (playerBackground) {
            PlayerBackgroundStyle.DEFAULT -> {
                LarkColors.PlayerPink
            }

            else -> {
                if (useDarkTheme) {
                    MaterialTheme.colorScheme.onSurface
                } else {
                    MaterialTheme.colorScheme.onPrimary
                }
            }
        }
    val useBlackBackground =
        remember(isSystemInDarkTheme, darkTheme, pureBlack) {
            val useDarkTheme =
                if (darkTheme == DarkMode.AUTO) isSystemInDarkTheme else darkTheme == DarkMode.ON
            useDarkTheme && pureBlack
        }
    val backgroundColor =
        if (useBlackBackground && state.value > state.collapsedBound) {
            val progress =
                ((state.value - state.collapsedBound) / (state.expandedBound - state.collapsedBound))
                    .coerceIn(0f, 1f)
            Color.Black.copy(alpha = progress)
        } else {
            val progress =
                ((state.value - state.collapsedBound) / (state.expandedBound - state.collapsedBound))
                    .coerceIn(0f, 1f)
            LarkColors.PlayerPurple.copy(alpha = progress)
        }

    val playbackState by playerConnection.playbackState.collectAsState()
    val isPlaying by playerConnection.isPlaying.collectAsState()
    val mediaMetadata by playerConnection.mediaMetadata.collectAsState()
    val currentSong by playerConnection.currentSong.collectAsState(initial = null)
    val currentSongLiked = currentSong?.song?.liked == true
    val queueTitle by playerConnection.queueTitle.collectAsState()
    val currentFormat by playerConnection.currentFormat.collectAsState(initial = null)
    val queue by playerConnection.queue.collectAsState()
    val deviceMusicVolumeController = rememberDeviceMusicVolumeController()
    val onPlayerVolumeChange =
        remember(deviceMusicVolumeController) {
            { volume: Float ->
                deviceMusicVolumeController.setVolumeFraction(volume)
            }
        }

    val repeatMode by playerConnection.repeatMode.collectAsState()

    val canSkipPrevious by playerConnection.canSkipPrevious.collectAsState()
    val canSkipNext by playerConnection.canSkipNext.collectAsState()

    val aodModeEnabled by playerConnection.aodModeEnabled.collectAsStateWithLifecycle()
    val currentLyricsEntity by playerConnection.currentLyrics.collectAsStateWithLifecycle(initialValue = null)
    val (thumbnailCornerRadius) = rememberPreference(ThumbnailCornerRadiusKey, defaultValue = 8f)
    val lowDataModeActive = rememberLowDataModeActive()
    val playerSwapState =
        rememberThumbnailSwapState(
            videoId = mediaMetadata?.id,
            ytmUrl = mediaMetadata?.thumbnailUrl?.highRes(),
            lowDataMode = lowDataModeActive,
            isMusicVideo = mediaMetadata?.isMusicVideo ?: false,
        )
    val sliderStyle by rememberEnumPreference(SliderStyleKey, SliderStyle.Standard)
    val canvasState by canvasViewModel.state.collectAsStateWithLifecycle()
    val canvasRequest = remember(mediaMetadata, playerDesignStyle, aodModeEnabled) {
        mediaMetadata?.takeIf {
            !aodModeEnabled &&
                playerDesignStyle != PlayerDesignStyle.V5 &&
                playerDesignStyle != PlayerDesignStyle.V7
        }?.let { metadata ->
            val country = Locale.getDefault().country
            CanvasPlaybackRequest(
                mediaId = metadata.id,
                title = metadata.title,
                artist = metadata.artists.firstOrNull()?.name.orEmpty(),
                storefront = if (country.length == 2) country.lowercase(Locale.ROOT) else "us",
                requireVertical = false,
            )
        }
    }
    LaunchedEffect(canvasViewModel, canvasRequest) {
        canvasViewModel.setRequest(canvasRequest)
    }
    DisposableEffect(canvasViewModel) {
        onDispose { canvasViewModel.setRequest(null) }
    }

    var position by rememberSaveable(mediaMetadata?.id) {
        mutableLongStateOf(playerConnection.player.currentPosition)
    }
    var duration by rememberSaveable(mediaMetadata?.id) {
        mutableLongStateOf(playerConnection.player.duration)
    }
    LaunchedEffect(lyricsSyncOffsetViewModel, mediaMetadata?.id) {
        lyricsSyncOffsetViewModel.setSongId(mediaMetadata?.id)
    }
    val lyricsSyncOffsetState by lyricsSyncOffsetViewModel.state.collectAsStateWithLifecycle()
    val lyricsSyncOffset = lyricsSyncOffsetState.offsetFor(mediaMetadata?.id)
    var sliderPosition by remember(mediaMetadata?.id) {
        mutableStateOf<Long?>(null)
    }
    var isUserSeeking by remember(mediaMetadata?.id) {
        mutableStateOf(false)
    }

    // Track loading state: when buffering or when user is seeking
    val isLoading = playbackState == STATE_BUFFERING || sliderPosition != null

    var gradientColors by remember {
        mutableStateOf<List<Color>>(emptyList())
    }

    // Exact seeds from artwork color scheme
    var artworkSeeds by remember {
        mutableStateOf<Pair<Color, Color>?>(null)
    }
    val artworkSeedsCache = remember { mutableMapOf<String, Pair<Color, Color>>() }

    // Previous background states for smooth transitions
    var previousThumbnailUrl by remember { mutableStateOf<String?>(null) }
    var previousGradientColors by remember { mutableStateOf<List<Color>>(emptyList()) }

    // Cache for gradient colors to prevent re-extraction for same songs
    val gradientColorsCache = remember { mutableMapOf<String, List<Color>>() }

    // Default gradient colors for fallback
    val defaultGradientColors = listOf(MaterialTheme.colorScheme.surface, MaterialTheme.colorScheme.surfaceVariant)
    val fallbackColor = MaterialTheme.colorScheme.surface.toArgb()

    // Update previous states when media changes
    LaunchedEffect(mediaMetadata?.id) {
        val currentThumbnail = mediaMetadata?.thumbnailUrl
        if (currentThumbnail != previousThumbnailUrl) {
            previousThumbnailUrl = currentThumbnail
            previousGradientColors = gradientColors
        }
    }

    LaunchedEffect(mediaMetadata?.id, playerSwapState.displayUrl, playerBackground, playerDesignStyle) {
        if (aodModeEnabled) return@LaunchedEffect
        if (playerDesignStyle == PlayerDesignStyle.V9 || playerDesignStyle == PlayerDesignStyle.V10 ||
            playerDesignStyle == PlayerDesignStyle.V11 ||
            playerBackground == PlayerBackgroundStyle.GRADIENT || playerBackground == PlayerBackgroundStyle.COLORING ||
            playerBackground == PlayerBackgroundStyle.BLUR_GRADIENT ||
            playerBackground == PlayerBackgroundStyle.GLOW ||
            playerBackground == PlayerBackgroundStyle.GLOW_ANIMATED
        ) {
            val currentMetadata = mediaMetadata
            val displayThumbnail = playerSwapState.displayUrl
            if (currentMetadata != null && displayThumbnail != null) {
                // Check cache first
                val cachedColors = gradientColorsCache[currentMetadata.id]
                val cachedSeeds = artworkSeedsCache[currentMetadata.id]
                if (cachedColors != null && cachedSeeds != null) {
                    gradientColors = cachedColors
                    artworkSeeds = cachedSeeds
                } else {
                    val request =
                        ImageRequest
                            .Builder(context)
                            .data(displayThumbnail)
                            .memoryCacheKey(displayThumbnail)
                            .diskCacheKey(displayThumbnail)
                            .diskCachePolicy(CachePolicy.ENABLED)
                            .networkCachePolicy(CachePolicy.ENABLED)
                            .size(PlayerColorExtractor.Config.IMAGE_SIZE, PlayerColorExtractor.Config.IMAGE_SIZE)
                            .allowHardware(false)
                            .build()

                    val result =
                        runCatching {
                            withContext(Dispatchers.IO) {
                                context.imageLoader.execute(request)
                            }
                        }.getOrNull()

                    if (result != null) {
                        val bitmap = result.image?.toBitmap()
                        if (bitmap != null) {
                            val palette =
                                withContext(Dispatchers.Default) {
                                    Palette
                                        .from(bitmap)
                                        .maximumColorCount(PlayerColorExtractor.Config.MAX_COLOR_COUNT)
                                        .resizeBitmapArea(PlayerColorExtractor.Config.BITMAP_AREA)
                                        .generate()
                                }

                            val extractedColors =
                                PlayerColorExtractor.extractGradientColors(
                                    palette = palette,
                                    fallbackColor = fallbackColor,
                                )

                            // EXACT artwork seeds extraction
                            val primarySeed = palette.vibrantSwatch
                                ?: palette.lightVibrantSwatch
                                ?: palette.darkVibrantSwatch
                                ?: palette.dominantSwatch
                            val secondarySeed = palette.mutedSwatch
                                ?: palette.lightMutedSwatch
                                ?: palette.darkMutedSwatch
                                ?: primarySeed

                            val seeds = if (primarySeed != null && secondarySeed != null) {
                                Pair(Color(primarySeed.rgb), Color(secondarySeed.rgb))
                            } else {
                                null
                            }

                            gradientColorsCache[currentMetadata.id] = extractedColors
                            gradientColors = extractedColors
                            if (seeds != null) {
                                artworkSeedsCache[currentMetadata.id] = seeds
                                artworkSeeds = seeds
                            }
                        } else {
                            gradientColors = defaultGradientColors
                        }
                    } else {
                        gradientColors = defaultGradientColors
                    }
                }
            } else {
                gradientColors = defaultGradientColors
            }
        } else {
            gradientColors = emptyList()
        }
    }

    val changeBound = state.expandedBound / 3

    val dominantColor = gradientColors.firstOrNull() ?: MaterialTheme.colorScheme.primary
    val targetBgColor = remember(dominantColor, useDarkTheme) {
        val hsv = FloatArray(3)
        android.graphics.Color.colorToHSV(dominantColor.toArgb(), hsv)
        if (useDarkTheme) {
            hsv[1] = hsv[1].coerceIn(0.12f, 0.35f)
            hsv[2] = 0.08f
        } else {
            hsv[1] = hsv[1].coerceIn(0.04f, 0.12f)
            hsv[2] = 0.96f
        }
        Color(android.graphics.Color.HSVToColor(hsv))
    }
    val dynamicBgColor by animateColorAsState(
        targetValue = targetBgColor,
        animationSpec = tween(durationMillis = 800),
        label = "dynamicBgColor"
    )

    val targetAccentColor = dominantColor
    val dynamicAccentColor by animateColorAsState(
        targetValue = targetAccentColor,
        animationSpec = tween(durationMillis = 800),
        label = "dynamicAccentColor"
    )

    // EXACT artwork accents using HCT (Hue-Chroma-Tone) for correct toning
    val targetV10FieldColor = remember(artworkSeeds, useDarkTheme) {
        val seeds = artworkSeeds
        if (seeds == null) {
            dominantColor
        } else {
            val hct = seeds.first.toHct()
            if (useDarkTheme) {
                // primaryContainer = primarySeed tone 30
                hct.withTone(30.0).toColor()
            } else {
                // primaryContainer = primarySeed tone 90
                hct.withTone(90.0).toColor()
            }
        }
    }

    val dynamicV10FieldColor by animateColorAsState(
        targetValue = targetV10FieldColor,
        animationSpec = tween(durationMillis = 800),
        label = "dynamicV10FieldColor"
    )

    val targetV10AccentColor = remember(artworkSeeds, useDarkTheme) {
        val seeds = artworkSeeds
        if (seeds == null) {
            dominantColor
        } else {
            val hct = seeds.first.toHct()
            if (useDarkTheme) {
                // onPrimaryContainer = primarySeed tone 90
                hct.withTone(90.0).toColor()
            } else {
                // onPrimaryContainer = primarySeed tone 10
                hct.withTone(10.0).toColor()
            }
        }
    }

    val dynamicV10AccentColor by animateColorAsState(
        targetValue = targetV10AccentColor,
        animationSpec = tween(durationMillis = 800),
        label = "dynamicV10AccentColor"
    )

    val v11BaseColorScheme = MaterialTheme.colorScheme
    val targetV11Palette =
        remember(artworkSeeds, useDarkTheme, v11BaseColorScheme) {
            v11PaletteFrom(artworkSeeds, useDarkTheme, v11BaseColorScheme)
        }
    val v11Palette = animateV11Palette(targetV11Palette)

    val targetTextColor = remember(dominantColor, useDarkTheme) {
        val hsv = FloatArray(3)
        android.graphics.Color.colorToHSV(dominantColor.toArgb(), hsv)
        if (useDarkTheme) {
            hsv[1] = hsv[1].coerceAtMost(0.12f)
            hsv[2] = 0.96f
        } else {
            hsv[1] = hsv[1].coerceIn(0.12f, 0.35f)
            hsv[2] = 0.08f
        }
        Color(android.graphics.Color.HSVToColor(hsv))
    }
    val dynamicTextColor by animateColorAsState(
        targetValue = targetTextColor,
        animationSpec = tween(durationMillis = 800),
        label = "dynamicTextColor"
    )

    val targetIconButtonColor = remember(dynamicAccentColor) {
        val luminance = 0.299f * dynamicAccentColor.red + 0.587f * dynamicAccentColor.green + 0.114f * dynamicAccentColor.blue
        if (luminance > 0.5f) Color.Black else Color.White
    }
    val dynamicIconButtonColor by animateColorAsState(
        targetValue = targetIconButtonColor,
        animationSpec = tween(durationMillis = 800),
        label = "dynamicIconButtonColor"
    )

    val TextBackgroundColor =
        if (playerDesignStyle == PlayerDesignStyle.V11) {
            v11Palette.onField
        } else if (playerDesignStyle == PlayerDesignStyle.V10) {
            dynamicV10AccentColor
        } else if (playerDesignStyle == PlayerDesignStyle.V9) {
            dynamicTextColor
        } else if (playerDesignStyle == PlayerDesignStyle.V7 || playerDesignStyle == PlayerDesignStyle.V8) {
            Color.White
        } else {
            when (playerBackground) {
                PlayerBackgroundStyle.DEFAULT -> LarkColors.PlayerPink
                PlayerBackgroundStyle.BLUR -> Color.White
                PlayerBackgroundStyle.GRADIENT -> Color.White
                PlayerBackgroundStyle.COLORING -> Color.White
                PlayerBackgroundStyle.BLUR_GRADIENT -> Color.White
                PlayerBackgroundStyle.GLOW -> Color.White
                PlayerBackgroundStyle.GLOW_ANIMATED -> Color.White
                PlayerBackgroundStyle.CUSTOM -> Color.White
            }
        }

    val icBackgroundColor =
        if (playerDesignStyle == PlayerDesignStyle.V11) {
            v11Palette.field
        } else if (playerDesignStyle == PlayerDesignStyle.V9 || playerDesignStyle == PlayerDesignStyle.V10) {
            dynamicBgColor
        } else if (playerDesignStyle == PlayerDesignStyle.V7 || playerDesignStyle == PlayerDesignStyle.V8) {
            Color.Black
        } else {
            when (playerBackground) {
                PlayerBackgroundStyle.DEFAULT -> LarkColors.PlayerPurple
                PlayerBackgroundStyle.BLUR -> Color.Black
                PlayerBackgroundStyle.GRADIENT -> Color.Black
                PlayerBackgroundStyle.COLORING -> Color.Black
                PlayerBackgroundStyle.BLUR_GRADIENT -> Color.Black
                PlayerBackgroundStyle.GLOW -> Color.Black
                PlayerBackgroundStyle.GLOW_ANIMATED -> Color.Black
                PlayerBackgroundStyle.CUSTOM -> Color.Black
            }
        }

    val (textButtonColor, iconButtonColor) =
        when (playerDesignStyle) {
            PlayerDesignStyle.V7, PlayerDesignStyle.V8 -> {
                Pair(Color.White, Color.Black)
            }

            PlayerDesignStyle.V9 -> {
                Pair(dynamicAccentColor, dynamicIconButtonColor)
            }

            PlayerDesignStyle.V10 -> {
                Pair(dynamicV10FieldColor, dynamicV10AccentColor)
            }

            PlayerDesignStyle.V11 -> {
                Pair(v11Palette.accent, v11Palette.onAccent)
            }

            else -> {
                when (playerButtonsStyle) {
                    PlayerButtonsStyle.DEFAULT -> {
                        Pair(TextBackgroundColor, icBackgroundColor)
                    }

                    PlayerButtonsStyle.SECONDARY -> {
                        Pair(
                            MaterialTheme.colorScheme.secondary,
                            MaterialTheme.colorScheme.onSecondary,
                        )
                    }
                }
            }
        }

    val download by LocalDownloadUtil.current
        .getDownload(mediaMetadata?.id ?: "")
        .collectAsState(initial = null)

    val sleepTimerEnabled =
        remember(
            playerConnection.service.sleepTimer.triggerTime,
            playerConnection.service.sleepTimer.pauseWhenSongEnd,
        ) {
            playerConnection.service.sleepTimer.isActive
        }

    var sleepTimerTimeLeft by remember {
        mutableLongStateOf(0L)
    }

    LaunchedEffect(sleepTimerEnabled) {
        if (sleepTimerEnabled) {
            while (isActive) {
                sleepTimerTimeLeft =
                    if (playerConnection.service.sleepTimer.pauseWhenSongEnd) {
                        playerConnection.player.duration - playerConnection.player.currentPosition
                    } else {
                        playerConnection.service.sleepTimer.triggerTime - System.currentTimeMillis()
                    }
                delay(1000L)
            }
        }
    }

    var showSleepTimerSheet by remember {
        mutableStateOf(false)
    }

    var sleepTimerValue by remember {
        mutableFloatStateOf(30f)
    }
    if (showSleepTimerSheet) {
        SleepTimerBottomSheet(
            value = sleepTimerValue,
            onValueChange = { sleepTimerValue = it },
            onDismiss = { showSleepTimerSheet = false },
            onStart = { minutes, finishCurrentSong, fadeOut ->
                playerConnection.service.sleepTimer.start(minutes, finishCurrentSong, fadeOut)
            },
        )
    }

    LaunchedEffect(immersivePlayerViewModel, navController, mediaMetadata, sleepTimerEnabled) {
        immersivePlayerViewModel.events.collect { event ->
            when (event) {
                is ImmersivePlayerEvent.OpenAlbum -> {
                    state.collapseSoft()
                    navController.navigateToAlbum(event.id)
                }
                is ImmersivePlayerEvent.OpenArtist -> {
                    state.collapseSoft()
                    navController.navigateToArtist(event.id)
                }
                ImmersivePlayerEvent.OpenMenu -> {
                    val metadata = mediaMetadata ?: return@collect
                    menuState.show {
                        PlayerMenu(
                            mediaMetadata = metadata,
                            navController = navController,
                            playerBottomSheetState = state,
                            sleepTimerEnabled = sleepTimerEnabled,
                            onSleepTimerClick = {
                                if (sleepTimerEnabled) {
                                    playerConnection.service.sleepTimer.clear()
                                } else {
                                    showSleepTimerSheet = true
                                }
                            },
                            onShowDetailsDialog = {
                                bottomSheetPageState.show { ShowMediaInfo(metadata.id) }
                            },
                            onDismiss = menuState::dismiss,
                        )
                    }
                }
            }
        }
    }

    var showChoosePlaylistDialog by rememberSaveable {
        mutableStateOf(false)
    }

    AddToPlaylistDialog(
        isVisible = showChoosePlaylistDialog,
        onGetSong = {
            mediaMetadata?.let { listOf(it.id) } ?: emptyList()
        },
        onDismiss = { showChoosePlaylistDialog = false },
        onAddComplete = { songCount, playlistNames ->
            val message =
                if (songCount == 1 && playlistNames.size == 1) {
                    context.getString(R.string.added_to_playlist, playlistNames.first())
                } else {
                    context.getString(R.string.added_to_n_playlists, playlistNames.size)
                }
            Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
            showChoosePlaylistDialog = false
        },
    )

    LaunchedEffect(mediaMetadata?.id, playbackState, aodModeEnabled) {
        val startTime = SystemClock.elapsedRealtime()
        if (playbackState == STATE_READY) {
            while (isActive) {
                delay(if (aodModeEnabled) 500L else 100L)
                val isTransitioning = playerConnection.player.currentMediaItem?.mediaId != mediaMetadata?.id
                val currentPlayerPosition = playerConnection.player.currentPosition
                val currentPlayerDuration = playerConnection.player.duration

                if (isTransitioning) {
                    val elapsedSinceStart = SystemClock.elapsedRealtime() - startTime
                    position = elapsedSinceStart
                    mediaMetadata?.let {
                        val metaDuration = it.duration.toLong() * 1000
                        duration = if (metaDuration > 0) metaDuration else 0L
                    }
                } else {
                    position = currentPlayerPosition
                    if (currentPlayerDuration > 0L && currentPlayerDuration != C.TIME_UNSET) {
                        duration = currentPlayerDuration
                    } else if (duration <= 0L || duration == C.TIME_UNSET) {
                        mediaMetadata?.let {
                            val metadataDuration = it.duration.toLong() * 1000
                            if (metadataDuration > 0L) duration = metadataDuration
                        }
                    }
                    if (!isUserSeeking) {
                        sliderPosition?.let { targetPosition ->
                            val clampedTargetPosition =
                                when {
                                    currentPlayerDuration > 0L && currentPlayerDuration != C.TIME_UNSET -> {
                                        targetPosition.coerceIn(0L, currentPlayerDuration)
                                    }

                                    else -> {
                                        targetPosition.coerceAtLeast(0L)
                                    }
                                }
                            if (abs(currentPlayerPosition - clampedTargetPosition) <= SeekbarSettleToleranceMs) {
                                sliderPosition = null
                            }
                        }
                    }
                }
            }
        } else {
            mediaMetadata?.let {
                val metaDuration = it.duration.toLong() * 1000
                duration = if (metaDuration > 0) metaDuration else 0L
            }
            val currentPlayerPosition = playerConnection.player.currentPosition
            if (sliderPosition == null && currentPlayerPosition > 0L) {
                position = currentPlayerPosition
            }
        }
    }


    val queueVisible by queueViewModel.isQueueVisible.collectAsStateWithLifecycle()

    LaunchedEffect(state, queueViewModel) {
        snapshotFlow { state.targetAnchor }.drop(1).collect { anchor ->
            if (anchor != EXPANDED_ANCHOR) queueViewModel.dismissQueue()
        }
    }
    LaunchedEffect(aodModeEnabled, queueViewModel) {
        if (aodModeEnabled) queueViewModel.dismissQueue()
    }

    var isLyricsScreenVisible by rememberSaveable {
        mutableStateOf(false)
    }
    val openQueue =
        remember(state, queueViewModel) {
            {
                isLyricsScreenVisible = false
                if (!state.isExpandedOrExpanding) {
                    state.expandSoft()
                }
                queueViewModel.openQueue()
            }
        }

    BackHandler(
        enabled =
            BackOwnershipPolicy.playerHandlesBack(
                aodModeEnabled = aodModeEnabled,
                queueVisible = queueVisible,
                isExpandedOrExpanding = state.isExpandedOrExpanding,
            ),
    ) {
        if (isLyricsScreenVisible) {
            isLyricsScreenVisible = false
        } else {
            state.collapseSoft()
        }
    }

    val isTvDevice = LocalIsTvDevice.current
    var isSheetSelfFocused by remember { mutableStateOf(false) }
    var expandedPlayerHeldFocus by remember { mutableStateOf(false) }

    LaunchedEffect(state.isExpanded) {
        if (state.isExpanded) {
            expandedPlayerHeldFocus = focusRequester.requestFocus()
        }
        if (!state.isExpanded && aodModeEnabled) {
            playerConnection.aodModeEnabled.value = false
        }
    }

    LaunchedEffect(state.isCollapsed, isTvDevice) {
        if (isTvDevice && state.isCollapsed && expandedPlayerHeldFocus) {
            expandedPlayerHeldFocus = false
            focusRequester.requestFocus()
        }
    }

    BottomSheet(
        state = state,
        modifier =
            modifier
                .focusRequester(focusRequester)
                .focusProperties {
                    onExit = {
                        if (state.isExpandedOrExpanding) {
                            val railTarget = exitLeftFocusRequester
                            when (requestedFocusDirection) {
                                FocusDirection.Left -> {
                                    if (railTarget != null) railTarget.requestFocus() else cancelFocusChange()
                                }

                                FocusDirection.Up,
                                FocusDirection.Down,
                                FocusDirection.Right,
                                FocusDirection.Next,
                                FocusDirection.Previous,
                                -> {
                                    cancelFocusChange()
                                }

                                else -> {}
                            }
                        }
                    }
                }.onFocusChanged { focusState ->
                    isSheetSelfFocused = focusState.isFocused
                    if (!state.isCollapsed) {
                        expandedPlayerHeldFocus = focusState.hasFocus
                    }
                }.then(if (isTvDevice) Modifier.focusGroup() else Modifier.focusable())
                .onKeyEvent { keyEvent ->
                    if (keyEvent.type != KeyEventType.KeyDown || state.isCollapsed) return@onKeyEvent false
                    val isDirectionalKey =
                        keyEvent.key == Key.DirectionLeft ||
                            keyEvent.key == Key.DirectionRight ||
                            keyEvent.key == Key.DirectionUp ||
                            keyEvent.key == Key.DirectionDown
                    if (isDirectionalKey && !isSheetSelfFocused) return@onKeyEvent false

                    when (keyEvent.key) {
                        Key.DirectionLeft -> {
                            val now = SystemClock.uptimeMillis()
                            if (incrementalSeekSkipEnabled && now - lastKeyboardTapTime < 1000) {
                                keyboardSkipMultiplier++
                            } else {
                                keyboardSkipMultiplier = 1
                            }
                            lastKeyboardTapTime = now
                            val skipAmount = 5000L * keyboardSkipMultiplier
                            playerConnection.player.seekTo((playerConnection.player.currentPosition - skipAmount).coerceAtLeast(0))
                            true
                        }

                        Key.DirectionRight -> {
                            val now = SystemClock.uptimeMillis()
                            if (incrementalSeekSkipEnabled && now - lastKeyboardTapTime < 1000) {
                                keyboardSkipMultiplier++
                            } else {
                                keyboardSkipMultiplier = 1
                            }
                            lastKeyboardTapTime = now
                            val skipAmount = 5000L * keyboardSkipMultiplier
                            playerConnection.player.seekTo(
                                (playerConnection.player.currentPosition + skipAmount).coerceAtMost(playerConnection.player.duration),
                            )
                            true
                        }

                        Key.DirectionUp -> {
                            deviceMusicVolumeController.setVolumeFraction(
                                (deviceMusicVolumeController.volumeFraction + 0.05f).coerceAtMost(1f),
                            )
                            true
                        }

                        Key.DirectionDown -> {
                            deviceMusicVolumeController.setVolumeFraction(
                                (deviceMusicVolumeController.volumeFraction - 0.05f).coerceAtLeast(0f),
                            )
                            true
                        }

                        Key.Spacebar -> {
                            playerConnection.player.togglePlayPause()
                            true
                        }

                        Key.N -> {
                            if (keyEvent.isShiftPressed) {
                                playerConnection.seekToNext()
                                true
                            } else {
                                false
                            }
                        }

                        Key.P -> {
                            if (keyEvent.isShiftPressed) {
                                playerConnection.seekToPrevious()
                                true
                            } else {
                                false
                            }
                        }

                        Key.L -> {
                            playerConnection.toggleLike()
                            true
                        }

                        else -> {
                            false
                        }
                    }
                },
        backgroundColor =
            run {
                val progress =
                    ((state.value - state.collapsedBound) / (state.expandedBound - state.collapsedBound))
                        .coerceIn(0f, 1f)
                val fadeProgress =
                    if (progress < 0.2f) {
                        ((0.2f - progress) / 0.2f).coerceIn(0f, 1f)
                    } else {
                        0f
                    }
                val sheetColor =
                    when {
                        playerDesignStyle == PlayerDesignStyle.V9 -> dynamicBgColor
                        playerDesignStyle == PlayerDesignStyle.V10 -> dynamicV10FieldColor
                        playerDesignStyle == PlayerDesignStyle.V11 -> v11Palette.field
                        playerDesignStyle == PlayerDesignStyle.V7 || playerDesignStyle == PlayerDesignStyle.V8 -> Color.Black
                        playerBackground == PlayerBackgroundStyle.BLUR || playerBackground == PlayerBackgroundStyle.GRADIENT ->
                            MaterialTheme.colorScheme.surface
                        useBlackBackground -> Color.Black
                        else -> MaterialTheme.colorScheme.surface
                    }
                sheetColor.copy(alpha = 1f - fadeProgress)
            },
        onDismiss = {
            playerConnection.service.stopAndClearPlayback(clearPersistentState = true)
        },
        backHandlerEnabled = false,
        collapsedContent = {
            MiniPlayer(
                position = position,
                duration = duration,
                hazeState = hazeState,
                pureBlack = pureBlack,
                navigationProximityProvider = navigationProximityProvider,
                navigationBarMode = navigationBarMode,
            )
        },
    ) {
        val onSliderValueChange: (Long) -> Unit = {
            isUserSeeking = true
            sliderPosition = it
        }
        val onSliderValueChangeFinished: () -> Unit = {
            sliderPosition?.let {
                val isTransitioning = playerConnection.player.currentMediaItem?.mediaId != mediaMetadata?.id
                if (isTransitioning) {
                    // During crossfade, we want to seek in the NEXT song (the one UI is showing)
                    // The easiest way is to skip to it and then seek
                    playerConnection.player.seekToNext()
                    playerConnection.player.seekTo(it)
                } else {
                    playerConnection.player.seekTo(it)
                }
                position = it
            }
            isUserSeeking = false
        }
        val seekEnabled = duration > 0L && duration != C.TIME_UNSET
        val updatedOnSliderValueChange by rememberUpdatedState(onSliderValueChange)
        val updatedOnSliderValueChangeFinished by rememberUpdatedState(onSliderValueChangeFinished)

        val nextUpMetadata =
            remember(queue) {
                queue.windows.getOrNull(queue.currentIndex + 1)?.mediaItem?.metadata
            }

        val enrichedMetadata =
            remember(mediaMetadata, currentSong) {
                val meta = mediaMetadata ?: return@remember null
                if (meta.album != null) return@remember meta
                val dbAlbum = currentSong?.album
                val dbAlbumId = currentSong?.song?.albumId
                when {
                    dbAlbum != null -> {
                        meta.copy(
                            album = MediaMetadata.Album(id = dbAlbum.id, title = dbAlbum.title),
                        )
                    }

                    dbAlbumId != null -> {
                        meta.copy(
                            album =
                                MediaMetadata.Album(
                                    id = dbAlbumId,
                                    title = currentSong?.song?.albumName.orEmpty(),
                                ),
                        )
                    }

                    else -> {
                        meta
                    }
                }
            }

        val resolvedCanvas = (canvasState as? CanvasPlaybackState.Success)
            ?.takeIf { it.request == canvasRequest }
            ?.video
        val artworkCanvas = resolvedCanvas

        val onPlayerSleepTimerClick: () -> Unit = {
            if (sleepTimerEnabled) {
                playerConnection.service.sleepTimer.clear()
            } else {
                showSleepTimerSheet = true
            }
        }
        val showPlayerMenu: (MediaMetadata) -> Unit = { metadata ->
            menuState.show {
                PlayerMenu(
                    mediaMetadata = metadata,
                    navController = navController,
                    playerBottomSheetState = state,
                    sleepTimerEnabled = sleepTimerEnabled,
                    onSleepTimerClick = onPlayerSleepTimerClick,
                    onShowDetailsDialog = {
                        bottomSheetPageState.show {
                            ShowMediaInfo(metadata.id)
                        }
                    },
                    onDismiss = menuState::dismiss,
                )
            }
        }

        val controlsContent: @Composable ColumnScope.(MediaMetadata, Boolean) -> Unit = { mediaMetadata, landscape ->
            PlayerControlsContent(
                mediaMetadata = mediaMetadata,
                playerDesignStyle = playerDesignStyle,
                sliderStyle = sliderStyle,
                playbackState = playbackState,
                isPlaying = isPlaying,
                isLoading = isLoading,
                repeatMode = repeatMode,
                canSkipPrevious = canSkipPrevious,
                canSkipNext = canSkipNext,
                textButtonColor = textButtonColor,
                iconButtonColor = iconButtonColor,
                textBackgroundColor = TextBackgroundColor,
                icBackgroundColor = icBackgroundColor,
                sliderPosition = sliderPosition,
                position = position,
                duration = duration,
                playerConnection = playerConnection,
                navController = navController,
                state = state,
                menuState = menuState,
                bottomSheetPageState = bottomSheetPageState,
                context = context,
                onSliderValueChange = onSliderValueChange,
                onSliderValueChangeFinished = onSliderValueChangeFinished,
                currentFormat = if (playerDesignStyle == PlayerDesignStyle.V7) currentFormat else null,
                landscape = landscape,
            )
        }

        if (!state.isCollapsed &&
            !aodModeEnabled &&
            playerDesignStyle != PlayerDesignStyle.V5 &&
            playerDesignStyle != PlayerDesignStyle.V7 &&
            playerDesignStyle != PlayerDesignStyle.V8 &&
            playerDesignStyle != PlayerDesignStyle.V9 &&
            playerDesignStyle != PlayerDesignStyle.V10 &&
            playerDesignStyle != PlayerDesignStyle.V11
        ) {
            PlayerBackground(
                playerBackground = playerBackground,
                mediaMetadata = mediaMetadata,
                gradientColors = gradientColors,
                disableBlur = disableBlur,
                blurRadius = blurRadius,
                playerCustomImageUri = playerCustomImageUri,
                playerCustomBlur = playerCustomBlur,
                playerCustomContrast = playerCustomContrast,
                playerCustomBrightness = playerCustomBrightness,
            )
        }

// distance

        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val isLandscape = maxWidth > maxHeight
            val isPortrait = !isLandscape

            val dynamicQueuePeekHeight =
                if (playerDesignStyle == PlayerDesignStyle.V5 || playerDesignStyle == PlayerDesignStyle.V11) {
                    0.dp
                } else if (playerDesignStyle == PlayerDesignStyle.V9) {
                    88.dp +
                        (if (showCodecOnPlayer) 24.dp else 0.dp) +
                        (if (sleepTimerEnabled) 42.dp else 0.dp)
                } else if (playerDesignStyle == PlayerDesignStyle.V10) {
                    if (isPortrait) (if (showCodecOnPlayer) 94.dp else 78.dp) else 0.dp
                } else if (playerDesignStyle == PlayerDesignStyle.V7) {
                    72.dp
                } else if (showCodecOnPlayer) {
                    88.dp
                } else {
                    QueuePeekHeight
                }

            val queueCollapsedHeight = dynamicQueuePeekHeight + WindowInsets.systemBars.asPaddingValues().calculateBottomPadding()
            val v11Content: @Composable (Boolean) -> Unit = { landscape ->
                enrichedMetadata?.let { metadata ->
                    V11PlayerContent(
                        mediaMetadata = metadata,
                        playbackState = playbackState,
                        isPlaying = isPlaying,
                        canSkipPrevious = canSkipPrevious,
                        canSkipNext = canSkipNext,
                        sliderPosition = sliderPosition,
                        position = position,
                        duration = duration,
                        playerConnection = playerConnection,
                        navController = navController,
                        state = state,
                        palette = v11Palette,
                        queueTitle = queueTitle,
                        currentSongLiked = currentSongLiked,
                        canvasSource = artworkCanvas?.source,
                        canvasPrimaryUrl = artworkCanvas?.animated,
                        canvasFallbackUrl = artworkCanvas?.videoUrl,
                        sleepTimerEnabled = sleepTimerEnabled,
                        sleepTimerTimeLeft = sleepTimerTimeLeft,
                        onCollapseClick = { state.collapseSoft() },
                        onQueueClick = openQueue,
                        onLyricsClick = { isLyricsScreenVisible = true },
                        onSliderValueChange = onSliderValueChange,
                        onSliderValueChangeFinished = onSliderValueChangeFinished,
                        onSleepTimerClick = onPlayerSleepTimerClick,
                        onMenuClick = { showPlayerMenu(metadata) },
                        onAddToPlaylistClick = { showChoosePlaylistDialog = true },
                        landscape = landscape,
                        modifier =
                            Modifier
                                .fillMaxSize()
                                .padding(bottom = queueCollapsedHeight)
                                .windowInsetsPadding(
                                    WindowInsets.systemBars.only(
                                        WindowInsetsSides.Top + WindowInsetsSides.Horizontal,
                                    ),
                                ).nestedScroll(state.preUpPostDownNestedScrollConnection),
                    )
                }
            }

            if (isLandscape) {
                if (playerDesignStyle == PlayerDesignStyle.V5) {
                    val littleBackground = MaterialTheme.colorScheme.primaryContainer
                    val littleTextColor = MaterialTheme.colorScheme.onPrimaryContainer
                    val displayPositionMs = sliderPosition ?: position
                    val progressFraction =
                        remember(displayPositionMs, duration) {
                            if (duration <= 0L || duration == C.TIME_UNSET) {
                                0f
                            } else {
                                (displayPositionMs.toFloat() / duration.toFloat()).coerceIn(0f, 1f)
                            }
                        }
                    val progressOverlayColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.28f)

                    Box(
                        modifier =
                            Modifier
                                .fillMaxSize()
                                .background(littleBackground),
                    ) {
                        Box(
                            modifier =
                                Modifier
                                    .fillMaxWidth()
                                    .fillMaxHeight(progressFraction)
                                    .align(Alignment.TopStart)
                                    .background(progressOverlayColor),
                        )
                        Box(
                            modifier =
                                Modifier
                                    .fillMaxSize()
                                    .littlePlayerOverlayGestures(
                                        seekEnabled = seekEnabled,
                                        durationMs = duration,
                                        progressFraction = progressFraction,
                                        canSkipPrevious = canSkipPrevious,
                                        canSkipNext = canSkipNext,
                                        onSeekToPositionMs = updatedOnSliderValueChange,
                                        onSeekFinished = updatedOnSliderValueChangeFinished,
                                        onSkipPrevious = playerConnection::seekToPrevious,
                                        onSkipNext = playerConnection::seekToNext,
                                    ).windowInsetsPadding(
                                        WindowInsets.systemBars.only(
                                            WindowInsetsSides.Horizontal + WindowInsetsSides.Top + WindowInsetsSides.Bottom,
                                        ),
                                    ),
                        ) {
                            enrichedMetadata?.let { metadata ->
                                LittlePlayerContent(
                                    mediaMetadata = metadata,
                                    sliderPosition = sliderPosition,
                                    positionMs = position,
                                    durationMs = duration,
                                    textColor = littleTextColor,
                                    liked = currentSongLiked,
                                    onCollapse = state::collapseSoft,
                                    onToggleLike = playerConnection::toggleLike,
                                    onExpandQueue = openQueue,
                                    onMenuClick = {
                                        menuState.show {
                                            PlayerMenu(
                                                mediaMetadata = metadata,
                                                navController = navController,
                                                playerBottomSheetState = state,
                                                sleepTimerEnabled = sleepTimerEnabled,
                                                onSleepTimerClick = {
                                                    if (sleepTimerEnabled) {
                                                        playerConnection.service.sleepTimer.clear()
                                                    } else {
                                                        showSleepTimerSheet = true
                                                    }
                                                },
                                                onShowDetailsDialog = {
                                                    bottomSheetPageState.show {
                                                        ShowMediaInfo(metadata.id)
                                                    }
                                                },
                                                onDismiss = menuState::dismiss,
                                            )
                                        }
                                    },
                                )
                            }
                        }
                    }
                } else if (playerDesignStyle == PlayerDesignStyle.V7) {
                    ImmersivePlayerScreen(
                        state = immersivePlayerState,
                        disableBlur = disableBlur,
                        backdropBlurAmount = backdropBlurAmount,
                        showVolumeBar = showPlayerVolumeBar,
                        showCodecOnPlayer = showCodecOnPlayer,
                        contentBottomPadding = queueCollapsedHeight,
                        onAction = immersivePlayerViewModel::onAction,
                        modifier =
                            Modifier
                                .fillMaxSize()
                                .nestedScroll(state.preUpPostDownNestedScrollConnection),
                    )
                } else if (playerDesignStyle == PlayerDesignStyle.V8) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                    ) {
                        val v8SwapState =
                            rememberThumbnailSwapState(
                                videoId = mediaMetadata?.id,
                                ytmUrl = mediaMetadata?.thumbnailUrl,
                                lowDataMode = lowDataModeActive,
                                isMusicVideo = mediaMetadata?.isMusicVideo ?: false,
                            )
                        V8PlayerBackdrop(
                            thumbnailUrl = v8SwapState.displayUrl,
                            backdropBlurAmount = backdropBlurAmount,
                        )

                        enrichedMetadata?.let { metadata ->
                            V8PlayerContent(
                                mediaMetadata = metadata,
                                queueTitle = queueTitle,
                                playbackState = playbackState,
                                isPlaying = isPlaying,
                                isLoading = isLoading,
                                canSkipPrevious = canSkipPrevious,
                                canSkipNext = canSkipNext,
                                currentSongLiked = currentSongLiked,
                                sliderPosition = sliderPosition,
                                position = position,
                                duration = duration,
                                volume = deviceMusicVolumeController.volumeFraction,
                                showVolumeBar = showPlayerVolumeBar,
                                playerConnection = playerConnection,
                                navController = navController,
                                state = state,
                                menuState = menuState,
                                bottomSheetPageState = bottomSheetPageState,
                                currentFormat = currentFormat,
                                canvasSource = artworkCanvas?.source,
                                canvasPrimaryUrl = artworkCanvas?.animated,
                                canvasFallbackUrl = artworkCanvas?.videoUrl,
                                onSliderValueChange = onSliderValueChange,
                                onSliderValueChangeFinished = onSliderValueChangeFinished,
                                onVolumeChange = onPlayerVolumeChange,
                                landscape = true,
                                modifier =
                                    Modifier
                                        .fillMaxSize()
                                        .padding(bottom = queueCollapsedHeight)
                                        .windowInsetsPadding(
                                            WindowInsets.systemBars.only(
                                                WindowInsetsSides.Top + WindowInsetsSides.Horizontal,
                                            ),
                                        ).nestedScroll(state.preUpPostDownNestedScrollConnection),
                            )
                        }
                    }
                } else if (playerDesignStyle == PlayerDesignStyle.V9) {
                    enrichedMetadata?.let { metadata ->
                        V9PlayerContent(
                            mediaMetadata = metadata,
                            playbackState = playbackState,
                            isPlaying = isPlaying,
                            isLoading = isLoading,
                            canSkipPrevious = canSkipPrevious,
                            canSkipNext = canSkipNext,
                            sliderPosition = sliderPosition,
                            position = position,
                            duration = duration,
                            playerConnection = playerConnection,
                            navController = navController,
                            state = state,
                            textBackgroundColor = TextBackgroundColor,
                            textButtonColor = textButtonColor,
                            iconButtonColor = iconButtonColor,
                            canvasSource = artworkCanvas?.source,
                            canvasPrimaryUrl = artworkCanvas?.animated,
                            canvasFallbackUrl = artworkCanvas?.videoUrl,
                            onCollapseClick = { state.collapseSoft() },
                            onQueueClick = openQueue,
                            onLyricsClick = { isLyricsScreenVisible = true },
                            onSliderValueChange = onSliderValueChange,
                            onSliderValueChangeFinished = onSliderValueChangeFinished,
                            landscape = true,
                            gradientColors = gradientColors,
                            modifier =
                                Modifier
                                    .fillMaxSize()
                                    .padding(bottom = queueCollapsedHeight)
                                    .windowInsetsPadding(
                                        WindowInsets.systemBars.only(
                                            WindowInsetsSides.Top + WindowInsetsSides.Horizontal,
                                        ),
                                    ).nestedScroll(state.preUpPostDownNestedScrollConnection),
                        )
                    }
                } else if (playerDesignStyle == PlayerDesignStyle.V10) {
                    enrichedMetadata?.let { metadata ->
                        V10PlayerContent(
                            mediaMetadata = metadata,
                            playbackState = playbackState,
                            isPlaying = isPlaying,
                            isLoading = isLoading,
                            canSkipPrevious = canSkipPrevious,
                            canSkipNext = canSkipNext,
                            sliderPosition = sliderPosition,
                            position = position,
                            duration = duration,
                            playerConnection = playerConnection,
                            navController = navController,
                            state = state,
                            textBackgroundColor = dynamicV10AccentColor,
                            textButtonColor = dynamicV10FieldColor,
                            iconButtonColor = iconButtonColor,
                            onCollapseClick = { state.collapseSoft() },
                            onQueueClick = openQueue,
                            onLyricsClick = { isLyricsScreenVisible = true },
                            onSliderValueChange = onSliderValueChange,
                            onSliderValueChangeFinished = onSliderValueChangeFinished,
                            onSleepTimerClick = {
                                if (sleepTimerEnabled) {
                                    playerConnection.service.sleepTimer.clear()
                                } else {
                                    showSleepTimerSheet = true
                                }
                            },
                            sleepTimerEnabled = sleepTimerEnabled,
                            sleepTimerTimeLeft = sleepTimerTimeLeft,
                            onMenuClick = {
                                menuState.show {
                                    PlayerMenu(
                                        mediaMetadata = metadata,
                                        navController = navController,
                                        playerBottomSheetState = state,
                                        sleepTimerEnabled = sleepTimerEnabled,
                                        onSleepTimerClick = {
                                            if (sleepTimerEnabled) {
                                                playerConnection.service.sleepTimer.clear()
                                            } else {
                                                showSleepTimerSheet = true
                                            }
                                        },
                                        onShowDetailsDialog = {
                                            bottomSheetPageState.show {
                                                ShowMediaInfo(metadata.id)
                                            }
                                        },
                                        onDismiss = menuState::dismiss,
                                    )
                                }
                            },
                            onAddToPlaylistClick = {
                                showChoosePlaylistDialog = true
                            },
                            landscape = true,
                            modifier =
                                Modifier
                                    .fillMaxSize()
                                    .padding(bottom = queueCollapsedHeight)
                                    .windowInsetsPadding(
                                        WindowInsets.systemBars.only(
                                            WindowInsetsSides.Top + WindowInsetsSides.Horizontal,
                                        ),
                                    )
                                    .nestedScroll(state.preUpPostDownNestedScrollConnection),
                        )
                    }
                } else if (playerDesignStyle == PlayerDesignStyle.V11) {
                    v11Content(true)
                } else {
                    LandscapePlayerLayout(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(bottom = queueCollapsedHeight)
                            .windowInsetsPadding(
                                WindowInsets.systemBars.only(WindowInsetsSides.Top + WindowInsetsSides.Horizontal),
                            ),
                        artwork = {
                            Thumbnail(
                                canvas = artworkCanvas,
                                sliderPositionProvider = { sliderPosition },
                                modifier = Modifier.fillMaxSize(),
                                isPlayerExpanded = state.isExpanded,
                                applyStatusBarPadding = false,
                            )
                        },
                        controls = {
                            Column(modifier = Modifier.fillMaxSize()) {
                                enrichedMetadata?.let { controlsContent(it, true) }
                            }
                        },
                    )
                }
            } else {
                if (playerDesignStyle == PlayerDesignStyle.V5) {
                    val littleBackground = MaterialTheme.colorScheme.primaryContainer
                    val littleTextColor = MaterialTheme.colorScheme.onPrimaryContainer
                    val displayPositionMs = sliderPosition ?: position
                    val progressFraction =
                        remember(displayPositionMs, duration) {
                            if (duration <= 0L || duration == C.TIME_UNSET) {
                                0f
                            } else {
                                (displayPositionMs.toFloat() / duration.toFloat()).coerceIn(0f, 1f)
                            }
                        }
                    val progressOverlayColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.28f)
                    val seekEnabled = duration > 0L && duration != C.TIME_UNSET

                    Box(
                        modifier =
                            Modifier
                                .fillMaxSize()
                                .background(littleBackground),
                    ) {
                        Box(
                            modifier =
                                Modifier
                                    .fillMaxWidth()
                                    .fillMaxHeight(progressFraction)
                                    .align(Alignment.TopStart)
                                    .background(progressOverlayColor),
                        )
                        Box(
                            modifier =
                                Modifier
                                    .fillMaxSize()
                                    .littlePlayerOverlayGestures(
                                        seekEnabled = seekEnabled,
                                        durationMs = duration,
                                        progressFraction = progressFraction,
                                        canSkipPrevious = canSkipPrevious,
                                        canSkipNext = canSkipNext,
                                        onSeekToPositionMs = updatedOnSliderValueChange,
                                        onSeekFinished = updatedOnSliderValueChangeFinished,
                                        onSkipPrevious = playerConnection::seekToPrevious,
                                        onSkipNext = playerConnection::seekToNext,
                                    ).windowInsetsPadding(
                                        WindowInsets.systemBars.only(
                                            WindowInsetsSides.Horizontal + WindowInsetsSides.Top + WindowInsetsSides.Bottom,
                                        ),
                                    ),
                        ) {
                            enrichedMetadata?.let { metadata ->
                                LandscapeLikeBox(modifier = Modifier.fillMaxSize()) {
                                    LittlePlayerContent(
                                        mediaMetadata = metadata,
                                        sliderPosition = sliderPosition,
                                        positionMs = position,
                                        durationMs = duration,
                                        textColor = littleTextColor,
                                        liked = currentSongLiked,
                                        onCollapse = state::collapseSoft,
                                        onToggleLike = playerConnection::toggleLike,
                                        onExpandQueue = openQueue,
                                        onMenuClick = {
                                            menuState.show {
                                                PlayerMenu(
                                                    mediaMetadata = metadata,
                                                    navController = navController,
                                                    playerBottomSheetState = state,
                                                    sleepTimerEnabled = sleepTimerEnabled,
                                                    onSleepTimerClick = {
                                                        if (sleepTimerEnabled) {
                                                            playerConnection.service.sleepTimer.clear()
                                                        } else {
                                                            showSleepTimerSheet = true
                                                        }
                                                    },
                                                    onShowDetailsDialog = {
                                                        bottomSheetPageState.show {
                                                            ShowMediaInfo(metadata.id)
                                                        }
                                                    },
                                                    onDismiss = menuState::dismiss,
                                                )
                                            }
                                        },
                                    )
                                }
                            }
                        }
                    }
                } else if (playerDesignStyle == PlayerDesignStyle.V7) {
                    ImmersivePlayerScreen(
                        state = immersivePlayerState,
                        disableBlur = disableBlur,
                        backdropBlurAmount = backdropBlurAmount,
                        showVolumeBar = showPlayerVolumeBar,
                        showCodecOnPlayer = showCodecOnPlayer,
                        contentBottomPadding = queueCollapsedHeight,
                        onAction = immersivePlayerViewModel::onAction,
                        modifier =
                            Modifier
                                .fillMaxSize()
                                .nestedScroll(state.preUpPostDownNestedScrollConnection),
                    )
                } else if (playerDesignStyle == PlayerDesignStyle.V8) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                    ) {
                        val v8SwapState =
                            rememberThumbnailSwapState(
                                videoId = mediaMetadata?.id,
                                ytmUrl = mediaMetadata?.thumbnailUrl,
                                lowDataMode = lowDataModeActive,
                                isMusicVideo = mediaMetadata?.isMusicVideo ?: false,
                            )
                        V8PlayerBackdrop(
                            thumbnailUrl = v8SwapState.displayUrl,
                            backdropBlurAmount = backdropBlurAmount,
                        )

                        enrichedMetadata?.let { metadata ->
                            V8PlayerContent(
                                mediaMetadata = metadata,
                                queueTitle = queueTitle,
                                playbackState = playbackState,
                                isPlaying = isPlaying,
                                isLoading = isLoading,
                                canSkipPrevious = canSkipPrevious,
                                canSkipNext = canSkipNext,
                                currentSongLiked = currentSongLiked,
                                sliderPosition = sliderPosition,
                                position = position,
                                duration = duration,
                                volume = deviceMusicVolumeController.volumeFraction,
                                showVolumeBar = showPlayerVolumeBar,
                                playerConnection = playerConnection,
                                navController = navController,
                                state = state,
                                menuState = menuState,
                                bottomSheetPageState = bottomSheetPageState,
                                currentFormat = currentFormat,
                                canvasSource = artworkCanvas?.source,
                                canvasPrimaryUrl = artworkCanvas?.animated,
                                canvasFallbackUrl = artworkCanvas?.videoUrl,
                                onSliderValueChange = onSliderValueChange,
                                onSliderValueChangeFinished = onSliderValueChangeFinished,
                                onVolumeChange = onPlayerVolumeChange,
                                modifier =
                                    Modifier
                                        .fillMaxSize()
                                        .padding(bottom = queueCollapsedHeight)
                                        .windowInsetsPadding(
                                            WindowInsets.systemBars.only(
                                                WindowInsetsSides.Top + WindowInsetsSides.Horizontal,
                                            ),
                                        ).nestedScroll(state.preUpPostDownNestedScrollConnection),
                            )
                        }
                    }
                } else if (playerDesignStyle == PlayerDesignStyle.V9) {
                    enrichedMetadata?.let { metadata ->
                        V9PlayerContent(
                            mediaMetadata = metadata,
                            playbackState = playbackState,
                            isPlaying = isPlaying,
                            isLoading = isLoading,
                            canSkipPrevious = canSkipPrevious,
                            canSkipNext = canSkipNext,
                            sliderPosition = sliderPosition,
                            position = position,
                            duration = duration,
                            playerConnection = playerConnection,
                            navController = navController,
                            state = state,
                            textBackgroundColor = TextBackgroundColor,
                            textButtonColor = textButtonColor,
                            iconButtonColor = iconButtonColor,
                            canvasSource = artworkCanvas?.source,
                            canvasPrimaryUrl = artworkCanvas?.animated,
                            canvasFallbackUrl = artworkCanvas?.videoUrl,
                            onCollapseClick = { state.collapseSoft() },
                            onQueueClick = openQueue,
                            onLyricsClick = { isLyricsScreenVisible = true },
                            onSliderValueChange = onSliderValueChange,
                            onSliderValueChangeFinished = onSliderValueChangeFinished,
                            gradientColors = gradientColors,
                            modifier =
                                Modifier
                                    .fillMaxSize()
                                    .padding(bottom = queueCollapsedHeight)
                                    .windowInsetsPadding(
                                        WindowInsets.systemBars.only(
                                            WindowInsetsSides.Top + WindowInsetsSides.Horizontal,
                                        ),
                                    ).nestedScroll(state.preUpPostDownNestedScrollConnection),
                        )
                    }
                } else if (playerDesignStyle == PlayerDesignStyle.V10) {
                    enrichedMetadata?.let { metadata ->
                        V10PlayerContent(
                            mediaMetadata = metadata,
                            playbackState = playbackState,
                            isPlaying = isPlaying,
                            isLoading = isLoading,
                            canSkipPrevious = canSkipPrevious,
                            canSkipNext = canSkipNext,
                            sliderPosition = sliderPosition,
                            position = position,
                            duration = duration,
                            playerConnection = playerConnection,
                            navController = navController,
                            state = state,
                            textBackgroundColor = dynamicV10AccentColor,
                            textButtonColor = dynamicV10FieldColor,
                            iconButtonColor = iconButtonColor,
                            onCollapseClick = { state.collapseSoft() },
                            onQueueClick = openQueue,
                            onLyricsClick = { isLyricsScreenVisible = true },
                            onSliderValueChange = onSliderValueChange,
                            onSliderValueChangeFinished = onSliderValueChangeFinished,
                            onSleepTimerClick = {
                                if (sleepTimerEnabled) {
                                    playerConnection.service.sleepTimer.clear()
                                } else {
                                    showSleepTimerSheet = true
                                }
                            },
                            sleepTimerEnabled = sleepTimerEnabled,
                            sleepTimerTimeLeft = sleepTimerTimeLeft,
                            onMenuClick = {
                                menuState.show {
                                    PlayerMenu(
                                        mediaMetadata = metadata,
                                        navController = navController,
                                        playerBottomSheetState = state,
                                        sleepTimerEnabled = sleepTimerEnabled,
                                        onSleepTimerClick = {
                                            if (sleepTimerEnabled) {
                                                playerConnection.service.sleepTimer.clear()
                                            } else {
                                                showSleepTimerSheet = true
                                            }
                                        },
                                        onShowDetailsDialog = {
                                            bottomSheetPageState.show {
                                                ShowMediaInfo(metadata.id)
                                            }
                                        },
                                        onDismiss = menuState::dismiss,
                                    )
                                }
                            },
                            onAddToPlaylistClick = {
                                showChoosePlaylistDialog = true
                            },
                            landscape = false,
                            modifier =
                                Modifier
                                    .fillMaxSize()
                                    .padding(bottom = queueCollapsedHeight)
                                    .windowInsetsPadding(
                                        WindowInsets.systemBars.only(
                                            WindowInsetsSides.Top + WindowInsetsSides.Horizontal,
                                        ),
                                    )
                                    .nestedScroll(state.preUpPostDownNestedScrollConnection),
                        )
                    }
                } else if (playerDesignStyle == PlayerDesignStyle.V11) {
                    v11Content(false)
                } else {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier =
                            Modifier
                                .windowInsetsPadding(
                                    WindowInsets.systemBars.only(
                                        WindowInsetsSides.Horizontal,
                                    ),
                                ).padding(bottom = queueCollapsedHeight),
                    ) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier.weight(1f),
                        ) {
                            Thumbnail(
                                canvas = artworkCanvas,
                                sliderPositionProvider = { sliderPosition },
                                modifier = Modifier.nestedScroll(state.preUpPostDownNestedScrollConnection),
                                isPlayerExpanded = state.isExpanded,
                            )
                        }

                        enrichedMetadata?.let {
                            controlsContent(it, false)
                        }

                        Spacer(Modifier.height(30.dp))
                    }
                }
            }
            QueueFooter(
                playerBottomSheetState = state,
                navController = navController,
                viewModel = queueViewModel,
                peekHeight = dynamicQueuePeekHeight,
                onExpandQueue = openQueue,
                onShowLyrics = { isLyricsScreenVisible = true },
                TextBackgroundColor = TextBackgroundColor,
                textButtonColor = textButtonColor,
                iconButtonColor = iconButtonColor,
                onAddToPlaylistClick = { showChoosePlaylistDialog = true },
                modifier = Modifier.align(Alignment.BottomCenter),
            )
        }

        mediaMetadata?.let { metadata ->
            MikoLyricsTransition(
                visible = isLyricsScreenVisible,
                backHandlerEnabled = isLyricsScreenVisible && state.isExpandedOrExpanding,
                mediaMetadata = metadata,
                navController = navController,
                lyricsSyncOffset = lyricsSyncOffset,
                onLyricsSyncOffsetChange = { lyricsSyncOffsetViewModel.setOffset(metadata.id, it) },
                onDismiss = { isLyricsScreenVisible = false },
                onQueueClick = openQueue,
            )
        }

        AnimatedVisibility(
            visible = aodModeEnabled,
            enter = fadeIn(tween(300)),
            exit = fadeOut(tween(300)),
            modifier =
                Modifier
                    .fillMaxSize()
                    .background(Color.Black),
        ) {
            val metadata = mediaMetadata ?: MediaMetadata(
                id = "",
                title = stringResource(R.string.app_name),
                artists = emptyList(),
                duration = 0,
            )
            AodPlayerScreen(
                mediaMetadata = metadata,
                isPlaying = isPlaying,
                position = position,
                duration = duration,
                sliderPosition = sliderPosition,
                canSkipPrevious = canSkipPrevious,
                canSkipNext = canSkipNext,
                thumbnailCornerRadius = thumbnailCornerRadius,
                onPlayPause = { playerConnection.player.togglePlayPause() },
                onSkipPrevious = playerConnection::seekToPrevious,
                onSkipNext = playerConnection::seekToNext,
                onSeek = { sliderPosition = it },
                onSeekFinished = onSliderValueChangeFinished,
                onExit = { playerConnection.aodModeEnabled.value = false },
                lyricsText = currentLyricsEntity?.lyrics,
            )
        }
    }

    Queue(
        playerBottomSheetState = state,
        navController = navController,
        viewModel = queueViewModel,
        pureBlack = useBlackBackground,
    )

    val activePlaybackError = playbackError
    val isRecoveryDestination =
        currentRoute?.startsWith(LOGIN_ROUTE) == true || currentRoute == "settings/account"
    if (activePlaybackError != null && !isRecoveryDestination) {
        val errorInfo = remember(activePlaybackError) { activePlaybackError.toPlaybackErrorInfo() }
        val loginClick =
            remember(errorInfo.loginRecoveryUrl, navigateToLogin) {
                { navigateToLogin(errorInfo.loginRecoveryUrl) }
            }

        PlaybackErrorDialog(
            error = activePlaybackError,
            showLoginAction = errorInfo.loginRecoveryUrl != null,
            onRetry = retryPlayback,
            onClose = dismissPlaybackError,
            onLogin = loginClick,
        )
    }
}

@Composable
private fun MikoLyricsTransition(
    visible: Boolean,
    backHandlerEnabled: Boolean,
    mediaMetadata: MediaMetadata,
    navController: NavController,
    lyricsSyncOffset: Int,
    onLyricsSyncOffsetChange: (Int) -> Unit,
    onDismiss: () -> Unit,
    onQueueClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val progress by animateFloatAsState(
        targetValue = if (visible) 1f else 0f,
        animationSpec =
            spring(
                dampingRatio = 0.82f,
                stiffness = Spring.StiffnessMediumLow,
            ),
        label = "mikoLyricsTransition",
    )

    val boundedProgress = progress.coerceIn(0f, 1f)

    if (visible || boundedProgress > 0.001f) {
        val scaleX = 0.92f + (0.08f * boundedProgress)
        val scaleY = 0.78f + (0.22f * boundedProgress)
        val alpha = (0.2f + (0.8f * boundedProgress)).coerceIn(0f, 1f)
        val cornerRadius = 32.dp * (1f - boundedProgress)

        Box(
            modifier =
                modifier
                    .fillMaxSize()
                    .graphicsLayer { this.alpha = boundedProgress }
                    .background(Color.Black.copy(alpha = 0.24f * boundedProgress)),
        ) {
            Box(
                modifier =
                    Modifier
                        .fillMaxSize()
                        .graphicsLayer {
                            transformOrigin = TransformOrigin(0.5f, 1f)
                            this.scaleX = scaleX
                            this.scaleY = scaleY
                            this.alpha = alpha
                            translationY = size.height * 0.16f * (1f - boundedProgress)
                        }.clip(RoundedCornerShape(cornerRadius))
                        .background(MaterialTheme.colorScheme.surface),
            ) {
                LyricsScreen(
                    mediaMetadata = mediaMetadata,
                    onBackClick = onDismiss,
                    navController = navController,
                    lyricsSyncOffset = lyricsSyncOffset,
                    onLyricsSyncOffsetChange = onLyricsSyncOffsetChange,
                    onQueueClick = onQueueClick,
                    backHandlerEnabled = backHandlerEnabled,
                )
            }
        }
    }
}

@Composable
private fun V8PlayerBackdrop(
    thumbnailUrl: String?,
    backdropBlurAmount: Int,
    modifier: Modifier = Modifier,
) {
    var currentUrl by remember(thumbnailUrl) {
        mutableStateOf(
            thumbnailUrl?.resize(
                width = V8BackdropArtworkSizePx,
                height = V8BackdropArtworkSizePx,
                maxresAllowed = true,
                ytimgResizePolicy = YtimgResizePolicy.AllowAnyAspect,
            ),
        )
    }
    val backdropRequest = rememberOfflineArtworkImageRequest(currentUrl)
    val blurRadiusDp = 44.dp * (backdropBlurAmount.toFloat() / 100f)

    Box(
        modifier =
            modifier
                .fillMaxSize()
                .background(Color.Black),
    ) {
        if (currentUrl != null) {
            val backdropHasBlur = backdropBlurAmount > 0
            if (backdropHasBlur && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                AsyncImage(
                    model = backdropRequest,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier =
                        Modifier
                            .fillMaxSize()
                            .then(if (blurRadiusDp > 0.dp) Modifier.blur(blurRadiusDp) else Modifier)
                            .graphicsLayer {
                                scaleX = 1.16f
                                scaleY = 1.16f
                                alpha = 0.66f
                            },
                    onState = { state ->
                        if (state is coil3.compose.AsyncImagePainter.State.Error) {
                            getNextFallbackUrl(currentUrl)?.let { currentUrl = it }
                        }
                    },
                )
            } else if (backdropHasBlur) {
                BackdropBlurApi30(
                    model = currentUrl,
                    blurAmount = backdropBlurAmount,
                    modifier =
                        Modifier
                            .fillMaxSize()
                            .graphicsLayer {
                                scaleX = 1.16f
                                scaleY = 1.16f
                                alpha = 0.66f
                            },
                    onError = { failedUrl ->
                        getNextFallbackUrl(failedUrl)?.let { currentUrl = it }
                    },
                )
            } else {
                AsyncImage(
                    model = backdropRequest,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier =
                        Modifier
                            .fillMaxSize()
                            .graphicsLayer {
                                scaleX = 1.16f
                                scaleY = 1.16f
                                alpha = 0.66f
                            },
                    onState = { state ->
                        if (state is coil3.compose.AsyncImagePainter.State.Error) {
                            getNextFallbackUrl(currentUrl)?.let { currentUrl = it }
                        }
                    },
                )
            }
        }

        Box(
            modifier =
                Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.52f)),
        )
    }
}

@Composable
private fun BackdropBlurApi30(
    model: String?,
    blurAmount: Int,
    modifier: Modifier = Modifier,
    onError: ((String) -> Unit)? = null,
) {
    val context = LocalContext.current
    val imageLoader = context.imageLoader

    val blurredBitmap by produceState<Bitmap?>(null, model, blurAmount) {
        if (model == null) return@produceState
        value =
            withContext(Dispatchers.IO) {
                try {
                    val request =
                        ImageRequest
                            .Builder(context)
                            .data(model)
                            .memoryCacheKey(model)
                            .diskCacheKey(model)
                            .diskCachePolicy(CachePolicy.ENABLED)
                            .networkCachePolicy(CachePolicy.ENABLED)
                            .allowHardware(false)
                            .size(500)
                            .build()
                    val result = imageLoader.execute(request)
                    when (result) {
                        is SuccessResult -> {
                            val bitmap = result.image.toBitmap().copy(Bitmap.Config.ARGB_8888, true)
                            val radius = (blurAmount * 25 / 100f).coerceIn(1f, 25f)
                            ImageBlurUtils.blur(bitmap, radius)
                        }

                        else -> {
                            if (onError != null) {
                                withContext(Dispatchers.Main) {
                                    onError(model)
                                }
                            }
                            null
                        }
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (_: Exception) {
                    if (onError != null) {
                        withContext(Dispatchers.Main) {
                            onError(model)
                        }
                    }
                    null
                }
            }
    }

    val loadedBitmap = blurredBitmap
    if (loadedBitmap != null) {
        Image(
            painter = BitmapPainter(loadedBitmap.asImageBitmap()),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = modifier,
        )
    } else {
        AsyncImage(
            model = rememberOfflineArtworkImageRequest(model),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = modifier,
            onState = { state ->
                if (state is coil3.compose.AsyncImagePainter.State.Error && model != null) {
                    onError?.invoke(model)
                }
            },
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LittlePlayerContent(
    mediaMetadata: MediaMetadata,
    sliderPosition: Long?,
    positionMs: Long,
    durationMs: Long,
    textColor: Color,
    liked: Boolean,
    onCollapse: () -> Unit,
    onToggleLike: () -> Unit,
    onExpandQueue: () -> Unit,
    onMenuClick: () -> Unit,
) {
    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val titleColor = textColor.copy(alpha = 0.95f)
        val secondaryColor = textColor.copy(alpha = 0.6f)
        val timeColor = textColor.copy(alpha = 0.85f)

        val scale =
            minOf(maxWidth / 420.dp, maxHeight / 260.dp)
                .coerceIn(0.78f, 1.15f)

        val titleSize = (56f * scale).sp
        val timeSize = (44f * scale).sp
        val iconSize = (26f * scale).dp
        val collapseIconSize = (28f * scale).dp
        val horizontalPadding = (18f * scale).dp
        val verticalPadding = (10f * scale).dp

        val displayPositionMs = sliderPosition ?: positionMs

        val timeText =
            remember(displayPositionMs, durationMs) {
                val positionText = makeTimeString(displayPositionMs)
                val durationText = if (durationMs != C.TIME_UNSET) makeTimeString(durationMs) else ""
                if (durationText.isBlank()) positionText else "$positionText/$durationText"
            }

        val artistsText =
            remember(mediaMetadata.artists) {
                mediaMetadata.artists.joinToString(separator = ", ") { artist -> artist.name }
            }

        Column(
            modifier =
                Modifier
                    .fillMaxSize()
                    .padding(horizontal = horizontalPadding, vertical = verticalPadding),
        ) {
            Spacer(Modifier.weight(1f))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    AnimatedContent(
                        targetState = mediaMetadata.title,
                        transitionSpec = { fadeIn() togetherWith fadeOut() },
                        label = "little_title",
                    ) { title ->
                        PlayerTitleText(
                            title = title,
                            explicit = mediaMetadata.explicit,
                            color = titleColor,
                            style = LocalTextStyle.current,
                            fontSize = titleSize,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.basicMarquee(),
                        )
                    }

                    Spacer(Modifier.height((10f * scale).dp))

                    mediaMetadata.album?.title?.takeIf { it.isNotBlank() }?.let { albumTitle ->
                        AnimatedContent(
                            targetState = albumTitle,
                            transitionSpec = { fadeIn() togetherWith fadeOut() },
                            label = "little_album",
                        ) { album ->
                            Text(
                                text = album,
                                color = secondaryColor,
                                style = MaterialTheme.typography.bodyMedium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.basicMarquee(),
                            )
                        }
                    }

                    artistsText.takeIf { it.isNotBlank() }?.let { artists ->
                        AnimatedContent(
                            targetState = artists,
                            transitionSpec = { fadeIn() togetherWith fadeOut() },
                            label = "little_artists",
                        ) { artistLine ->
                            Text(
                                text = "by - $artistLine",
                                color = secondaryColor,
                                style = MaterialTheme.typography.bodyMedium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.basicMarquee(),
                            )
                        }
                    }
                }

                Spacer(Modifier.width((16f * scale).dp))

                Text(
                    text = timeText,
                    color = timeColor,
                    fontSize = timeSize,
                    fontWeight = FontWeight.Medium,
                    textAlign = TextAlign.End,
                    maxLines = 1,
                    modifier = Modifier.widthIn(min = (140f * scale).dp),
                )
            }

            Spacer(Modifier.height((14f * scale).dp))

            Spacer(Modifier.height((6f * scale).dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(
                    painter = painterResource(R.drawable.expand_more),
                    contentDescription = null,
                    tint = textColor.copy(alpha = 0.8f),
                    modifier =
                        Modifier
                            .size(collapseIconSize)
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = tvFocusIndicationOrNull(),
                                onClick = onCollapse,
                            ),
                )

                Spacer(Modifier.weight(1f))

                Icon(
                    painter = painterResource(if (liked) R.drawable.favorite else R.drawable.favorite_border),
                    contentDescription = null,
                    tint =
                        if (liked) {
                            MaterialTheme.colorScheme.error.copy(alpha = 0.9f)
                        } else {
                            textColor.copy(alpha = 0.78f)
                        },
                    modifier =
                        Modifier
                            .size(iconSize)
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = tvFocusIndicationOrNull(),
                                onClick = onToggleLike,
                            ),
                )

                Spacer(Modifier.width((18f * scale).dp))

                Icon(
                    painter = painterResource(R.drawable.queue_music),
                    contentDescription = null,
                    tint = textColor.copy(alpha = 0.78f),
                    modifier =
                        Modifier
                            .size(iconSize)
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = tvFocusIndicationOrNull(),
                                onClick = onExpandQueue,
                            ),
                )

                Spacer(Modifier.width((18f * scale).dp))

                Icon(
                    painter = painterResource(R.drawable.more_vert),
                    contentDescription = null,
                    tint = textColor.copy(alpha = 0.78f),
                    modifier =
                        Modifier
                            .size(iconSize)
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = tvFocusIndicationOrNull(),
                                onClick = onMenuClick,
                            ),
                )
            }
        }
    }
}

@Composable
private fun LandscapeLikeBox(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit,
) {
    Layout(
        content = content,
        modifier = modifier.graphicsLayer { clip = true },
    ) { measurables, constraints ->
        val measurable = measurables.firstOrNull()
        if (measurable == null) {
            layout(constraints.minWidth, constraints.minHeight) {}
        } else {
            val swappedConstraints =
                Constraints(
                    minWidth = constraints.minHeight,
                    maxWidth = constraints.maxHeight,
                    minHeight = constraints.minWidth,
                    maxHeight = constraints.maxWidth,
                )

            val placeable = measurable.measure(swappedConstraints)
            val width = constraints.maxWidth
            val height = constraints.maxHeight
            val rotatedWidth = placeable.height
            val rotatedHeight = placeable.width

            val x = ((width - rotatedWidth) / 2).coerceAtLeast(0)
            val y = ((height - rotatedHeight) / 2).coerceAtLeast(0)

            layout(width, height) {
                placeable.placeWithLayer(x, y) {
                    transformOrigin = TransformOrigin(0f, 0f)
                    rotationZ = 90f
                    translationX = placeable.height.toFloat()
                }
            }
        }
    }
}

private fun Modifier.littlePlayerOverlayGestures(
    seekEnabled: Boolean,
    durationMs: Long,
    progressFraction: Float,
    canSkipPrevious: Boolean,
    canSkipNext: Boolean,
    onSeekToPositionMs: (Long) -> Unit,
    onSeekFinished: () -> Unit,
    onSkipPrevious: () -> Unit,
    onSkipNext: () -> Unit,
): Modifier =
    composed {
        val view = LocalView.current
        val (enableHapticFeedback) = rememberPreference(EnableHapticFeedbackKey, true)

        pointerInput(seekEnabled, durationMs, canSkipPrevious, canSkipNext) {
            var lastTapUptimeMs = 0L
            var lastTapPosition: Offset? = null
            val doubleTapTimeoutMs = viewConfiguration.doubleTapTimeoutMillis.toLong()
            val touchSlop = viewConfiguration.touchSlop

            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = true)
                val pointerId = down.id

                var upPosition = down.position
                val minOverlayHeightPx = 24.dp.toPx()
                val overlayHeightPx =
                    (progressFraction * size.height).coerceAtLeast(minOverlayHeightPx)
                val seekAllowedFromDown =
                    seekEnabled &&
                        durationMs > 0L &&
                        durationMs != C.TIME_UNSET &&
                        down.position.y <= overlayHeightPx

                var isSeeking = false

                while (true) {
                    val event = awaitPointerEvent(PointerEventPass.Main)
                    val change = event.changes.firstOrNull { it.id == pointerId } ?: continue
                    upPosition = change.position

                    if (!change.pressed) break

                    if (!isSeeking && seekAllowedFromDown) {
                        val distanceFromDown = (change.position - down.position).getDistance()
                        if (distanceFromDown > touchSlop) isSeeking = true
                    }

                    if (isSeeking) {
                        val fraction =
                            if (size.height > 0) (change.position.y / size.height.toFloat()) else 0f
                        val clampedFraction = fraction.coerceIn(0f, 1f)

                        val targetMs =
                            (durationMs.toDouble() * clampedFraction.toDouble()).roundToLong().coerceIn(0L, durationMs)
                        onSeekToPositionMs(targetMs)
                        change.consume()
                    }
                }

                if (isSeeking) {
                    onSeekFinished()
                    lastTapUptimeMs = 0L
                    lastTapPosition = null
                } else {
                    val now = SystemClock.uptimeMillis()
                    val previousTapPosition = lastTapPosition
                    val isDoubleTap =
                        previousTapPosition != null &&
                            (now - lastTapUptimeMs) <= doubleTapTimeoutMs &&
                            (upPosition - previousTapPosition).getDistance() <= (touchSlop * 2f)

                    if (isDoubleTap) {
                        val isTopSide = upPosition.y < size.height / 2f
                        if (isTopSide) {
                            if (canSkipPrevious) {
                                if (enableHapticFeedback) {
                                    view.performHapticFeedback(
                                        android.view.HapticFeedbackConstants.CONTEXT_CLICK,
                                        android.view.HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING,
                                    )
                                }
                                onSkipPrevious()
                            }
                        } else {
                            if (canSkipNext) {
                                if (enableHapticFeedback) {
                                    view.performHapticFeedback(
                                        android.view.HapticFeedbackConstants.CONTEXT_CLICK,
                                        android.view.HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING,
                                    )
                                }
                                onSkipNext()
                            }
                        }
                        lastTapUptimeMs = 0L
                        lastTapPosition = null
                    } else {
                        lastTapUptimeMs = now
                        lastTapPosition = upPosition
                    }
                }
            }
        }
    }
