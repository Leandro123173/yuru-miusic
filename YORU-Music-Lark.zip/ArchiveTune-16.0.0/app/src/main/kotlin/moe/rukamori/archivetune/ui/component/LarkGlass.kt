/*
 * ArchiveTune (2026)
 * © Rukamori — github.com/rukamori
 * GPL-3.0 License | Contributors: see git history
 * Do not remove or alter this notice. - Per GPL-3.0 Section 4 & Section 5
 */

package moe.rukamori.archivetune.ui.component

import androidx.annotation.OptIn
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.keyframes
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import coil3.compose.AsyncImage
import moe.rukamori.archivetune.LocalAnimationsDisabled
import moe.rukamori.archivetune.constants.AppWallpaperDimKey
import moe.rukamori.archivetune.constants.AppWallpaperTypeKey
import moe.rukamori.archivetune.constants.AppWallpaperUriKey
import moe.rukamori.archivetune.constants.GlassSweepEnabledKey
import moe.rukamori.archivetune.utils.rememberPreference

object AppWallpaperType {
    const val NONE = "NONE"
    const val IMAGE = "IMAGE"
    const val VIDEO = "VIDEO"
}

/**
 * Línea de luz diagonal que cruza el cristal de izquierda a derecha y descansa unos segundos.
 * Debe aplicarse sobre un contenedor que ya esté recortado con la forma (clip) para que el brillo
 * no se salga de las esquinas redondeadas.
 */
fun Modifier.glassSweep(
    periodMillis: Int = 5200,
    intensity: Float = 0.20f,
): Modifier =
    composed {
        val (enabled) = rememberPreference(GlassSweepEnabledKey, true)
        if (!enabled || LocalAnimationsDisabled.current) return@composed this

        val transition = rememberInfiniteTransition(label = "glassSweep")
        val progress =
            transition.animateFloat(
                initialValue = 0f,
                targetValue = 1f,
                animationSpec =
                    infiniteRepeatable(
                        animation =
                            keyframes {
                                durationMillis = periodMillis
                                0f at 0 using LinearEasing
                                1f at (periodMillis * 0.42f).toInt() using LinearEasing
                            },
                        repeatMode = RepeatMode.Restart,
                    ),
                label = "glassSweepProgress",
            )

        drawWithContent {
            drawContent()
            val p = progress.value
            if (p <= 0f || p >= 1f) return@drawWithContent
            val band = size.height * 1.6f + size.width * 0.18f
            val x = -band + (size.width + 2f * band) * p
            drawRect(
                brush =
                    Brush.linearGradient(
                        colors =
                            listOf(
                                Color.Transparent,
                                Color.White.copy(alpha = intensity * 0.35f),
                                Color.White.copy(alpha = intensity),
                                Color.White.copy(alpha = intensity * 0.35f),
                                Color.Transparent,
                            ),
                        start = Offset(x, 0f),
                        end = Offset(x + band, size.height * 0.9f),
                    ),
            )
        }
    }

/**
 * Fondo de la app: imagen o vídeo (de la galería) con una capa oscura para que el texto se lea.
 * Si no hay fondo elegido, no dibuja nada (la pantalla usa su propio color/degradado).
 */
@OptIn(UnstableApi::class)
@Composable
fun LarkWallpaperBackground(modifier: Modifier = Modifier) {
    val (type) = rememberPreference(AppWallpaperTypeKey, AppWallpaperType.NONE)
    val (uri) = rememberPreference(AppWallpaperUriKey, "")
    val (dim) = rememberPreference(AppWallpaperDimKey, 0.55f)
    if (type == AppWallpaperType.NONE || uri.isBlank()) return

    Box(modifier = modifier) {
        when (type) {
            AppWallpaperType.IMAGE ->
                AsyncImage(
                    model = uri,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                )

            AppWallpaperType.VIDEO -> WallpaperVideo(uri = uri, modifier = Modifier.fillMaxSize())
        }
        Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = dim.coerceIn(0f, 0.9f))))
    }
}

@OptIn(UnstableApi::class)
@Composable
private fun WallpaperVideo(
    uri: String,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val exoPlayer =
        remember(uri) {
            ExoPlayer.Builder(context).build().apply {
                volume = 0f
                repeatMode = Player.REPEAT_MODE_ALL
                setMediaItem(MediaItem.fromUri(uri))
                prepare()
                playWhenReady = true
            }
        }

    DisposableEffect(lifecycleOwner, exoPlayer) {
        val observer =
            LifecycleEventObserver { _, event ->
                when (event) {
                    Lifecycle.Event.ON_START -> exoPlayer.play()
                    Lifecycle.Event.ON_STOP -> exoPlayer.pause()
                    else -> Unit
                }
            }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            exoPlayer.release()
        }
    }

    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            PlayerView(ctx).apply {
                useController = false
                resizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                player = exoPlayer
            }
        },
        update = { view -> view.player = exoPlayer },
    )
}
