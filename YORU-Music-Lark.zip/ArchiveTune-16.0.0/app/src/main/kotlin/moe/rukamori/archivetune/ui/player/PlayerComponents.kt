/*
 * ArchiveTune (2026)
 * © Rukamori — github.com/rukamori
 * GPL-3.0 License | Contributors: see git history
 * Do not remove or alter this notice. - Per GPL-3.0 Section 4 & Section 5
 */

@file:OptIn(ExperimentalMaterial3ExpressiveApi::class)

package moe.rukamori.archivetune.ui.player

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.InlineTextContent
import androidx.compose.foundation.text.appendInlineContent
import androidx.compose.material3.CircularWavyProgressIndicator
import androidx.compose.material3.LinearWavyProgressIndicator
import androidx.compose.material3.LoadingIndicator
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalDensity

import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MotionScheme
import androidx.compose.material3.ripple
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.animateColorAsState
import androidx.compose.material3.LocalContentColor
import androidx.compose.runtime.CompositionLocalProvider
import moe.rukamori.archivetune.ui.component.LocalMenuState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.graphics.shapes.Morph
import androidx.graphics.shapes.RoundedPolygon
import androidx.graphics.shapes.toPath
import androidx.compose.ui.graphics.asComposePath
import androidx.compose.ui.graphics.Matrix
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.animation.core.Animatable
import androidx.compose.material3.MaterialShapes
import kotlin.math.abs
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.Placeholder
import androidx.compose.ui.text.PlaceholderVerticalAlign
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.common.Player.STATE_ENDED
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.navigation.NavController
import coil3.compose.AsyncImage
import moe.rukamori.archivetune.canvas.CanvasSource
import moe.rukamori.archivetune.R
import moe.rukamori.archivetune.constants.EnableHapticFeedbackKey
import moe.rukamori.archivetune.constants.PlayerBackgroundStyle
import moe.rukamori.archivetune.constants.PlayerDesignStyle
import moe.rukamori.archivetune.constants.PlayerHorizontalPadding
import moe.rukamori.archivetune.constants.SliderStyle
import moe.rukamori.archivetune.db.entities.FormatEntity
import moe.rukamori.archivetune.db.entities.codecLabel
import moe.rukamori.archivetune.extensions.togglePlayPause
import moe.rukamori.archivetune.extensions.toggleRepeatMode
import moe.rukamori.archivetune.models.MediaMetadata
import moe.rukamori.archivetune.playback.PlayerConnection
import moe.rukamori.archivetune.ui.component.BottomSheetPageState
import moe.rukamori.archivetune.ui.component.BottomSheetState
import moe.rukamori.archivetune.ui.component.MenuState
import moe.rukamori.archivetune.ui.component.PlayerSliderTrack
import moe.rukamori.archivetune.ui.component.rememberControlledSliderState
import moe.rukamori.archivetune.ui.component.ResizableIconButton
import moe.rukamori.archivetune.ui.menu.PlayerMenu
import moe.rukamori.archivetune.ui.theme.PlayerBackgroundColorUtils
import moe.rukamori.archivetune.ui.theme.PlayerSliderColors
import moe.rukamori.archivetune.ui.utils.ShowMediaInfo
import moe.rukamori.archivetune.ui.utils.highRes
import moe.rukamori.archivetune.ui.utils.tvFocusIndicationOrNull
import moe.rukamori.archivetune.utils.makeTimeString
import moe.rukamori.archivetune.utils.rememberLowDataModeActive
import moe.rukamori.archivetune.utils.rememberPreference

private const val PlayerBackgroundMaxBlurRadius = 64f
private const val ExplicitBadgeInlineId = "explicitBadge"

@Composable
internal fun PlayerTitleText(
    title: String,
    explicit: Boolean,
    color: Color,
    style: TextStyle,
    fontWeight: FontWeight,
    modifier: Modifier = Modifier,
    fontSize: TextUnit = TextUnit.Unspecified,
    textAlign: TextAlign? = null,
) {
    val annotatedTitle =
        remember(title, explicit) {
            buildAnnotatedString {
                append(title)
                if (explicit) {
                    append(" ")
                    appendInlineContent(ExplicitBadgeInlineId, "\uFFFC")
                }
            }
        }
    val badgePainter = painterResource(R.drawable.explicit)
    val inlineContent =
        remember(badgePainter, color, explicit) {
            if (explicit) {
                mapOf(
                    ExplicitBadgeInlineId to
                        InlineTextContent(
                            placeholder =
                                Placeholder(
                                    width = 0.82.em,
                                    height = 0.82.em,
                                    placeholderVerticalAlign = PlaceholderVerticalAlign.TextCenter,
                                ),
                        ) {
                            Icon(
                                painter = badgePainter,
                                contentDescription = null,
                                tint = color,
                                modifier = Modifier.fillMaxSize(),
                            )
                        },
                )
            } else {
                emptyMap()
            }
        }

    Text(
        text = annotatedTitle,
        inlineContent = inlineContent,
        color = color,
        style = style,
        fontSize = fontSize,
        fontWeight = fontWeight,
        textAlign = textAlign,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        modifier = modifier,
    )
}

@Composable
fun PlayerTitleSection(
    mediaMetadata: MediaMetadata,
    textBackgroundColor: Color,
    navController: NavController,
    state: BottomSheetState,
) {
    // Tap/long-press behavior is centralized; this style keeps its own visual rendering.
    val actions =
        rememberPlayerTitleActions(
            mediaMetadata = mediaMetadata,
            navController = navController,
            state = state,
        )
    AnimatedContent(
        targetState = mediaMetadata.title,
        transitionSpec = { fadeIn() togetherWith fadeOut() },
        label = "",
    ) { title ->
        PlayerTitleText(
            title = title,
            explicit = mediaMetadata.explicit,
            color = textBackgroundColor,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            modifier =
                Modifier
                    .basicMarquee()
                    .combinedClickable(
                        enabled = true,
                        indication = tvFocusIndicationOrNull(),
                        interactionSource = remember { MutableInteractionSource() },
                        onClick = actions.onTitleClick,
                        onLongClick = actions.onCopyTitle,
                    ),
        )
    }

    Spacer(Modifier.height(6.dp))

    ClickableArtists(
        artists = mediaMetadata.artists,
        onArtistClick = actions.onArtistClick,
        style = MaterialTheme.typography.titleMedium.copy(color = textBackgroundColor, fontSize = 16.sp),
        onLongClick = actions.onCopyArtists,
        modifier =
            Modifier
                .fillMaxWidth()
                .basicMarquee()
                .padding(end = 12.dp),
    )
}

@Composable
fun PlayerTopActions(
    mediaMetadata: MediaMetadata,
    playerDesignStyle: PlayerDesignStyle,
    textButtonColor: Color,
    iconButtonColor: Color,
    textBackgroundColor: Color,
    playerConnection: PlayerConnection,
    navController: NavController,
    menuState: MenuState,
    state: BottomSheetState,
    bottomSheetPageState: BottomSheetPageState,
    context: Context,
    currentSongLiked: Boolean,
) {
    val haptic = LocalHapticFeedback.current
    val shuffleModeEnabled by playerConnection.shuffleModeEnabled.collectAsState()

    when (playerDesignStyle) {
        PlayerDesignStyle.V2 -> {
            val shareShape =
                RoundedCornerShape(
                    topStart = 50.dp,
                    bottomStart = 50.dp,
                    topEnd = 10.dp,
                    bottomEnd = 10.dp,
                )

            val favShape =
                RoundedCornerShape(
                    topStart = 10.dp,
                    bottomStart = 10.dp,
                    topEnd = 50.dp,
                    bottomEnd = 50.dp,
                )

            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    modifier =
                        Modifier
                            .size(42.dp)
                            .clip(shareShape)
                            .background(textButtonColor)
                            .clickable {
                                val intent =
                                    Intent().apply {
                                        action = Intent.ACTION_SEND
                                        type = "text/plain"
                                        putExtra(
                                            Intent.EXTRA_TEXT,
                                            "https://music.youtube.com/watch?v=${mediaMetadata.id}",
                                        )
                                    }
                                context.startActivity(Intent.createChooser(intent, null))
                            },
                ) {
                    Image(
                        painter = painterResource(R.drawable.share),
                        contentDescription = null,
                        colorFilter = ColorFilter.tint(iconButtonColor),
                        modifier =
                            Modifier
                                .align(Alignment.Center)
                                .size(24.dp),
                    )
                }

                Box(
                    modifier =
                        Modifier
                            .size(42.dp)
                            .clip(favShape)
                            .background(textButtonColor)
                            .clickable {
                                playerConnection.toggleLike()
                            },
                ) {
                    Image(
                        painter =
                            painterResource(
                                if (currentSongLiked) {
                                    R.drawable.favorite
                                } else {
                                    R.drawable.favorite_border
                                },
                            ),
                        contentDescription = null,
                        colorFilter = ColorFilter.tint(iconButtonColor),
                        modifier =
                            Modifier
                                .align(Alignment.Center)
                                .size(24.dp),
                    )
                }
            }
        }

        PlayerDesignStyle.V3, PlayerDesignStyle.V5 -> {
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    modifier =
                        Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .clickable {
                                val intent =
                                    Intent().apply {
                                        action = Intent.ACTION_SEND
                                        type = "text/plain"
                                        putExtra(
                                            Intent.EXTRA_TEXT,
                                            "https://music.youtube.com/watch?v=${mediaMetadata.id}",
                                        )
                                    }
                                context.startActivity(Intent.createChooser(intent, null))
                            },
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        painter = painterResource(R.drawable.share),
                        contentDescription = null,
                        tint = textBackgroundColor.copy(alpha = 0.7f),
                        modifier = Modifier.size(20.dp),
                    )
                }
                Box(
                    modifier =
                        Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { playerConnection.toggleLike() },
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        painter =
                            painterResource(
                                if (currentSongLiked) {
                                    R.drawable.favorite
                                } else {
                                    R.drawable.favorite_border
                                },
                            ),
                        contentDescription = null,
                        tint =
                            if (currentSongLiked) {
                                MaterialTheme.colorScheme.error.copy(alpha = 0.9f)
                            } else {
                                textBackgroundColor.copy(alpha = 0.7f)
                            },
                        modifier = Modifier.size(20.dp),
                    )
                }
            }
        }

        PlayerDesignStyle.V4 -> {
            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Surface(
                    onClick = {
                        val intent =
                            Intent().apply {
                                action = Intent.ACTION_SEND
                                type = "text/plain"
                                putExtra(
                                    Intent.EXTRA_TEXT,
                                    "https://music.youtube.com/watch?v=${mediaMetadata.id}",
                                )
                            }
                        context.startActivity(Intent.createChooser(intent, null))
                    },
                    shape = RoundedCornerShape(14.dp),
                    color = textBackgroundColor.copy(alpha = 0.12f),
                    modifier =
                        Modifier
                            .height(44.dp)
                            .width(44.dp),
                ) {
                    Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                        Icon(
                            painter = painterResource(R.drawable.share),
                            contentDescription = null,
                            tint = textBackgroundColor,
                            modifier = Modifier.size(22.dp),
                        )
                    }
                }

                Surface(
                    onClick = { playerConnection.toggleLike() },
                    shape = RoundedCornerShape(14.dp),
                    color =
                        if (currentSongLiked) {
                            MaterialTheme.colorScheme.error.copy(alpha = 0.25f)
                        } else {
                            textBackgroundColor.copy(alpha = 0.12f)
                        },
                    modifier =
                        Modifier
                            .height(44.dp)
                            .width(44.dp),
                ) {
                    Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                        Icon(
                            painter =
                                painterResource(
                                    if (currentSongLiked) {
                                        R.drawable.favorite
                                    } else {
                                        R.drawable.favorite_border
                                    },
                                ),
                            contentDescription = null,
                            tint =
                                if (currentSongLiked) {
                                    MaterialTheme.colorScheme.error
                                } else {
                                    textBackgroundColor
                                },
                            modifier = Modifier.size(22.dp),
                        )
                    }
                }

                // More menu button - cinematic glass card
                Surface(
                    onClick = {
                        menuState.show {
                            PlayerMenu(
                                mediaMetadata = mediaMetadata,
                                navController = navController,
                                playerBottomSheetState = state,
                                onShowDetailsDialog = {
                                    mediaMetadata.id.let {
                                        bottomSheetPageState.show {
                                            ShowMediaInfo(it)
                                        }
                                    }
                                },
                                onDismiss = menuState::dismiss,
                            )
                        }
                    },
                    shape = RoundedCornerShape(14.dp),
                    color = textBackgroundColor.copy(alpha = 0.12f),
                    modifier =
                        Modifier
                            .height(44.dp)
                            .width(44.dp),
                ) {
                    Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                        Icon(
                            painter = painterResource(R.drawable.more_horiz),
                            contentDescription = null,
                            tint = textBackgroundColor,
                            modifier = Modifier.size(22.dp),
                        )
                    }
                }
            }
        }

        PlayerDesignStyle.V1 -> {
            Box(
                modifier =
                    Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(textButtonColor)
                        .clickable {
                            val intent =
                                Intent().apply {
                                    action = Intent.ACTION_SEND
                                    type = "text/plain"
                                    putExtra(
                                        Intent.EXTRA_TEXT,
                                        "https://music.youtube.com/watch?v=${mediaMetadata.id}",
                                    )
                                }
                            context.startActivity(Intent.createChooser(intent, null))
                        },
            ) {
                Image(
                    painter = painterResource(R.drawable.share),
                    contentDescription = null,
                    colorFilter = ColorFilter.tint(iconButtonColor),
                    modifier =
                        Modifier
                            .align(Alignment.Center)
                            .size(24.dp),
                )
            }

            Spacer(modifier = Modifier.size(12.dp))

            Box(
                contentAlignment = Alignment.Center,
                modifier =
                    Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(textButtonColor)
                        .clickable {
                            menuState.show {
                                PlayerMenu(
                                    mediaMetadata = mediaMetadata,
                                    navController = navController,
                                    playerBottomSheetState = state,
                                    onShowDetailsDialog = {
                                        mediaMetadata.id.let {
                                            bottomSheetPageState.show {
                                                ShowMediaInfo(it)
                                            }
                                        }
                                    },
                                    onDismiss = menuState::dismiss,
                                )
                            }
                        },
            ) {
                Image(
                    painter = painterResource(R.drawable.more_horiz),
                    contentDescription = null,
                    colorFilter = ColorFilter.tint(iconButtonColor),
                )
            }
        }

        PlayerDesignStyle.V6 -> {
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Surface(
                    onClick = {
                        val intent =
                            Intent().apply {
                                action = Intent.ACTION_SEND
                                type = "text/plain"
                                putExtra(
                                    Intent.EXTRA_TEXT,
                                    "https://music.youtube.com/watch?v=${mediaMetadata.id}",
                                )
                            }
                        context.startActivity(Intent.createChooser(intent, null))
                    },
                    shape =
                        RoundedCornerShape(
                            topStart = 50.dp,
                            bottomStart = 50.dp,
                            topEnd = 6.dp,
                            bottomEnd = 6.dp,
                        ),
                    color = textBackgroundColor.copy(alpha = 0.12f),
                    modifier =
                        Modifier
                            .height(42.dp)
                            .width(42.dp),
                ) {
                    Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                        Icon(
                            painter = painterResource(R.drawable.share),
                            contentDescription = null,
                            tint = textBackgroundColor,
                            modifier = Modifier.size(20.dp),
                        )
                    }
                }

                Surface(
                    onClick = { playerConnection.toggleLike() },
                    shape = RoundedCornerShape(50),
                    color =
                        if (currentSongLiked) {
                            MaterialTheme.colorScheme.error.copy(alpha = 0.18f)
                        } else {
                            textBackgroundColor.copy(alpha = 0.12f)
                        },
                    modifier =
                        Modifier
                            .height(42.dp)
                            .width(42.dp),
                ) {
                    Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                        Icon(
                            painter =
                                painterResource(
                                    if (currentSongLiked) {
                                        R.drawable.favorite
                                    } else {
                                        R.drawable.favorite_border
                                    },
                                ),
                            contentDescription = null,
                            tint =
                                if (currentSongLiked) {
                                    MaterialTheme.colorScheme.error
                                } else {
                                    textBackgroundColor
                                },
                            modifier = Modifier.size(20.dp),
                        )
                    }
                }

                Surface(
                    onClick = {
                        menuState.show {
                            PlayerMenu(
                                mediaMetadata = mediaMetadata,
                                navController = navController,
                                playerBottomSheetState = state,
                                onShowDetailsDialog = {
                                    mediaMetadata.id.let {
                                        bottomSheetPageState.show {
                                            ShowMediaInfo(it)
                                        }
                                    }
                                },
                                onDismiss = menuState::dismiss,
                            )
                        }
                    },
                    shape =
                        RoundedCornerShape(
                            topStart = 6.dp,
                            bottomStart = 6.dp,
                            topEnd = 50.dp,
                            bottomEnd = 50.dp,
                        ),
                    color = textBackgroundColor.copy(alpha = 0.12f),
                    modifier =
                        Modifier
                            .height(42.dp)
                            .width(42.dp),
                ) {
                    Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                        Icon(
                            painter = painterResource(R.drawable.more_horiz),
                            contentDescription = null,
                            tint = textBackgroundColor,
                            modifier = Modifier.size(20.dp),
                        )
                    }
                }
            }
        }

        PlayerDesignStyle.V7, PlayerDesignStyle.V8, PlayerDesignStyle.V9, PlayerDesignStyle.V10, PlayerDesignStyle.V11 -> {
            Unit
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlayerSlider(
    sliderStyle: SliderStyle,
    sliderPosition: Long?,
    position: Long,
    duration: Long,
    isPlaying: Boolean,
    textButtonColor: Color,
    onValueChange: (Long) -> Unit,
    onValueChangeFinished: () -> Unit,
) {
    val safeDuration = if (duration <= 0L) 0f else duration.toFloat()
    val safeValue = (sliderPosition ?: position).toFloat().coerceIn(0f, maxOf(0f, safeDuration))

    StyledPlaybackSlider(
        sliderStyle = sliderStyle,
        value = safeValue,
        valueRange = 0f..maxOf(1f, safeDuration),
        onValueChange = { onValueChange(it.toLong()) },
        onValueChangeFinished = onValueChangeFinished,
        activeColor = textButtonColor,
        isPlaying = isPlaying,
        modifier = Modifier.padding(horizontal = PlayerHorizontalPadding),
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StyledPlaybackSlider(
    sliderStyle: SliderStyle,
    value: Float,
    valueRange: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit,
    onValueChangeFinished: () -> Unit,
    activeColor: Color,
    isPlaying: Boolean,
    modifier: Modifier = Modifier,
) {
    when (sliderStyle) {
        SliderStyle.Standard -> {
            Slider(
                value = value,
                valueRange = valueRange,
                onValueChange = onValueChange,
                onValueChangeFinished = onValueChangeFinished,
                colors = PlayerSliderColors.standardSliderColors(activeColor),
                modifier = modifier,
            )
        }

        SliderStyle.Wavy -> {
            val sliderState =
                rememberControlledSliderState(
                    value = value,
                    valueRange = valueRange,
                )
            Slider(
                state = sliderState,
                onValueChange = { updated ->
                    sliderState.value = updated
                    onValueChange(updated)
                },
                onValueChangeFinished = onValueChangeFinished,
                colors = PlayerSliderColors.wavySliderColors(activeColor),
                thumb = { Spacer(modifier = Modifier.size(0.dp)) },
                track = { sliderState ->
                    PlayerSliderTrack(
                        sliderState = sliderState,
                        colors = PlayerSliderColors.wavySliderColors(activeColor),
                        trackHeight = if (isPlaying) 6.dp else 3.dp,
                    )
                },
                modifier = modifier,
            )
        }

        SliderStyle.Thick -> {
            val sliderState =
                rememberControlledSliderState(
                    value = value,
                    valueRange = valueRange,
                )
            Slider(
                state = sliderState,
                onValueChange = { updated ->
                    sliderState.value = updated
                    onValueChange(updated)
                },
                onValueChangeFinished = onValueChangeFinished,
                colors = PlayerSliderColors.thickSliderColors(activeColor),
                thumb = { Spacer(modifier = Modifier.size(0.dp)) },
                track = { sliderState ->
                    PlayerSliderTrack(
                        sliderState = sliderState,
                        colors = PlayerSliderColors.thickSliderColors(activeColor),
                        trackHeight = 12.dp,
                    )
                },
                modifier = modifier,
            )
        }

        SliderStyle.Circular -> {
            val sliderState =
                rememberControlledSliderState(
                    value = value,
                    valueRange = valueRange,
                )
            Slider(
                state = sliderState,
                onValueChange = { updated ->
                    sliderState.value = updated
                    onValueChange(updated)
                },
                onValueChangeFinished = onValueChangeFinished,
                colors = PlayerSliderColors.circularSliderColors(activeColor),
                modifier = modifier,
            )
        }

        SliderStyle.Simple -> {
            val sliderState =
                rememberControlledSliderState(
                    value = value,
                    valueRange = valueRange,
                )
            Slider(
                state = sliderState,
                onValueChange = { updated ->
                    sliderState.value = updated
                    onValueChange(updated)
                },
                onValueChangeFinished = onValueChangeFinished,
                colors = PlayerSliderColors.simpleSliderColors(activeColor),
                thumb = { Spacer(modifier = Modifier.size(0.dp)) },
                track = { sliderState ->
                    PlayerSliderTrack(
                        sliderState = sliderState,
                        colors = PlayerSliderColors.simpleSliderColors(activeColor),
                        trackHeight = 3.dp,
                    )
                },
                modifier = modifier,
            )
        }
    }
}

@Composable
fun PlayerTimeLabel(
    sliderPosition: Long?,
    position: Long,
    duration: Long,
    textBackgroundColor: Color,
    showRemainingTime: Boolean = false,
    centerContent: @Composable (() -> Unit)? = null,
) {
    Box(
        modifier =
            Modifier
                .fillMaxWidth()
                .padding(horizontal = PlayerHorizontalPadding + 4.dp),
    ) {
        Text(
            text = makeTimeString(sliderPosition ?: position),
            style = MaterialTheme.typography.labelMedium,
            color = textBackgroundColor,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.align(Alignment.CenterStart),
        )

        if (centerContent != null) {
            Box(
                modifier = Modifier.align(Alignment.Center),
                contentAlignment = Alignment.Center,
            ) {
                centerContent()
            }
        }

        Text(
            text =
                if (duration != C.TIME_UNSET) {
                    if (showRemainingTime) {
                        val remaining = duration - (sliderPosition ?: position)
                        "-${makeTimeString(remaining.coerceAtLeast(0))}"
                    } else {
                        makeTimeString(duration)
                    }
                } else {
                    ""
                },
            style = MaterialTheme.typography.labelMedium,
            color = textBackgroundColor,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.align(Alignment.CenterEnd),
        )
    }
}

@Composable
fun PlayerPlaybackControls(
    playerDesignStyle: PlayerDesignStyle,
    playbackState: Int,
    isPlaying: Boolean,
    isLoading: Boolean,
    repeatMode: Int,
    canSkipPrevious: Boolean,
    canSkipNext: Boolean,
    textButtonColor: Color,
    iconButtonColor: Color,
    textBackgroundColor: Color,
    icBackgroundColor: Color,
    playPauseRoundness: androidx.compose.ui.unit.Dp,
    playerConnection: PlayerConnection,
    currentSongLiked: Boolean,
) {
    val haptic = LocalHapticFeedback.current
    val shuffleModeEnabled by playerConnection.shuffleModeEnabled.collectAsState()
    val view = LocalView.current
    val (enableHapticFeedback) = rememberPreference(EnableHapticFeedbackKey, true)

    val cinematicPlayPauseCorner by animateDpAsState(
        targetValue = if (isPlaying) 28.dp else 44.dp,
        animationSpec =
            spring(
                dampingRatio = Spring.DampingRatioMediumBouncy,
                stiffness = Spring.StiffnessMedium,
            ),
        label = "cinematicPlayPauseCorner",
    )

    when (playerDesignStyle) {
        PlayerDesignStyle.V2 -> {
            BoxWithConstraints(
                modifier = Modifier.fillMaxWidth(),
            ) {
                val maxW = maxWidth
                val playButtonHeight = maxW / 6f
                val playButtonWidth = playButtonHeight * 1.6f
                val sideButtonHeight = playButtonHeight * 0.8f
                val sideButtonWidth = sideButtonHeight * 1.3f

                Row(
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    FilledTonalIconButton(
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            playerConnection.seekToPrevious()
                        },
                        enabled = canSkipPrevious,
                        colors =
                            IconButtonDefaults.filledTonalIconButtonColors(
                                containerColor = textButtonColor,
                                contentColor = iconButtonColor,
                            ),
                        modifier =
                            Modifier
                                .size(width = sideButtonWidth, height = sideButtonHeight)
                                .clip(RoundedCornerShape(32.dp)),
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.skip_previous),
                            contentDescription = null,
                            modifier = Modifier.size(32.dp),
                        )
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    FilledIconButton(
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            if (playbackState == STATE_ENDED) {
                                playerConnection.player.seekTo(0, 0)
                                playerConnection.player.playWhenReady = true
                            } else {
                                playerConnection.player.togglePlayPause()
                            }
                        },
                        colors =
                            IconButtonDefaults.filledIconButtonColors(
                                containerColor = textButtonColor,
                                contentColor = iconButtonColor,
                            ),
                        modifier =
                            Modifier
                                .size(width = playButtonWidth, height = playButtonHeight)
                                .clip(RoundedCornerShape(32.dp)),
                    ) {
                        if (isLoading) {
                            CircularWavyProgressIndicator(
                                modifier = Modifier.size(42.dp),
                                color = iconButtonColor,
                            )
                        } else {
                            Icon(
                                painter =
                                    painterResource(
                                        when {
                                            playbackState == STATE_ENDED -> R.drawable.replay
                                            isPlaying -> R.drawable.pause
                                            else -> R.drawable.play
                                        },
                                    ),
                                contentDescription = null,
                                modifier = Modifier.size(42.dp),
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    FilledTonalIconButton(
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            playerConnection.seekToNext()
                        },
                        enabled = canSkipNext,
                        colors =
                            IconButtonDefaults.filledTonalIconButtonColors(
                                containerColor = textButtonColor,
                                contentColor = iconButtonColor,
                            ),
                        modifier =
                            Modifier
                                .size(width = sideButtonWidth, height = sideButtonHeight)
                                .clip(RoundedCornerShape(32.dp)),
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.skip_next),
                            contentDescription = null,
                            modifier = Modifier.size(32.dp),
                        )
                    }
                }
            }
        }

        PlayerDesignStyle.V3 -> {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = PlayerHorizontalPadding),
            ) {
                Row(
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Box(
                        modifier =
                            Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .clickable {
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    playerConnection.player.shuffleModeEnabled = !shuffleModeEnabled
                                },
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.shuffle),
                            contentDescription = null,
                            tint =
                                textBackgroundColor.copy(
                                    alpha = if (shuffleModeEnabled) 1f else 0.4f,
                                ),
                            modifier = Modifier.size(22.dp),
                        )
                    }

                    Box(
                        modifier =
                            Modifier
                                .size(52.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(textBackgroundColor.copy(alpha = 0.08f))
                                .clickable(enabled = canSkipPrevious) {
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    playerConnection.seekToPrevious()
                                },
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.skip_previous),
                            contentDescription = null,
                            tint = textBackgroundColor.copy(alpha = if (canSkipPrevious) 0.9f else 0.4f),
                            modifier = Modifier.size(26.dp),
                        )
                    }

                    Box(
                        modifier =
                            Modifier
                                .size(70.dp)
                                .clip(RoundedCornerShape(50))
                                .background(textBackgroundColor)
                                .clickable {
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    if (playbackState == STATE_ENDED) {
                                        playerConnection.player.seekTo(0, 0)
                                        playerConnection.player.playWhenReady = true
                                    } else {
                                        playerConnection.player.togglePlayPause()
                                    }
                                },
                        contentAlignment = Alignment.Center,
                    ) {
                        if (isLoading) {
                            CircularWavyProgressIndicator(
                                modifier = Modifier.size(32.dp),
                                color = icBackgroundColor,
                            )
                        } else {
                            Icon(
                                painter =
                                    painterResource(
                                        when {
                                            playbackState == STATE_ENDED -> R.drawable.replay
                                            isPlaying -> R.drawable.pause
                                            else -> R.drawable.play
                                        },
                                    ),
                                contentDescription = null,
                                tint = icBackgroundColor,
                                modifier = Modifier.size(34.dp),
                            )
                        }
                    }

                    Box(
                        modifier =
                            Modifier
                                .size(52.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(textBackgroundColor.copy(alpha = 0.08f))
                                .clickable(enabled = canSkipNext) {
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    playerConnection.seekToNext()
                                },
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.skip_next),
                            contentDescription = null,
                            tint = textBackgroundColor.copy(alpha = if (canSkipNext) 0.9f else 0.4f),
                            modifier = Modifier.size(26.dp),
                        )
                    }

                    Box(
                        modifier =
                            Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .clickable {
                                    if (enableHapticFeedback) {
                                        view.performHapticFeedback(
                                            android.view.HapticFeedbackConstants.CONTEXT_CLICK,
                                            android.view.HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING,
                                        )
                                    }
                                    playerConnection.player.toggleRepeatMode()
                                },
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(
                            painter =
                                painterResource(
                                    when (repeatMode) {
                                        Player.REPEAT_MODE_OFF, Player.REPEAT_MODE_ALL -> R.drawable.repeat
                                        Player.REPEAT_MODE_ONE -> R.drawable.repeat_one
                                        else -> R.drawable.repeat
                                    },
                                ),
                            contentDescription = null,
                            tint =
                                textBackgroundColor.copy(
                                    alpha = if (repeatMode == Player.REPEAT_MODE_OFF) 0.4f else 1f,
                                ),
                            modifier = Modifier.size(22.dp),
                        )
                    }
                }
            }
        }

        PlayerDesignStyle.V4 -> {
            BoxWithConstraints(
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = PlayerHorizontalPadding),
            ) {
                val baseLarge = 56.dp
                val baseSmall = 46.dp
                val baseGap = 12.dp
                val baseLargeIcon = 28.dp
                val baseSmallIcon = 22.dp
                val baseLargeRadius = 18.dp
                val baseSmallRadius = 16.dp
                val centerSize = 88.dp
                val centerPadding = 40.dp
                val sideTotal = (maxWidth - centerSize - centerPadding) / 2f
                val scale =
                    ((sideTotal - baseGap) / (baseLarge + baseSmall)).coerceAtMost(1f).coerceAtLeast(0.6f)
                val large = baseLarge * scale
                val small = baseSmall * scale
                val gap = baseGap * scale
                val largeIcon = baseLargeIcon * scale
                val smallIcon = baseSmallIcon * scale
                val largeRadius = baseLargeRadius * scale
                val smallRadius = baseSmallRadius * scale

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Surface(
                            onClick = {
                                if (enableHapticFeedback) {
                                    view.performHapticFeedback(
                                        android.view.HapticFeedbackConstants.CONTEXT_CLICK,
                                        android.view.HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING,
                                    )
                                }
                                playerConnection.player.shuffleModeEnabled = !shuffleModeEnabled
                            },
                            shape = RoundedCornerShape(smallRadius),
                            color =
                                textBackgroundColor.copy(
                                    alpha = if (shuffleModeEnabled) 0.2f else 0.08f,
                                ),
                            modifier = Modifier.size(small),
                        ) {
                            Box(
                                modifier = Modifier.fillMaxSize(),
                                contentAlignment = Alignment.Center,
                            ) {
                                Icon(
                                    painter = painterResource(R.drawable.shuffle),
                                    contentDescription = null,
                                    tint =
                                        textBackgroundColor.copy(
                                            alpha = if (shuffleModeEnabled) 1f else 0.6f,
                                        ),
                                    modifier = Modifier.size(smallIcon),
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(gap))

                        Surface(
                            onClick = {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                playerConnection.seekToPrevious()
                            },
                            enabled = canSkipPrevious,
                            shape = RoundedCornerShape(largeRadius),
                            color = textBackgroundColor.copy(alpha = 0.15f),
                            modifier = Modifier.size(large),
                        ) {
                            Box(
                                modifier = Modifier.fillMaxSize(),
                                contentAlignment = Alignment.Center,
                            ) {
                                Icon(
                                    painter = painterResource(R.drawable.skip_previous),
                                    contentDescription = null,
                                    tint =
                                        textBackgroundColor.copy(
                                            alpha = if (canSkipPrevious) 1f else 0.4f,
                                        ),
                                    modifier = Modifier.size(largeIcon),
                                )
                            }
                        }
                    }

                    Surface(
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            if (playbackState == STATE_ENDED) {
                                playerConnection.player.seekTo(0, 0)
                                playerConnection.player.playWhenReady = true
                            } else {
                                playerConnection.player.togglePlayPause()
                            }
                        },
                        shape = RoundedCornerShape(cinematicPlayPauseCorner),
                        color = textButtonColor,
                        modifier =
                            Modifier
                                .padding(horizontal = 20.dp)
                                .size(88.dp),
                    ) {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center,
                        ) {
                            if (isLoading) {
                                CircularWavyProgressIndicator(
                                    modifier = Modifier.size(40.dp),
                                    color = icBackgroundColor,
                                )
                            } else {
                                Icon(
                                    painter =
                                        painterResource(
                                            when {
                                                playbackState == STATE_ENDED -> R.drawable.replay
                                                isPlaying -> R.drawable.pause
                                                else -> R.drawable.play
                                            },
                                        ),
                                    contentDescription = null,
                                    tint = icBackgroundColor,
                                    modifier = Modifier.size(44.dp),
                                )
                            }
                        }
                    }
                    Row(
                        modifier = Modifier.weight(1f),
                        horizontalArrangement = Arrangement.Start,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Surface(
                            onClick = {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                playerConnection.seekToNext()
                            },
                            enabled = canSkipNext,
                            shape = RoundedCornerShape(largeRadius),
                            color = textBackgroundColor.copy(alpha = 0.15f),
                            modifier = Modifier.size(large),
                        ) {
                            Box(
                                modifier = Modifier.fillMaxSize(),
                                contentAlignment = Alignment.Center,
                            ) {
                                Icon(
                                    painter = painterResource(R.drawable.skip_next),
                                    contentDescription = null,
                                    tint =
                                        textBackgroundColor.copy(
                                            alpha = if (canSkipNext) 1f else 0.4f,
                                        ),
                                    modifier = Modifier.size(largeIcon),
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(gap))

                        Surface(
                            onClick = {
                                if (enableHapticFeedback) {
                                    view.performHapticFeedback(
                                        android.view.HapticFeedbackConstants.CONTEXT_CLICK,
                                        android.view.HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING,
                                    )
                                }
                                playerConnection.player.toggleRepeatMode()
                            },
                            shape = RoundedCornerShape(smallRadius),
                            color =
                                textBackgroundColor.copy(
                                    alpha = if (repeatMode != Player.REPEAT_MODE_OFF) 0.2f else 0.08f,
                                ),
                            modifier = Modifier.size(small),
                        ) {
                            Box(
                                modifier = Modifier.fillMaxSize(),
                                contentAlignment = Alignment.Center,
                            ) {
                                Icon(
                                    painter =
                                        painterResource(
                                            when (repeatMode) {
                                                Player.REPEAT_MODE_ONE -> R.drawable.repeat_one
                                                else -> R.drawable.repeat
                                            },
                                        ),
                                    contentDescription = null,
                                    tint =
                                        textBackgroundColor.copy(
                                            alpha = if (repeatMode == Player.REPEAT_MODE_OFF) 0.6f else 1f,
                                        ),
                                    modifier = Modifier.size(smallIcon),
                                )
                            }
                        }
                    }
                }
            }
        }

        PlayerDesignStyle.V1, PlayerDesignStyle.V5 -> {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = PlayerHorizontalPadding),
            ) {
                Box(modifier = Modifier.weight(1f)) {
                    ResizableIconButton(
                        icon =
                            when (repeatMode) {
                                Player.REPEAT_MODE_OFF, Player.REPEAT_MODE_ALL -> R.drawable.repeat
                                Player.REPEAT_MODE_ONE -> R.drawable.repeat_one
                                else -> throw IllegalStateException()
                            },
                        color = textBackgroundColor,
                        modifier =
                            Modifier
                                .size(32.dp)
                                .padding(4.dp)
                                .align(Alignment.Center)
                                .alpha(if (repeatMode == Player.REPEAT_MODE_OFF) 0.5f else 1f),
                        onClick = {
                            if (enableHapticFeedback) {
                                view.performHapticFeedback(
                                    android.view.HapticFeedbackConstants.CONTEXT_CLICK,
                                    android.view.HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING,
                                )
                            }
                            playerConnection.player.toggleRepeatMode()
                        },
                    )
                }

                Box(modifier = Modifier.weight(1f)) {
                    ResizableIconButton(
                        icon = R.drawable.skip_previous,
                        enabled = canSkipPrevious,
                        color = textBackgroundColor,
                        modifier =
                            Modifier
                                .size(32.dp)
                                .align(Alignment.Center),
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            playerConnection.seekToPrevious()
                        },
                    )
                }

                Spacer(Modifier.width(8.dp))

                Box(
                    modifier =
                        Modifier
                            .size(72.dp)
                            .clip(RoundedCornerShape(playPauseRoundness))
                            .background(textButtonColor)
                            .clickable {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                if (playbackState == STATE_ENDED) {
                                    playerConnection.player.seekTo(0, 0)
                                    playerConnection.player.playWhenReady = true
                                } else {
                                    playerConnection.player.togglePlayPause()
                                }
                            },
                ) {
                    if (isLoading) {
                        CircularWavyProgressIndicator(
                            modifier =
                                Modifier
                                    .align(Alignment.Center)
                                    .size(36.dp),
                            color = iconButtonColor,
                        )
                    } else {
                        Image(
                            painter =
                                painterResource(
                                    if (playbackState ==
                                        STATE_ENDED
                                    ) {
                                        R.drawable.replay
                                    } else if (isPlaying) {
                                        R.drawable.pause
                                    } else {
                                        R.drawable.play
                                    },
                                ),
                            contentDescription = null,
                            colorFilter = ColorFilter.tint(iconButtonColor),
                            modifier =
                                Modifier
                                    .align(Alignment.Center)
                                    .size(36.dp),
                        )
                    }
                }

                Spacer(Modifier.width(8.dp))

                Box(modifier = Modifier.weight(1f)) {
                    ResizableIconButton(
                        icon = R.drawable.skip_next,
                        enabled = canSkipNext,
                        color = textBackgroundColor,
                        modifier =
                            Modifier
                                .size(32.dp)
                                .align(Alignment.Center),
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            playerConnection.seekToNext()
                        },
                    )
                }

                Box(modifier = Modifier.weight(1f)) {
                    ResizableIconButton(
                        icon = if (currentSongLiked) R.drawable.favorite else R.drawable.favorite_border,
                        color = if (currentSongLiked) MaterialTheme.colorScheme.error else textBackgroundColor,
                        modifier =
                            Modifier
                                .size(32.dp)
                                .padding(4.dp)
                                .align(Alignment.Center),
                        onClick = playerConnection::toggleLike,
                    )
                }
            }
        }

        PlayerDesignStyle.V6 -> {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = PlayerHorizontalPadding),
            ) {
                Surface(
                    shape = RoundedCornerShape(28.dp),
                    color = textBackgroundColor.copy(alpha = 0.08f),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Row(
                        modifier =
                            Modifier
                                .fillMaxWidth()
                                .padding(6.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Surface(
                            onClick = {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                playerConnection.seekToPrevious()
                            },
                            enabled = canSkipPrevious,
                            shape =
                                RoundedCornerShape(
                                    topStart = 22.dp,
                                    bottomStart = 22.dp,
                                    topEnd = 8.dp,
                                    bottomEnd = 8.dp,
                                ),
                            color = MaterialTheme.colorScheme.secondaryContainer,
                            modifier =
                                Modifier
                                    .weight(1f)
                                    .height(56.dp),
                        ) {
                            Box(
                                modifier = Modifier.fillMaxSize(),
                                contentAlignment = Alignment.Center,
                            ) {
                                Icon(
                                    painter = painterResource(R.drawable.skip_previous),
                                    contentDescription = null,
                                    tint =
                                        MaterialTheme.colorScheme.onSecondaryContainer.copy(
                                            alpha = if (canSkipPrevious) 1f else 0.4f,
                                        ),
                                    modifier = Modifier.size(28.dp),
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(6.dp))

                        Surface(
                            onClick = {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                if (playbackState == STATE_ENDED) {
                                    playerConnection.player.seekTo(0, 0)
                                    playerConnection.player.playWhenReady = true
                                } else {
                                    playerConnection.player.togglePlayPause()
                                }
                            },
                            shape = RoundedCornerShape(28.dp),
                            color = textButtonColor,
                            modifier =
                                Modifier
                                    .size(width = 88.dp, height = 80.dp),
                        ) {
                            Box(
                                modifier = Modifier.fillMaxSize(),
                                contentAlignment = Alignment.Center,
                            ) {
                                if (isLoading) {
                                    CircularWavyProgressIndicator(
                                        modifier = Modifier.size(40.dp),
                                        color = iconButtonColor,
                                    )
                                } else {
                                    Icon(
                                        painter =
                                            painterResource(
                                                when {
                                                    playbackState == STATE_ENDED -> R.drawable.replay
                                                    isPlaying -> R.drawable.pause
                                                    else -> R.drawable.play
                                                },
                                            ),
                                        contentDescription = null,
                                        tint = iconButtonColor,
                                        modifier = Modifier.size(44.dp),
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.width(6.dp))

                        Surface(
                            onClick = {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                playerConnection.seekToNext()
                            },
                            enabled = canSkipNext,
                            shape =
                                RoundedCornerShape(
                                    topStart = 8.dp,
                                    bottomStart = 8.dp,
                                    topEnd = 22.dp,
                                    bottomEnd = 22.dp,
                                ),
                            color = MaterialTheme.colorScheme.secondaryContainer,
                            modifier =
                                Modifier
                                    .weight(1f)
                                    .height(56.dp),
                        ) {
                            Box(
                                modifier = Modifier.fillMaxSize(),
                                contentAlignment = Alignment.Center,
                            ) {
                                Icon(
                                    painter = painterResource(R.drawable.skip_next),
                                    contentDescription = null,
                                    tint =
                                        MaterialTheme.colorScheme.onSecondaryContainer.copy(
                                            alpha = if (canSkipNext) 1f else 0.4f,
                                        ),
                                    modifier = Modifier.size(28.dp),
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Surface(
                        onClick = {
                            if (enableHapticFeedback) {
                                view.performHapticFeedback(
                                    android.view.HapticFeedbackConstants.CONTEXT_CLICK,
                                    android.view.HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING,
                                )
                            }
                            playerConnection.player.shuffleModeEnabled = !shuffleModeEnabled
                        },
                        shape = RoundedCornerShape(50),
                        color =
                            if (shuffleModeEnabled) {
                                MaterialTheme.colorScheme.tertiaryContainer
                            } else {
                                textBackgroundColor.copy(alpha = 0.08f)
                            },
                        modifier = Modifier.size(40.dp),
                    ) {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(
                                painter = painterResource(R.drawable.shuffle),
                                contentDescription = null,
                                tint =
                                    if (shuffleModeEnabled) {
                                        MaterialTheme.colorScheme.onTertiaryContainer
                                    } else {
                                        textBackgroundColor.copy(alpha = 0.5f)
                                    },
                                modifier = Modifier.size(20.dp),
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    Surface(
                        onClick = {
                            if (enableHapticFeedback) {
                                view.performHapticFeedback(
                                    android.view.HapticFeedbackConstants.CONTEXT_CLICK,
                                    android.view.HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING,
                                )
                            }
                            playerConnection.player.toggleRepeatMode()
                        },
                        shape = RoundedCornerShape(50),
                        color =
                            if (repeatMode != Player.REPEAT_MODE_OFF) {
                                MaterialTheme.colorScheme.tertiaryContainer
                            } else {
                                textBackgroundColor.copy(alpha = 0.08f)
                            },
                        modifier = Modifier.size(40.dp),
                    ) {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(
                                painter =
                                    painterResource(
                                        when (repeatMode) {
                                            Player.REPEAT_MODE_ONE -> R.drawable.repeat_one
                                            else -> R.drawable.repeat
                                        },
                                    ),
                                contentDescription = null,
                                tint =
                                    if (repeatMode != Player.REPEAT_MODE_OFF) {
                                        MaterialTheme.colorScheme.onTertiaryContainer
                                    } else {
                                        textBackgroundColor.copy(alpha = 0.5f)
                                    },
                                modifier = Modifier.size(20.dp),
                            )
                        }
                    }
                }
            }
        }

        PlayerDesignStyle.V7, PlayerDesignStyle.V8, PlayerDesignStyle.V9, PlayerDesignStyle.V10, PlayerDesignStyle.V11 -> {
            Unit
        }
    }
}

/**
 * Wrapper composable that combines all player control components.
 * This replaces the large inline controlsContent lambda in BottomSheetPlayer
 * to reduce JIT compilation overhead.
 */
@Composable
fun PlayerControlsContent(
    mediaMetadata: MediaMetadata,
    playerDesignStyle: PlayerDesignStyle,
    sliderStyle: SliderStyle,
    playbackState: Int,
    isPlaying: Boolean,
    isLoading: Boolean,
    repeatMode: Int,
    canSkipPrevious: Boolean,
    canSkipNext: Boolean,
    textButtonColor: Color,
    iconButtonColor: Color,
    textBackgroundColor: Color,
    icBackgroundColor: Color,
    sliderPosition: Long?,
    position: Long,
    duration: Long,
    playerConnection: PlayerConnection,
    navController: NavController,
    state: BottomSheetState,
    menuState: MenuState,
    bottomSheetPageState: BottomSheetPageState,
    context: Context,
    onSliderValueChange: (Long) -> Unit,
    onSliderValueChangeFinished: () -> Unit,
    currentFormat: FormatEntity? = null,
    landscape: Boolean = false,
) {
    val currentSong by playerConnection.currentSong.collectAsState(initial = null)
    val currentSongLiked = currentSong?.song?.liked == true

    val playPauseRoundness by animateDpAsState(
        targetValue = if (isPlaying) 24.dp else 36.dp,
        animationSpec = tween(durationMillis = 90, easing = LinearEasing),
        label = "playPauseRoundness",
    )

    PlayerControlsLayout(
        landscape = landscape,
        playbackContent = {
            PlayerPlaybackControls(
                    playerDesignStyle = playerDesignStyle,
                    playbackState = playbackState,
                    isPlaying = isPlaying,
                    isLoading = isLoading,
                    repeatMode = repeatMode,
                    canSkipPrevious = canSkipPrevious,
                    canSkipNext = canSkipNext,
                    textButtonColor = textButtonColor,
                    iconButtonColor = iconButtonColor,
                    textBackgroundColor = textBackgroundColor,
                    icBackgroundColor = icBackgroundColor,
                    playPauseRoundness = playPauseRoundness,
                    playerConnection = playerConnection,
                    currentSongLiked = currentSongLiked,
                )
            },
        ) {
        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
            modifier =
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = PlayerHorizontalPadding),
        ) {
            Column(modifier = Modifier.weight(1f)) {
                PlayerTitleSection(
                    mediaMetadata = mediaMetadata,
                    textBackgroundColor = textBackgroundColor,
                    navController = navController,
                    state = state,
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            PlayerTopActions(
                mediaMetadata = mediaMetadata,
                playerDesignStyle = playerDesignStyle,
                textButtonColor = textButtonColor,
                iconButtonColor = iconButtonColor,
                textBackgroundColor = textBackgroundColor,
                playerConnection = playerConnection,
                navController = navController,
                menuState = menuState,
                state = state,
                bottomSheetPageState = bottomSheetPageState,
                context = context,
                currentSongLiked = currentSongLiked,
            )
        }

        Spacer(Modifier.height(12.dp))
        PlayerSlider(
            sliderStyle = sliderStyle,
            sliderPosition = sliderPosition,
            position = position,
            duration = duration,
            isPlaying = isPlaying,
            textButtonColor = textButtonColor,
            onValueChange = onSliderValueChange,
            onValueChangeFinished = onSliderValueChangeFinished,
        )

        Spacer(Modifier.height(4.dp))

        PlayerTimeLabel(
            sliderPosition = sliderPosition,
            position = position,
            duration = duration,
            textBackgroundColor = textBackgroundColor,
            showRemainingTime = playerDesignStyle == PlayerDesignStyle.V7,
            centerContent =
                if (playerDesignStyle == PlayerDesignStyle.V7 && currentFormat != null) {
                    {
                        val codec = currentFormat.mimeType.substringAfter("/").uppercase()
                        val label =
                            when {
                                codec.contains("FLAC") || codec.contains("ALAC") -> "Lossless"
                                codec.contains("OPUS") -> codec
                                codec.contains("AAC") -> codec
                                codec.contains("MP4A") -> "AAC"
                                codec.contains("VORBIS") -> "Vorbis"
                                else -> codec
                            }
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = textBackgroundColor.copy(alpha = 0.12f),
                        ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                                ) {
                                    Icon(
                                        painter = painterResource(R.drawable.graphic_eq),
                                        contentDescription = null,
                                        modifier = Modifier.size(14.dp),
                                        tint = textBackgroundColor.copy(alpha = 0.8f),
                                    )
                                    Spacer(Modifier.width(4.dp))
                                    Text(
                                        text = label,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = textBackgroundColor.copy(alpha = 0.8f),
                                    )
                                }
                            }
                        }
                    } else {
                        null
                    },
            )

            Spacer(Modifier.height(12.dp))
    }
}

@Composable
private fun PlayerControlsLayout(
    landscape: Boolean,
    playbackContent: @Composable () -> Unit,
    content: @Composable () -> Unit,
) {
    if (landscape) {
        LandscapePlayerControls(playbackContent = { playbackContent() }) {
            content()
        }
    } else {
        Column(modifier = Modifier.fillMaxWidth()) {
            content()
            playbackContent()
        }
    }
}

@Composable
fun V8PlayerControlsContent(
    mediaMetadata: MediaMetadata,
    queueTitle: String?,
    playbackState: Int,
    isPlaying: Boolean,
    isLoading: Boolean,
    canSkipPrevious: Boolean,
    canSkipNext: Boolean,
    currentSongLiked: Boolean,
    sliderPosition: Long?,
    position: Long,
    duration: Long,
    volume: Float,
    showVolumeBar: Boolean,
    currentFormat: FormatEntity?,
    playerConnection: PlayerConnection,
    navController: NavController,
    state: BottomSheetState,
    menuState: MenuState,
    bottomSheetPageState: BottomSheetPageState,
    onSliderValueChange: (Long) -> Unit,
    onSliderValueChangeFinished: () -> Unit,
    onVolumeChange: (Float) -> Unit,
    modifier: Modifier = Modifier,
    landscape: Boolean = false,
) {
    val foreground = Color.White
    val secondaryForeground = foreground.copy(alpha = 0.72f)
    val onMenuClick =
        remember(mediaMetadata, navController, state, menuState, bottomSheetPageState) {
            {
                menuState.show {
                    PlayerMenu(
                        mediaMetadata = mediaMetadata,
                        navController = navController,
                        playerBottomSheetState = state,
                        onShowDetailsDialog = {
                            bottomSheetPageState.show {
                                ShowMediaInfo(mediaMetadata.id)
                            }
                        },
                        onDismiss = menuState::dismiss,
                    )
                }
            }
        }
    val titleActions = rememberPlayerTitleActions(mediaMetadata, navController, state)
    val onTitleClick = titleActions.onTitleClick
    val onArtistClick = titleActions.onArtistClick
    val onPlayPauseClick =
        remember(playbackState, playerConnection) {
            {
                if (playbackState == STATE_ENDED) {
                    playerConnection.player.seekTo(0, 0)
                    playerConnection.player.playWhenReady = true
                } else {
                    playerConnection.player.togglePlayPause()
                }
            }
        }
    val onToggleLike =
        remember(playerConnection) {
            { playerConnection.toggleLike() }
        }
    val onPreviousClick =
        remember(playerConnection) {
            { playerConnection.seekToPrevious() }
        }
    val onNextClick =
        remember(playerConnection) {
            { playerConnection.seekToNext() }
        }

    BoxWithConstraints(modifier = modifier.fillMaxWidth()) {
        val horizontalPadding =
            if (landscape) {
                36.dp
            } else if (maxWidth < 380.dp) {
                22.dp
            } else {
                24.dp
            }
        val contentGap = if (landscape) 14.dp else 18.dp
        val progressToTransportGap = if (landscape) 12.dp else 18.dp
        val transportToVolumeGap = if (landscape) 12.dp else 18.dp
        val subtitle = queueTitle ?: mediaMetadata.album?.title.orEmpty()

        Column(
            modifier =
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = horizontalPadding),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            if (subtitle.isNotBlank()) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.titleMedium,
                    color = secondaryForeground,
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier =
                        Modifier
                            .fillMaxWidth()
                            .basicMarquee(),
                )

                Spacer(Modifier.height(contentGap))
            }

            V8MetadataActions(
                title = mediaMetadata.title,
                explicit = mediaMetadata.explicit,
                artists = mediaMetadata.artists,
                liked = currentSongLiked,
                foreground = foreground,
                onMenuClick = onMenuClick,
                onToggleLike = onToggleLike,
                onTitleClick = onTitleClick,
                onArtistClick = onArtistClick,
            )

            Spacer(Modifier.height(contentGap))

            V8PlaybackProgress(
                sliderPosition = sliderPosition,
                position = position,
                duration = duration,
                currentFormat = currentFormat,
                foreground = foreground,
                onSliderValueChange = onSliderValueChange,
                onSliderValueChangeFinished = onSliderValueChangeFinished,
            )

            Spacer(Modifier.height(progressToTransportGap))

            V8TransportControls(
                playbackState = playbackState,
                isPlaying = isPlaying,
                isLoading = isLoading,
                canSkipPrevious = canSkipPrevious,
                canSkipNext = canSkipNext,
                foreground = foreground,
                onPreviousClick = onPreviousClick,
                onPlayPauseClick = onPlayPauseClick,
                onNextClick = onNextClick,
            )

            if (showVolumeBar) {
                Spacer(Modifier.height(transportToVolumeGap))

                V8VolumeControls(
                    volume = volume,
                    foreground = foreground,
                    secondaryForeground = secondaryForeground,
                    onVolumeChange = onVolumeChange,
                )
            }
        }
    }
}

@Composable
fun V8PlayerContent(
    mediaMetadata: MediaMetadata,
    queueTitle: String?,
    playbackState: Int,
    isPlaying: Boolean,
    isLoading: Boolean,
    canSkipPrevious: Boolean,
    canSkipNext: Boolean,
    currentSongLiked: Boolean,
    sliderPosition: Long?,
    position: Long,
    duration: Long,
    volume: Float,
    showVolumeBar: Boolean,
    playerConnection: PlayerConnection,
    navController: NavController,
    state: BottomSheetState,
    menuState: MenuState,
    bottomSheetPageState: BottomSheetPageState,
    currentFormat: FormatEntity?,
    canvasSource: CanvasSource?,
    canvasPrimaryUrl: String?,
    canvasFallbackUrl: String?,
    onSliderValueChange: (Long) -> Unit,
    onSliderValueChangeFinished: () -> Unit,
    onVolumeChange: (Float) -> Unit,
    modifier: Modifier = Modifier,
    landscape: Boolean = false,
) {
    val foreground = Color.White
    val secondaryForeground = foreground.copy(alpha = 0.72f)
    val baseArtworkUrl = mediaMetadata.thumbnailUrl?.highRes()
    val thumbnailSwapState =
        rememberThumbnailSwapState(
            videoId = mediaMetadata.id,
            ytmUrl = baseArtworkUrl,
            lowDataMode = rememberLowDataModeActive(),
            isMusicVideo = mediaMetadata.isMusicVideo,
        )
    val artworkUrl = thumbnailSwapState.displayUrl
    val subtitle = queueTitle ?: mediaMetadata.album?.title.orEmpty()
    val onMenuClick = {
        menuState.show {
            PlayerMenu(
                mediaMetadata = mediaMetadata,
                navController = navController,
                playerBottomSheetState = state,
                onShowDetailsDialog = {
                    bottomSheetPageState.show {
                        ShowMediaInfo(mediaMetadata.id)
                    }
                },
                onDismiss = menuState::dismiss,
            )
        }
    }

    val titleActions = rememberPlayerTitleActions(mediaMetadata, navController, state)
    val onTitleClick = titleActions.onTitleClick
    val onArtistClick = titleActions.onArtistClick

    if (landscape) {
        V8LandscapeContent(
            mediaMetadata = mediaMetadata,
            subtitle = subtitle,
            artists = mediaMetadata.artists,
            artworkUrl = artworkUrl,
            canvasSource = canvasSource,
            canvasPrimaryUrl = canvasPrimaryUrl,
            canvasFallbackUrl = canvasFallbackUrl,
            playbackState = playbackState,
            isPlaying = isPlaying,
            isLoading = isLoading,
            canSkipPrevious = canSkipPrevious,
            canSkipNext = canSkipNext,
            currentSongLiked = currentSongLiked,
            sliderPosition = sliderPosition,
            position = position,
            duration = duration,
            volume = volume,
            showVolumeBar = showVolumeBar,
            currentFormat = currentFormat,
            foreground = foreground,
            secondaryForeground = secondaryForeground,
            onMenuClick = onMenuClick,
            onToggleLike = playerConnection::toggleLike,
            onTitleClick = onTitleClick,
            onArtistClick = onArtistClick,
            onPreviousClick = playerConnection::seekToPrevious,
            onNextClick = playerConnection::seekToNext,
            onPlayPauseClick = {
                if (playbackState == STATE_ENDED) {
                    playerConnection.player.seekTo(0, 0)
                    playerConnection.player.playWhenReady = true
                } else {
                    playerConnection.player.togglePlayPause()
                }
            },
            onSliderValueChange = onSliderValueChange,
            onSliderValueChangeFinished = onSliderValueChangeFinished,
            onVolumeChange = onVolumeChange,
            modifier = modifier,
        )
    } else {
        V8PortraitContent(
            mediaMetadata = mediaMetadata,
            subtitle = subtitle,
            artists = mediaMetadata.artists,
            artworkUrl = artworkUrl,
            canvasSource = canvasSource,
            canvasPrimaryUrl = canvasPrimaryUrl,
            canvasFallbackUrl = canvasFallbackUrl,
            playbackState = playbackState,
            isPlaying = isPlaying,
            isLoading = isLoading,
            canSkipPrevious = canSkipPrevious,
            canSkipNext = canSkipNext,
            currentSongLiked = currentSongLiked,
            sliderPosition = sliderPosition,
            position = position,
            duration = duration,
            volume = volume,
            showVolumeBar = showVolumeBar,
            currentFormat = currentFormat,
            foreground = foreground,
            secondaryForeground = secondaryForeground,
            onMenuClick = onMenuClick,
            onToggleLike = playerConnection::toggleLike,
            onTitleClick = onTitleClick,
            onArtistClick = onArtistClick,
            onPreviousClick = playerConnection::seekToPrevious,
            onNextClick = playerConnection::seekToNext,
            onPlayPauseClick = {
                if (playbackState == STATE_ENDED) {
                    playerConnection.player.seekTo(0, 0)
                    playerConnection.player.playWhenReady = true
                } else {
                    playerConnection.player.togglePlayPause()
                }
            },
            onSliderValueChange = onSliderValueChange,
            onSliderValueChangeFinished = onSliderValueChangeFinished,
            onVolumeChange = onVolumeChange,
            modifier = modifier,
        )
    }
}

@Composable
private fun V8PortraitContent(
    mediaMetadata: MediaMetadata,
    subtitle: String,
    artists: List<MediaMetadata.Artist>,
    artworkUrl: String?,
    canvasSource: CanvasSource?,
    canvasPrimaryUrl: String?,
    canvasFallbackUrl: String?,
    playbackState: Int,
    isPlaying: Boolean,
    isLoading: Boolean,
    canSkipPrevious: Boolean,
    canSkipNext: Boolean,
    currentSongLiked: Boolean,
    sliderPosition: Long?,
    position: Long,
    duration: Long,
    volume: Float,
    showVolumeBar: Boolean,
    currentFormat: FormatEntity?,
    foreground: Color,
    secondaryForeground: Color,
    onMenuClick: () -> Unit,
    onToggleLike: () -> Unit,
    onPreviousClick: () -> Unit,
    onNextClick: () -> Unit,
    onPlayPauseClick: () -> Unit,
    onSliderValueChange: (Long) -> Unit,
    onSliderValueChangeFinished: () -> Unit,
    onVolumeChange: (Float) -> Unit,
    onTitleClick: () -> Unit,
    onArtistClick: (artistId: String) -> Unit,
    modifier: Modifier = Modifier,
) {
    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val contentPadding = if (maxWidth < 380.dp) 22.dp else 24.dp
        val compactHeight = maxHeight < 760.dp
        val veryCompactHeight = maxHeight < 680.dp
        val headerTop = if (compactHeight) 6.dp else 14.dp
        val headerToArtwork =
            when {
                veryCompactHeight -> 10.dp
                compactHeight -> 14.dp
                else -> 28.dp
            }
        val artworkToMetadata =
            when {
                veryCompactHeight -> 12.dp
                compactHeight -> 16.dp
                else -> 28.dp
            }
        val controlsGap = if (compactHeight) 10.dp else 18.dp
        val progressToTransportGap = if (compactHeight) 8.dp else 18.dp
        val transportToVolumeGap = if (compactHeight) 8.dp else 18.dp
        val bottomGap = if (compactHeight) 8.dp else 16.dp
        val volumeControlsHeight =
            if (showVolumeBar) {
                transportToVolumeGap + 30.dp
            } else {
                0.dp
            }
        val reservedControlsHeight =
            headerTop +
                56.dp +
                headerToArtwork +
                artworkToMetadata +
                58.dp +
                controlsGap +
                62.dp +
                progressToTransportGap +
                72.dp +
                volumeControlsHeight +
                bottomGap
        val maxArtworkSize =
            (maxWidth - contentPadding * 2)
                .coerceAtMost(if (compactHeight) 360.dp else 420.dp)
        val artworkSize =
            maxArtworkSize
                .coerceAtMost(maxHeight - reservedControlsHeight)
                .coerceAtLeast(0.dp)

        Column(
            modifier =
                Modifier
                    .fillMaxSize()
                    .padding(horizontal = contentPadding),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.height(headerTop))

            V8Header(
                title = stringResource(R.string.now_playing),
                subtitle = subtitle,
                foreground = foreground,
                secondaryForeground = secondaryForeground,
            )

            Spacer(Modifier.height(headerToArtwork))
            Spacer(Modifier.weight(1f))

            V8Artwork(
                artworkUrl = artworkUrl,
                canvasSource = canvasSource,
                canvasPrimaryUrl = canvasPrimaryUrl,
                canvasFallbackUrl = canvasFallbackUrl,
                isPlaying = isPlaying,
                size = artworkSize,
            )

            Spacer(Modifier.height(artworkToMetadata))

            V8MetadataActions(
                title = mediaMetadata.title,
                explicit = mediaMetadata.explicit,
                artists = artists,
                liked = currentSongLiked,
                foreground = foreground,
                onMenuClick = onMenuClick,
                onToggleLike = onToggleLike,
                onTitleClick = onTitleClick,
                onArtistClick = onArtistClick,
            )

            Spacer(Modifier.height(controlsGap))

            V8PlaybackProgress(
                sliderPosition = sliderPosition,
                position = position,
                duration = duration,
                currentFormat = currentFormat,
                foreground = foreground,
                onSliderValueChange = onSliderValueChange,
                onSliderValueChangeFinished = onSliderValueChangeFinished,
            )

            Spacer(Modifier.height(progressToTransportGap))

            V8TransportControls(
                playbackState = playbackState,
                isPlaying = isPlaying,
                isLoading = isLoading,
                canSkipPrevious = canSkipPrevious,
                canSkipNext = canSkipNext,
                foreground = foreground,
                onPreviousClick = onPreviousClick,
                onPlayPauseClick = onPlayPauseClick,
                onNextClick = onNextClick,
            )

            if (showVolumeBar) {
                Spacer(Modifier.height(transportToVolumeGap))

                V8VolumeControls(
                    volume = volume,
                    foreground = foreground,
                    secondaryForeground = secondaryForeground,
                    onVolumeChange = onVolumeChange,
                )
            }

            Spacer(Modifier.height(bottomGap))
        }
    }
}

@Composable
private fun V8LandscapeContent(
    mediaMetadata: MediaMetadata,
    subtitle: String,
    artists: List<MediaMetadata.Artist>,
    artworkUrl: String?,
    canvasSource: CanvasSource?,
    canvasPrimaryUrl: String?,
    canvasFallbackUrl: String?,
    playbackState: Int,
    isPlaying: Boolean,
    isLoading: Boolean,
    canSkipPrevious: Boolean,
    canSkipNext: Boolean,
    currentSongLiked: Boolean,
    sliderPosition: Long?,
    position: Long,
    duration: Long,
    volume: Float,
    showVolumeBar: Boolean,
    currentFormat: FormatEntity?,
    foreground: Color,
    secondaryForeground: Color,
    onMenuClick: () -> Unit,
    onToggleLike: () -> Unit,
    onPreviousClick: () -> Unit,
    onNextClick: () -> Unit,
    onPlayPauseClick: () -> Unit,
    onSliderValueChange: (Long) -> Unit,
    onSliderValueChangeFinished: () -> Unit,
    onVolumeChange: (Float) -> Unit,
    onTitleClick: () -> Unit,
    onArtistClick: (artistId: String) -> Unit,
    modifier: Modifier = Modifier,
) {
    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val horizontalPadding = 16.dp
        val contentGap = 24.dp
        val artworkSize =
            (maxHeight - 16.dp)
                .coerceAtMost((maxWidth - horizontalPadding * 2 - contentGap) * 0.44f)
                .coerceAtLeast(0.dp)

        Row(
            modifier =
                Modifier
                    .fillMaxSize()
                    .padding(horizontal = horizontalPadding, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(contentGap),
        ) {
            V8Artwork(
                artworkUrl = artworkUrl,
                canvasSource = canvasSource,
                canvasPrimaryUrl = canvasPrimaryUrl,
                canvasFallbackUrl = canvasFallbackUrl,
                isPlaying = isPlaying,
                size = artworkSize,
            )

            LandscapePlayerControls(
                modifier = Modifier.weight(1f).fillMaxHeight(),
                playbackContent = {
                    V8TransportControls(
                        playbackState = playbackState,
                        isPlaying = isPlaying,
                        isLoading = isLoading,
                        canSkipPrevious = canSkipPrevious,
                        canSkipNext = canSkipNext,
                        foreground = foreground,
                        onPreviousClick = onPreviousClick,
                        onPlayPauseClick = onPlayPauseClick,
                        onNextClick = onNextClick,
                    )
                },
            ) {
                V8Header(
                    title = stringResource(R.string.now_playing),
                    subtitle = subtitle,
                    foreground = foreground,
                    secondaryForeground = secondaryForeground,
                )

                Spacer(Modifier.height(4.dp))

                V8MetadataActions(
                    title = mediaMetadata.title,
                    explicit = mediaMetadata.explicit,
                    artists = artists,
                    liked = currentSongLiked,
                    foreground = foreground,
                    onMenuClick = onMenuClick,
                    onToggleLike = onToggleLike,
                    onTitleClick = onTitleClick,
                    onArtistClick = onArtistClick,
                )

                Spacer(Modifier.height(4.dp))

                if (showVolumeBar) {
                    Spacer(Modifier.height(4.dp))

                    V8VolumeControls(
                        volume = volume,
                        foreground = foreground,
                        secondaryForeground = secondaryForeground,
                        onVolumeChange = onVolumeChange,
                    )
                }
                V8PlaybackProgress(
                    sliderPosition = sliderPosition,
                    position = position,
                    duration = duration,
                    currentFormat = currentFormat,
                    foreground = foreground,
                    onSliderValueChange = onSliderValueChange,
                    onSliderValueChangeFinished = onSliderValueChangeFinished,
                )

                Spacer(Modifier.height(4.dp))

            }
        }
    }
}

@Composable
private fun V8Header(
    title: String,
    subtitle: String,
    foreground: Color,
    secondaryForeground: Color,
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(2.dp),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleLarge,
            color = foreground,
            textAlign = TextAlign.Center,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.fillMaxWidth(),
        )
        Text(
            text = subtitle,
            style = MaterialTheme.typography.titleMedium,
            color = secondaryForeground,
            textAlign = TextAlign.Center,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier =
                Modifier
                    .fillMaxWidth()
                    .basicMarquee(),
        )
    }
}

@Composable
private fun V8Artwork(
    artworkUrl: String?,
    canvasSource: CanvasSource?,
    canvasPrimaryUrl: String?,
    canvasFallbackUrl: String?,
    isPlaying: Boolean,
    size: androidx.compose.ui.unit.Dp,
) {
    val artworkRequest = rememberOfflineArtworkImageRequest(artworkUrl)
    Box(
        modifier =
            Modifier
                .size(size)
                .clip(RoundedCornerShape(8.dp))
                .background(Color.White.copy(alpha = 0.08f)),
    ) {
        AsyncImage(
            model = artworkRequest,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize(),
        )

        if (!canvasPrimaryUrl.isNullOrBlank() || !canvasFallbackUrl.isNullOrBlank()) {
            CanvasArtworkPlayer(
                source = canvasSource,
                primaryUrl = canvasPrimaryUrl,
                fallbackUrl = canvasFallbackUrl,
                isPlaying = isPlaying,
                resizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM,
                modifier = Modifier.fillMaxSize(),
            )
        }
    }
}

@Composable
private fun V8MetadataActions(
    title: String,
    explicit: Boolean,
    artists: List<MediaMetadata.Artist>,
    liked: Boolean,
    foreground: Color,
    onMenuClick: () -> Unit,
    onToggleLike: () -> Unit,
    onTitleClick: () -> Unit,
    onArtistClick: (artistId: String) -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(18.dp),
    ) {
        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            PlayerTitleText(
                title = title,
                explicit = explicit,
                color = foreground,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                modifier =
                    Modifier
                        .basicMarquee()
                        .clickable(
                            indication = tvFocusIndicationOrNull(),
                            interactionSource = remember { MutableInteractionSource() },
                            onClick = onTitleClick,
                        ),
            )
            ClickableArtists(
                artists = artists,
                onArtistClick = onArtistClick,
                style = MaterialTheme.typography.titleMedium,
                color = foreground,
                modifier = Modifier.basicMarquee(),
            )
        }

        Row(
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            V8ActionButton(
                iconRes = R.drawable.more_vert,
                contentDescription = stringResource(R.string.more_options),
                foreground = foreground,
                containerColor = foreground.copy(alpha = 0.16f),
                iconSize = 24.dp,
                onClick = onMenuClick,
            )
            V8ActionButton(
                iconRes = if (liked) R.drawable.favorite else R.drawable.favorite_border,
                contentDescription = stringResource(R.string.action_like),
                foreground = foreground,
                containerColor = foreground.copy(alpha = 0.16f),
                iconSize = 26.dp,
                onClick = onToggleLike,
            )
        }
    }
}

@Composable
private fun V8ActionButton(
    iconRes: Int,
    contentDescription: String,
    foreground: Color,
    containerColor: Color,
    iconSize: androidx.compose.ui.unit.Dp,
    onClick: () -> Unit,
) {
    Surface(
        onClick = onClick,
        shape = CircleShape,
        color = containerColor,
        modifier = Modifier.size(48.dp),
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                painter = painterResource(iconRes),
                contentDescription = contentDescription,
                tint = foreground,
                modifier = Modifier.size(iconSize),
            )
        }
    }
}

@Composable
private fun V8PlaybackProgress(
    sliderPosition: Long?,
    position: Long,
    duration: Long,
    currentFormat: FormatEntity?,
    foreground: Color,
    onSliderValueChange: (Long) -> Unit,
    onSliderValueChangeFinished: () -> Unit,
) {
    val safeDuration = if (duration <= 0L || duration == C.TIME_UNSET) 0f else duration.toFloat()
    val safeValue = (sliderPosition ?: position).toFloat().coerceIn(0f, safeDuration.coerceAtLeast(0f))

    Column(modifier = Modifier.fillMaxWidth()) {
        V8FlatSlider(
            value = safeValue,
            valueRange = 0f..safeDuration.coerceAtLeast(0f),
            activeColor = foreground.copy(alpha = 0.88f),
            inactiveColor = foreground.copy(alpha = 0.32f),
            trackHeight = 9.dp,
            onValueChange = { onSliderValueChange(it.toLong()) },
            onValueChangeFinished = onSliderValueChangeFinished,
            enabled = safeDuration > 0f,
            modifier = Modifier.fillMaxWidth(),
        )

        Box(
            modifier =
                Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
        ) {
            Text(
                text = makeTimeString(sliderPosition ?: position),
                style = MaterialTheme.typography.labelMedium,
                color = foreground,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.align(Alignment.CenterStart),
            )

            if (currentFormat != null) {
                V8QualityChip(
                    currentFormat = currentFormat,
                    foreground = foreground,
                    modifier = Modifier.align(Alignment.Center),
                )
            }

            Text(
                text = if (duration != C.TIME_UNSET) makeTimeString(duration) else "",
                style = MaterialTheme.typography.labelMedium,
                color = foreground,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.align(Alignment.CenterEnd),
            )
        }
    }
}

@Composable
private fun V8QualityChip(
    currentFormat: FormatEntity,
    foreground: Color,
    modifier: Modifier = Modifier,
) {
    val label =
        remember(currentFormat.mimeType, currentFormat.codecs) {
            currentFormat.codecLabel()
        }

    Surface(
        shape = RoundedCornerShape(6.dp),
        color = foreground.copy(alpha = 0.1f),
        border =
            androidx.compose.foundation.BorderStroke(
                width = 1.dp,
                color = foreground.copy(alpha = 0.13f),
            ),
        modifier = modifier,
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp),
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
        ) {
            Icon(
                painter = painterResource(R.drawable.graphic_eq),
                contentDescription = null,
                tint = foreground.copy(alpha = 0.72f),
                modifier = Modifier.size(15.dp),
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = foreground.copy(alpha = 0.72f),
                maxLines = 1,
            )
        }
    }
}

@Composable
internal fun V8TransportControls(
    playbackState: Int,
    isPlaying: Boolean,
    isLoading: Boolean,
    canSkipPrevious: Boolean,
    canSkipNext: Boolean,
    foreground: Color,
    onPreviousClick: () -> Unit,
    onPlayPauseClick: () -> Unit,
    onNextClick: () -> Unit,
) {
    val haptic = LocalHapticFeedback.current

    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceEvenly,
    ) {
        V8TransportButton(
            iconRes = R.drawable.skip_previous,
            contentDescription = stringResource(R.string.widget_previous),
            foreground = foreground,
            enabled = canSkipPrevious,
            touchSize = 64.dp,
            iconSize = 44.dp,
            onClick = {
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                onPreviousClick()
            },
        )

        Surface(
            onClick = {
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                onPlayPauseClick()
            },
            shape = CircleShape,
            color = Color.Transparent,
            modifier = Modifier.size(72.dp),
        ) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center,
            ) {
                if (isLoading) {
                    CircularWavyProgressIndicator(
                        modifier = Modifier.size(44.dp),
                        color = foreground,
                    )
                } else {
                    Icon(
                        painter =
                            painterResource(
                                when {
                                    playbackState == STATE_ENDED -> R.drawable.replay
                                    isPlaying -> R.drawable.pause
                                    else -> R.drawable.play
                                },
                            ),
                        contentDescription =
                            if (isPlaying) {
                                stringResource(R.string.widget_pause)
                            } else {
                                stringResource(R.string.play)
                            },
                        tint = foreground,
                        modifier = Modifier.size(52.dp),
                    )
                }
            }
        }

        V8TransportButton(
            iconRes = R.drawable.skip_next,
            contentDescription = stringResource(R.string.next),
            foreground = foreground,
            enabled = canSkipNext,
            touchSize = 64.dp,
            iconSize = 44.dp,
            onClick = {
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                onNextClick()
            },
        )
    }
}

@Composable
private fun V8TransportButton(
    iconRes: Int,
    contentDescription: String,
    foreground: Color,
    enabled: Boolean,
    touchSize: androidx.compose.ui.unit.Dp,
    iconSize: androidx.compose.ui.unit.Dp,
    onClick: () -> Unit,
) {
    Surface(
        onClick = onClick,
        enabled = enabled,
        shape = CircleShape,
        color = Color.Transparent,
        modifier = Modifier.size(touchSize),
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                painter = painterResource(iconRes),
                contentDescription = contentDescription,
                tint = foreground.copy(alpha = if (enabled) 1f else 0.4f),
                modifier = Modifier.size(iconSize),
            )
        }
    }
}

@Composable
private fun V8VolumeControls(
    volume: Float,
    foreground: Color,
    secondaryForeground: Color,
    onVolumeChange: (Float) -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            painter = painterResource(R.drawable.volume_off),
            contentDescription = stringResource(R.string.minimum_volume),
            tint = secondaryForeground,
            modifier = Modifier.size(22.dp),
        )
        V8FlatSlider(
            value = volume.coerceIn(0f, 1f),
            valueRange = 0f..1f,
            activeColor = foreground.copy(alpha = 0.86f),
            inactiveColor = foreground.copy(alpha = 0.24f),
            trackHeight = 8.dp,
            onValueChange = { onVolumeChange(it.coerceIn(0f, 1f)) },
            onValueChangeFinished = {},
            modifier =
                Modifier
                    .weight(1f)
                    .padding(horizontal = 18.dp),
        )
        Icon(
            painter = painterResource(R.drawable.volume_up),
            contentDescription = stringResource(R.string.maximum_volume),
            tint = secondaryForeground,
            modifier = Modifier.size(24.dp),
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun V8FlatSlider(
    value: Float,
    valueRange: ClosedFloatingPointRange<Float>,
    activeColor: Color,
    inactiveColor: Color,
    trackHeight: androidx.compose.ui.unit.Dp,
    onValueChange: (Float) -> Unit,
    onValueChangeFinished: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
) {
    val safeEnd = valueRange.endInclusive.coerceAtLeast(valueRange.start + 1f)
    val safeRange = valueRange.start..safeEnd
    val colors =
        SliderDefaults.colors(
            activeTrackColor = activeColor,
            activeTickColor = activeColor,
            thumbColor = Color.Transparent,
            inactiveTrackColor = inactiveColor,
        )
    val sliderState =
        rememberControlledSliderState(
            value = value.coerceIn(safeRange),
            valueRange = safeRange,
        )

    Slider(
        state = sliderState,
        onValueChange = { updated ->
            sliderState.value = updated
            onValueChange(updated)
        },
        onValueChangeFinished = onValueChangeFinished,
        enabled = enabled,
        colors = colors,
        thumb = { Spacer(modifier = Modifier.size(0.dp)) },
        track = { sliderState ->
            PlayerSliderTrack(
                sliderState = sliderState,
                colors = colors,
                trackHeight = trackHeight,
            )
        },
        modifier = modifier.height(30.dp),
    )
}

@Composable
fun V9PlayerContent(
    mediaMetadata: MediaMetadata,
    playbackState: Int,
    isPlaying: Boolean,
    isLoading: Boolean,
    canSkipPrevious: Boolean,
    canSkipNext: Boolean,
    sliderPosition: Long?,
    position: Long,
    duration: Long,
    playerConnection: PlayerConnection,
    navController: NavController,
    state: BottomSheetState,
    textBackgroundColor: Color,
    textButtonColor: Color,
    iconButtonColor: Color,
    canvasSource: CanvasSource?,
    canvasPrimaryUrl: String?,
    canvasFallbackUrl: String?,
    onCollapseClick: () -> Unit,
    onQueueClick: () -> Unit,
    onLyricsClick: () -> Unit,
    onSliderValueChange: (Long) -> Unit,
    onSliderValueChangeFinished: () -> Unit,
    modifier: Modifier = Modifier,
    landscape: Boolean = false,
    gradientColors: List<Color> = emptyList(),
) {
    val baseArtworkUrl = mediaMetadata.thumbnailUrl?.highRes()
    val thumbnailSwapState =
        rememberThumbnailSwapState(
            videoId = mediaMetadata.id,
            ytmUrl = baseArtworkUrl,
            lowDataMode = rememberLowDataModeActive(),
            isMusicVideo = mediaMetadata.isMusicVideo,
        )
    val artworkUrl = thumbnailSwapState.displayUrl
    val titleActions = rememberPlayerTitleActions(mediaMetadata, navController, state)
    val onTitleClick = titleActions.onTitleClick
    val onArtistClick = titleActions.onArtistClick
    val onPlayPauseClick = {
        if (playbackState == STATE_ENDED) {
            playerConnection.player.seekTo(0, 0)
            playerConnection.player.playWhenReady = true
        } else {
            playerConnection.player.togglePlayPause()
        }
    }

    val shuffleModeEnabled by playerConnection.shuffleModeEnabled.collectAsState()
    val repeatMode by playerConnection.repeatMode.collectAsState()
    val currentSong by playerConnection.currentSong.collectAsState(initial = null)
    val liked = currentSong?.song?.liked == true
    val onToggleLike = playerConnection::toggleLike
    val menuState = LocalMenuState.current

    val onShuffleClick = {
        playerConnection.player.shuffleModeEnabled = !shuffleModeEnabled
    }
    val onRepeatClick = {
        playerConnection.player.repeatMode =
            when (repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                Player.REPEAT_MODE_ONE -> Player.REPEAT_MODE_OFF
                else -> Player.REPEAT_MODE_OFF
            }
    }
    val onMenuClick = {
        menuState.show {
            PlayerMenu(
                mediaMetadata = mediaMetadata,
                navController = navController,
                playerBottomSheetState = state,
                onShowDetailsDialog = {},
                onDismiss = menuState::dismiss,
            )
        }
    }

    if (landscape) {
        V9LandscapeContent(
            title = mediaMetadata.title,
            explicit = mediaMetadata.explicit,
            artists = mediaMetadata.artists,
            artworkUrl = artworkUrl,
            canvasSource = canvasSource,
            canvasPrimaryUrl = canvasPrimaryUrl,
            canvasFallbackUrl = canvasFallbackUrl,
            playbackState = playbackState,
            isPlaying = isPlaying,
            isLoading = isLoading,
            canSkipPrevious = canSkipPrevious,
            canSkipNext = canSkipNext,
            sliderPosition = sliderPosition,
            position = position,
            duration = duration,
            textBackgroundColor = textBackgroundColor,
            textButtonColor = textButtonColor,
            iconButtonColor = iconButtonColor,
            onCollapseClick = onCollapseClick,
            onQueueClick = onQueueClick,
            onLyricsClick = onLyricsClick,
            onTitleClick = onTitleClick,
            onArtistClick = onArtistClick,
            onPreviousClick = playerConnection::seekToPrevious,
            onPlayPauseClick = onPlayPauseClick,
            onNextClick = playerConnection::seekToNext,
            onSliderValueChange = onSliderValueChange,
            onSliderValueChangeFinished = onSliderValueChangeFinished,
            shuffleModeEnabled = shuffleModeEnabled,
            repeatMode = repeatMode,
            onShuffleClick = onShuffleClick,
            onRepeatClick = onRepeatClick,
            onMenuClick = onMenuClick,
            modifier = modifier,
        )
    } else {
        V9PortraitContent(
            title = mediaMetadata.title,
            explicit = mediaMetadata.explicit,
            artists = mediaMetadata.artists,
            artworkUrl = artworkUrl,
            canvasSource = canvasSource,
            canvasPrimaryUrl = canvasPrimaryUrl,
            canvasFallbackUrl = canvasFallbackUrl,
            playbackState = playbackState,
            isPlaying = isPlaying,
            isLoading = isLoading,
            canSkipPrevious = canSkipPrevious,
            canSkipNext = canSkipNext,
            sliderPosition = sliderPosition,
            position = position,
            duration = duration,
            textBackgroundColor = textBackgroundColor,
            textButtonColor = textButtonColor,
            iconButtonColor = iconButtonColor,
            onCollapseClick = onCollapseClick,
            onQueueClick = onQueueClick,
            onLyricsClick = onLyricsClick,
            onTitleClick = onTitleClick,
            onArtistClick = onArtistClick,
            onPreviousClick = playerConnection::seekToPrevious,
            onPlayPauseClick = onPlayPauseClick,
            onNextClick = playerConnection::seekToNext,
            onSliderValueChange = onSliderValueChange,
            onSliderValueChangeFinished = onSliderValueChangeFinished,
            liked = liked,
            onToggleLike = onToggleLike,
            modifier = modifier,
        )
    }
}

@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
private fun V9PortraitContent(
    title: String,
    explicit: Boolean,
    artists: List<MediaMetadata.Artist>,
    artworkUrl: String?,
    canvasSource: CanvasSource?,
    canvasPrimaryUrl: String?,
    canvasFallbackUrl: String?,
    playbackState: Int,
    isPlaying: Boolean,
    isLoading: Boolean,
    canSkipPrevious: Boolean,
    canSkipNext: Boolean,
    sliderPosition: Long?,
    position: Long,
    duration: Long,
    textBackgroundColor: Color,
    textButtonColor: Color,
    iconButtonColor: Color,
    onCollapseClick: () -> Unit,
    onQueueClick: () -> Unit,
    onLyricsClick: () -> Unit,
    onPreviousClick: () -> Unit,
    onPlayPauseClick: () -> Unit,
    onNextClick: () -> Unit,
    onSliderValueChange: (Long) -> Unit,
    onSliderValueChangeFinished: () -> Unit,
    onTitleClick: () -> Unit,
    onArtistClick: (artistId: String) -> Unit,
    liked: Boolean,
    onToggleLike: () -> Unit,
    modifier: Modifier = Modifier,
) {
    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val horizontalPadding = if (maxWidth < 380.dp) 16.dp else 20.dp
        val compactHeight = maxHeight < 760.dp
        val veryCompactHeight = maxHeight < 700.dp

        val headerGap =
            when {
                veryCompactHeight -> 14.dp
                compactHeight -> 18.dp
                else -> 26.dp
            }

        Column(
            modifier =
                Modifier
                    .fillMaxSize()
                    .padding(horizontal = horizontalPadding),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.height(if (compactHeight) 8.dp else 14.dp))

            // TOP HEADER BAR
            V9Header(
                textColor = textBackgroundColor,
                containerColor = textButtonColor.copy(alpha = 0.16f),
                iconColor = textBackgroundColor,
                onCollapseClick = onCollapseClick,
                onLyricsClick = onLyricsClick,
                onQueueClick = onQueueClick,
            )

            Spacer(Modifier.height(headerGap))

            // ALBUM COVER (Large 1:1 squircle)
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center,
            ) {
                V9Artwork(
                    artworkUrl = artworkUrl,
                    canvasSource = canvasSource,
                    canvasPrimaryUrl = canvasPrimaryUrl,
                    canvasFallbackUrl = canvasFallbackUrl,
                    isPlaying = isPlaying,
                    placeholderColor = textBackgroundColor.copy(alpha = 0.08f),
                    modifier = Modifier.aspectRatio(1f)
                )
            }

            Spacer(Modifier.height(headerGap))

            // METADATA (Title & Artist on left, Heart button on right)
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    PlayerTitleText(
                        title = title,
                        explicit = explicit,
                        color = textBackgroundColor,
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Start,
                        modifier = Modifier
                            .fillMaxWidth()
                            .basicMarquee()
                            .clickable(
                                indication = tvFocusIndicationOrNull(),
                                interactionSource = remember { MutableInteractionSource() },
                                onClick = onTitleClick,
                            ),
                    )
                    ClickableArtists(
                        artists = artists,
                        onArtistClick = onArtistClick,
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.SemiBold),
                        color = textBackgroundColor.copy(alpha = 0.72f),
                        textAlign = TextAlign.Start,
                        modifier = Modifier
                            .fillMaxWidth()
                            .basicMarquee(),
                    )
                }

                Spacer(Modifier.width(16.dp))

                // Heart / Like Action Button (replaces lyrics button)
                IconButton(
                    onClick = onToggleLike,
                    modifier = Modifier.size(48.dp)
                ) {
                    Icon(
                        painter = painterResource(if (liked) R.drawable.favorite else R.drawable.favorite_border),
                        contentDescription = stringResource(if (liked) R.string.action_remove_like else R.string.action_like),
                        tint = if (liked) MaterialTheme.colorScheme.primary else textBackgroundColor,
                        modifier = Modifier.size(32.dp)
                    )
                }
            }

            Spacer(Modifier.height(headerGap))

            // PLAYBACK PROGRESS WAVY SLIDER
            val (smoothProgressFraction, displayedPosition) = rememberSmoothProgress(
                isPlayingProvider = { isPlaying },
                currentPositionProvider = { sliderPosition ?: position },
                totalDuration = duration.coerceAtLeast(0L),
                isVisible = true
            )

            Column(modifier = Modifier.fillMaxWidth()) {
                WavySliderExpressive(
                    value = { smoothProgressFraction.value },
                    onValueChange = { fraction ->
                        onSliderValueChange((fraction * duration.coerceAtLeast(0L)).toLong())
                    },
                    onValueCommit = { fraction ->
                        onSliderValueChangeFinished()
                    },
                    enabled = duration > 0L,
                    activeTrackColor = textBackgroundColor,
                    inactiveTrackColor = textBackgroundColor.copy(alpha = 0.24f),
                    thumbColor = textBackgroundColor,
                    isPlaying = isPlaying,
                    isVisible = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(36.dp),
                )

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp)
                ) {
                    Text(
                        text = makeTimeString(sliderPosition ?: displayedPosition.value),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = textBackgroundColor.copy(alpha = 0.78f),
                        maxLines = 1,
                        modifier = Modifier.align(Alignment.CenterStart)
                    )

                    Text(
                        text = if (duration != C.TIME_UNSET) makeTimeString(duration) else "",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = textBackgroundColor.copy(alpha = 0.78f),
                        maxLines = 1,
                        modifier = Modifier.align(Alignment.CenterEnd)
                    )
                }
            }

            Spacer(Modifier.height(if (compactHeight) 16.dp else 24.dp))

            // TRANSPORT CONTROLS (Material Extended animated weight style, placed at the bottom)
            val motionScheme = remember { MotionScheme.standard() }
            val controlSpatialSpec = remember { motionScheme.fastSpatialSpec<Float>() }
            V9AnimatedPlaybackControls(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                isPlayingProvider = { isPlaying },
                onPrevious = onPreviousClick,
                onPlayPause = onPlayPauseClick,
                onNext = onNextClick,
                height = 80.dp,
                pressAnimationSpec = controlSpatialSpec,
                releaseDelay = 220L,
                colorOtherButtons = textBackgroundColor.copy(alpha = 0.08f),
                colorPlayPause = textBackgroundColor,
                tintPlayPauseIcon = if ((textBackgroundColor.red + textBackgroundColor.green + textBackgroundColor.blue) > 1.5f) Color.Black else Color.White,
                tintOtherIcons = textBackgroundColor,
            )

            Spacer(Modifier.height(if (compactHeight) 16.dp else 24.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
private fun V9LandscapeContent(
    title: String,
    explicit: Boolean,
    artists: List<MediaMetadata.Artist>,
    artworkUrl: String?,
    canvasSource: CanvasSource?,
    canvasPrimaryUrl: String?,
    canvasFallbackUrl: String?,
    playbackState: Int,
    isPlaying: Boolean,
    isLoading: Boolean,
    canSkipPrevious: Boolean,
    canSkipNext: Boolean,
    sliderPosition: Long?,
    position: Long,
    duration: Long,
    textBackgroundColor: Color,
    textButtonColor: Color,
    iconButtonColor: Color,
    onCollapseClick: () -> Unit,
    onQueueClick: () -> Unit,
    onLyricsClick: () -> Unit,
    onPreviousClick: () -> Unit,
    onPlayPauseClick: () -> Unit,
    onNextClick: () -> Unit,
    onSliderValueChange: (Long) -> Unit,
    onSliderValueChangeFinished: () -> Unit,
    onTitleClick: () -> Unit,
    onArtistClick: (artistId: String) -> Unit,
    shuffleModeEnabled: Boolean,
    repeatMode: Int,
    onShuffleClick: () -> Unit,
    onRepeatClick: () -> Unit,
    onMenuClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val artworkSize =
            (maxHeight - 16.dp)
                .coerceAtMost(maxWidth * 0.4f)
                .coerceAtLeast(0.dp)

        Row(
            modifier =
                Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(24.dp),
        ) {
            V9Artwork(
                artworkUrl = artworkUrl,
                canvasSource = canvasSource,
                canvasPrimaryUrl = canvasPrimaryUrl,
                canvasFallbackUrl = canvasFallbackUrl,
                isPlaying = isPlaying,
                size = artworkSize,
                placeholderColor = textBackgroundColor.copy(alpha = 0.08f),
            )

            LandscapePlayerControls(
                modifier = Modifier.weight(1f).fillMaxHeight(),
                playbackContent = {
                    val motionScheme = remember { MotionScheme.standard() }
                    val controlSpatialSpec = remember { motionScheme.fastSpatialSpec<Float>() }
                    V9AnimatedPlaybackControls(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        isPlayingProvider = { isPlaying },
                        onPrevious = onPreviousClick,
                        onPlayPause = onPlayPauseClick,
                        onNext = onNextClick,
                        height = 64.dp,
                        pressAnimationSpec = controlSpatialSpec,
                        releaseDelay = 220L,
                        colorOtherButtons = textBackgroundColor.copy(alpha = 0.08f),
                        colorPlayPause = textBackgroundColor,
                        tintPlayPauseIcon = if ((textBackgroundColor.red + textBackgroundColor.green + textBackgroundColor.blue) > 1.5f) Color.Black else Color.White,
                        tintOtherIcons = textBackgroundColor,
                    )

                    Spacer(Modifier.height(4.dp))
                },
            ) {
                V9Header(
                    textColor = textBackgroundColor,
                    containerColor = textButtonColor.copy(alpha = 0.16f),
                    iconColor = textBackgroundColor,
                    onCollapseClick = onCollapseClick,
                    onLyricsClick = onLyricsClick,
                    onQueueClick = onQueueClick,
                )

                Spacer(Modifier.height(4.dp))

                V9Metadata(
                    title = title,
                    explicit = explicit,
                    artists = artists,
                    textColor = textBackgroundColor,
                    onTitleClick = onTitleClick,
                    onArtistClick = onArtistClick,
                )

                Spacer(Modifier.height(4.dp))

                V9BottomToggleRow(
                    shuffleModeEnabled = shuffleModeEnabled,
                    repeatMode = repeatMode,
                    onShuffleClick = onShuffleClick,
                    onRepeatClick = onRepeatClick,
                    onMenuClick = onMenuClick,
                    activeColor = textBackgroundColor,
                    inactiveColor = textBackgroundColor.copy(alpha = 0.24f),
                    textColor = textBackgroundColor,
                    containerColor = textBackgroundColor.copy(alpha = 0.08f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp),
                )
                V9PlaybackProgress(
                    sliderPosition = sliderPosition,
                    position = position,
                    duration = duration,
                    isPlaying = isPlaying,
                    activeColor = textBackgroundColor,
                    inactiveColor = textBackgroundColor.copy(alpha = 0.24f),
                    textColor = textBackgroundColor,
                    onSliderValueChange = onSliderValueChange,
                    onSliderValueChangeFinished = onSliderValueChangeFinished,
                )

                Spacer(Modifier.height(4.dp))

            }
        }
    }
}

@Composable
private fun V9Header(
    textColor: Color,
    containerColor: Color,
    iconColor: Color,
    onCollapseClick: () -> Unit,
    onLyricsClick: () -> Unit,
    onQueueClick: () -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        V9HeaderButton(
            iconRes = R.drawable.expand_more,
            contentDescription = null,
            containerColor = containerColor,
            iconColor = iconColor,
            shape = CircleShape,
            onClick = onCollapseClick,
        )

        Text(
            text = stringResource(R.string.now_playing),
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.SemiBold,
            color = textColor,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier =
                Modifier
                    .weight(1f)
                    .basicMarquee(),
        )

        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            V9HeaderButton(
                iconRes = R.drawable.lyrics,
                contentDescription = stringResource(R.string.lyrics),
                containerColor = containerColor,
                iconColor = iconColor,
                shape = RoundedCornerShape(22.dp),
                onClick = onLyricsClick,
            )
            V9HeaderButton(
                iconRes = R.drawable.queue_music,
                contentDescription = stringResource(R.string.queue),
                containerColor = containerColor,
                iconColor = iconColor,
                shape = RoundedCornerShape(22.dp),
                onClick = onQueueClick,
            )
        }
    }
}

@Composable
private fun V9HeaderButton(
    iconRes: Int,
    contentDescription: String?,
    containerColor: Color,
    iconColor: Color,
    shape: androidx.compose.ui.graphics.Shape,
    onClick: () -> Unit,
) {
    Surface(
        onClick = onClick,
        shape = shape,
        color = containerColor,
        modifier = Modifier.size(56.dp),
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                painter = painterResource(iconRes),
                contentDescription = contentDescription,
                tint = iconColor,
                modifier = Modifier.size(26.dp),
            )
        }
    }
}

@Composable
private fun V9Artwork(
    artworkUrl: String?,
    canvasSource: CanvasSource?,
    canvasPrimaryUrl: String?,
    canvasFallbackUrl: String?,
    isPlaying: Boolean,
    placeholderColor: Color,
    modifier: Modifier = Modifier,
    size: Dp? = null,
) {
    val artworkRequest = rememberOfflineArtworkImageRequest(artworkUrl)
    val baseModifier = if (size != null) Modifier.size(size) else Modifier
    Box(
        modifier =
            modifier
                .then(baseModifier)
                .clip(RoundedCornerShape(36.dp))
                .background(placeholderColor),
    ) {
        AsyncImage(
            model = artworkRequest,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize(),
        )

        if (!canvasPrimaryUrl.isNullOrBlank() || !canvasFallbackUrl.isNullOrBlank()) {
            CanvasArtworkPlayer(
                source = canvasSource,
                primaryUrl = canvasPrimaryUrl,
                fallbackUrl = canvasFallbackUrl,
                isPlaying = isPlaying,
                resizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM,
                modifier = Modifier.fillMaxSize(),
            )
        }
    }
}

@Composable
private fun V9Metadata(
    title: String,
    explicit: Boolean,
    artists: List<MediaMetadata.Artist>,
    textColor: Color,
    onTitleClick: () -> Unit,
    onArtistClick: (artistId: String) -> Unit,
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        PlayerTitleText(
            title = title,
            explicit = explicit,
            color = textColor,
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
            modifier =
                Modifier
                    .fillMaxWidth()
                    .basicMarquee()
                    .clickable(
                        indication = tvFocusIndicationOrNull(),
                        interactionSource = remember { MutableInteractionSource() },
                        onClick = onTitleClick,
                    ),
        )
        ClickableArtists(
            artists = artists,
            onArtistClick = onArtistClick,
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.SemiBold),
            color = textColor.copy(alpha = 0.72f),
            textAlign = TextAlign.Center,
            modifier =
                Modifier
                    .fillMaxWidth()
                    .basicMarquee(),
        )
    }
}

@Composable
private fun V9PlaybackProgress(
    sliderPosition: Long?,
    position: Long,
    duration: Long,
    isPlaying: Boolean,
    activeColor: Color,
    inactiveColor: Color,
    textColor: Color,
    onSliderValueChange: (Long) -> Unit,
    onSliderValueChangeFinished: () -> Unit,
) {
    val (smoothProgressFraction, displayedPosition) = rememberSmoothProgress(
        isPlayingProvider = { isPlaying },
        currentPositionProvider = { sliderPosition ?: position },
        totalDuration = duration.coerceAtLeast(0L),
        isVisible = true
    )

    Column(modifier = Modifier.fillMaxWidth()) {
        WavySliderExpressive(
            value = { smoothProgressFraction.value },
            onValueChange = { fraction ->
                onSliderValueChange((fraction * duration.coerceAtLeast(0L)).toLong())
            },
            onValueCommit = { fraction ->
                onSliderValueChangeFinished()
            },
            enabled = duration > 0L,
            activeTrackColor = activeColor,
            inactiveTrackColor = inactiveColor,
            thumbColor = activeColor,
            isPlaying = isPlaying,
            isVisible = true,
            modifier = Modifier
                .fillMaxWidth()
                .height(36.dp),
        )

        Row(
            modifier =
                Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = makeTimeString(sliderPosition ?: displayedPosition.value),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = textColor.copy(alpha = 0.78f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = if (duration != C.TIME_UNSET) makeTimeString(duration) else "",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = textColor.copy(alpha = 0.78f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}


@Composable
private fun V9BottomToggleRow(
    shuffleModeEnabled: Boolean,
    repeatMode: Int,
    onShuffleClick: () -> Unit,
    onRepeatClick: () -> Unit,
    onMenuClick: () -> Unit,
    activeColor: Color,
    inactiveColor: Color,
    textColor: Color,
    containerColor: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier.background(
            color = containerColor,
            shape = RoundedCornerShape(60.dp)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp)
                .background(Color.Transparent),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val commonModifier = Modifier.weight(1f)

            ToggleSegmentButton(
                modifier = commonModifier,
                active = shuffleModeEnabled,
                activeColor = activeColor,
                activeCornerRadius = 60.dp,
                activeContentColor = MaterialTheme.colorScheme.onPrimary,
                inactiveColor = inactiveColor,
                inactiveContentColor = textColor.copy(alpha = 0.6f),
                onClick = onShuffleClick,
                iconId = R.drawable.shuffle,
                contentDesc = stringResource(R.string.shuffle)
            )

            val repeatActive = repeatMode != Player.REPEAT_MODE_OFF
            val repeatIcon = when (repeatMode) {
                Player.REPEAT_MODE_ONE -> R.drawable.repeat_one
                Player.REPEAT_MODE_ALL -> R.drawable.repeat
                else -> R.drawable.repeat
            }
            ToggleSegmentButton(
                modifier = commonModifier,
                active = repeatActive,
                activeColor = activeColor,
                activeCornerRadius = 60.dp,
                activeContentColor = MaterialTheme.colorScheme.onPrimary,
                inactiveColor = inactiveColor,
                inactiveContentColor = textColor.copy(alpha = 0.6f),
                onClick = onRepeatClick,
                iconId = repeatIcon,
                contentDesc = stringResource(R.string.repeat_mode_all)
            )

            ToggleSegmentButton(
                modifier = commonModifier,
                active = false,
                activeColor = activeColor,
                activeCornerRadius = 60.dp,
                activeContentColor = MaterialTheme.colorScheme.onPrimary,
                inactiveColor = inactiveColor,
                inactiveContentColor = textColor.copy(alpha = 0.6f),
                onClick = onMenuClick,
                iconId = R.drawable.more_vert,
                contentDesc = stringResource(R.string.more)
            )
        }
    }
}

@Composable
fun PlayerBackground(
    playerBackground: PlayerBackgroundStyle,
    mediaMetadata: MediaMetadata?,
    gradientColors: List<Color>,
    disableBlur: Boolean,
    blurRadius: Float,
    playerCustomImageUri: String,
    playerCustomBlur: Float,
    playerCustomContrast: Float,
    playerCustomBrightness: Float,
) {
    val effectiveBlurRadius = blurRadius.coerceIn(0f, PlayerBackgroundMaxBlurRadius)
    val shouldApplyBlur = !disableBlur && effectiveBlurRadius > 0f

    val backgroundSwapState =
        rememberThumbnailSwapState(
            videoId = mediaMetadata?.id,
            ytmUrl = mediaMetadata?.thumbnailUrl,
            lowDataMode = rememberLowDataModeActive(),
            isMusicVideo = mediaMetadata?.isMusicVideo ?: false,
        )
    val backgroundThumbnailUrl = backgroundSwapState.displayUrl
    val styleAppliesBlur =
        effectiveBlurRadius > 0f && effectiveBlurRadius >= 0.5f
    Box(modifier = Modifier.fillMaxSize()) {
        when (playerBackground) {
            PlayerBackgroundStyle.BLUR -> {
                AnimatedContent(
                    targetState = backgroundThumbnailUrl,
                    transitionSpec = {
                        fadeIn(tween(1000)) togetherWith fadeOut(tween(1000))
                    },
                    label = "",
                ) { thumbnailUrl ->
                    if (thumbnailUrl != null) {
                        Box(modifier = Modifier.fillMaxSize()) {
                            AsyncImage(
                                model = thumbnailUrl.highRes(),
                                contentDescription = "Blurred background",
                                contentScale = ContentScale.Crop,
                                modifier =
                                    Modifier.fillMaxSize().let {
                                        if (styleAppliesBlur) it.blur(radius = effectiveBlurRadius.dp) else it
                                    },
                            )
                            val overlayStops = PlayerBackgroundColorUtils.buildBlurOverlayStops(gradientColors)
                            Box(
                                modifier =
                                    Modifier
                                        .fillMaxSize()
                                        .background(Brush.verticalGradient(colorStops = overlayStops)),
                            )
                            Box(
                                modifier =
                                    Modifier
                                        .fillMaxSize()
                                        .background(Color.Black.copy(alpha = 0.08f)),
                            )
                        }
                    }
                }
            }

            PlayerBackgroundStyle.GRADIENT -> {
                AnimatedContent(
                    targetState = gradientColors,
                    transitionSpec = {
                        fadeIn(tween(1000)) togetherWith fadeOut(tween(1000))
                    },
                    label = "",
                ) { colors ->
                    if (colors.isNotEmpty()) {
                        Box(modifier = Modifier.fillMaxSize()) {
                            val gradientColorStops =
                                if (colors.size >= 3) {
                                    arrayOf(
                                        0.0f to colors[0].copy(alpha = 0.92f), // Top: primary vibrant color
                                        0.5f to colors[1].copy(alpha = 0.75f), // Middle: darker variant
                                        1.0f to colors[2].copy(alpha = 0.65f), // Bottom: black-ish
                                    )
                                } else {
                                    arrayOf(
                                        0.0f to colors[0].copy(alpha = 0.9f), // Top: primary color
                                        0.6f to colors[0].copy(alpha = 0.55f), // Middle: faded variant
                                        1.0f to Color.Black.copy(alpha = 0.7f), // Bottom: black
                                    )
                                }
                            Box(
                                modifier =
                                    Modifier
                                        .fillMaxSize()
                                        .background(Brush.verticalGradient(colorStops = gradientColorStops)),
                            )
                            // Keep a gentle dark overlay to ensure text contrast on bright artwork
                            Box(
                                modifier =
                                    Modifier
                                        .fillMaxSize()
                                        .background(Color.Black.copy(alpha = 0.18f)),
                            )
                        }
                    }
                }
            }

            PlayerBackgroundStyle.COLORING -> {
                AnimatedContent(
                    targetState = gradientColors,
                    transitionSpec = {
                        fadeIn(tween(1000)) togetherWith fadeOut(tween(1000))
                    },
                    label = "",
                ) { colors ->
                    if (colors.isNotEmpty()) {
                        val baseColor = PlayerBackgroundColorUtils.ensureComfortableColor(colors.first())
                        val gradientStops = PlayerBackgroundColorUtils.buildColoringStops(baseColor)
                        Box(modifier = Modifier.fillMaxSize()) {
                            Box(modifier = Modifier.fillMaxSize().background(baseColor))
                            Box(
                                modifier =
                                    Modifier
                                        .fillMaxSize()
                                        .background(Brush.verticalGradient(colorStops = gradientStops)),
                            )
                            Box(
                                modifier =
                                    Modifier
                                        .fillMaxSize()
                                        .background(Color.Black.copy(alpha = 0.25f)),
                            )
                        }
                    }
                }
            }

            PlayerBackgroundStyle.BLUR_GRADIENT -> {
                AnimatedContent(
                    targetState = backgroundThumbnailUrl,
                    transitionSpec = {
                        fadeIn(tween(1000)) togetherWith fadeOut(tween(1000))
                    },
                    label = "",
                ) { thumbnailUrl ->
                    if (thumbnailUrl != null) {
                        Box(modifier = Modifier.fillMaxSize()) {
                            AsyncImage(
                                model = thumbnailUrl.highRes(),
                                contentDescription = "Blurred background",
                                contentScale = ContentScale.Crop,
                                modifier =
                                    Modifier.fillMaxSize().let {
                                        if (styleAppliesBlur) it.blur(radius = effectiveBlurRadius.dp) else it
                                    },
                            )
                            val gradientColorStops =
                                PlayerBackgroundColorUtils.buildBlurGradientStops(gradientColors)
                            Box(
                                modifier =
                                    Modifier
                                        .fillMaxSize()
                                        .background(Brush.verticalGradient(colorStops = gradientColorStops)),
                            )
                            Box(
                                modifier =
                                    Modifier
                                        .fillMaxSize()
                                        .background(Color.Black.copy(alpha = 0.05f)),
                            )
                        }
                    }
                }
            }

            PlayerBackgroundStyle.CUSTOM -> {
                AnimatedContent(
                    targetState = playerCustomImageUri,
                    transitionSpec = {
                        fadeIn(tween(1000)) togetherWith fadeOut(tween(1000))
                    },
                    label = "",
                ) { uri ->
                    if (uri.isNotBlank()) {
                        Box(modifier = Modifier.fillMaxSize()) {
                            val blurPx = playerCustomBlur
                            val contrastVal = playerCustomContrast
                            val brightnessVal = playerCustomBrightness

                            val t = (1f - contrastVal) * 128f + (brightnessVal - 1f) * 255f
                            val matrix =
                                floatArrayOf(
                                    contrastVal,
                                    0f,
                                    0f,
                                    0f,
                                    t,
                                    0f,
                                    contrastVal,
                                    0f,
                                    0f,
                                    t,
                                    0f,
                                    0f,
                                    contrastVal,
                                    0f,
                                    t,
                                    0f,
                                    0f,
                                    0f,
                                    1f,
                                    0f,
                                )

                            val cm = ColorMatrix(matrix)

                            AsyncImage(
                                model = Uri.parse(uri),
                                contentDescription = "Custom background",
                                contentScale = ContentScale.Crop,
                                modifier =
                                    Modifier.fillMaxSize().let {
                                        if (disableBlur) it else it.blur(radius = blurPx.dp)
                                    },
                                colorFilter = ColorFilter.colorMatrix(cm),
                            )
                            Box(
                                modifier =
                                    Modifier
                                        .fillMaxSize()
                                        .background(Color.Black.copy(alpha = 0.4f)),
                            )
                        }
                    }
                }
            }

            PlayerBackgroundStyle.GLOW -> {
                AnimatedContent(
                    targetState = gradientColors,
                    transitionSpec = {
                        fadeIn(tween(1200)) togetherWith fadeOut(tween(1200))
                    },
                    label = "",
                ) { colors ->
                    if (colors.isNotEmpty()) {
                        Box(
                            modifier =
                                Modifier
                                    .fillMaxSize()
                                    .drawWithCache {
                                        val width = size.width
                                        val height = size.height

                                        // Use a dark base, but the gradients will cover most of it
                                        val baseColor = Color(0xFF050505)

                                        // Extract up to 6 colors
                                        val color1 = colors.getOrElse(0) { Color.DarkGray }
                                        val color2 = colors.getOrElse(1) { color1 }
                                        val color3 = colors.getOrElse(2) { color2 }
                                        val color4 = colors.getOrElse(3) { color1 }
                                        val color5 = colors.getOrElse(4) { color2 }
                                        val color6 = colors.getOrElse(5) { color3 }

                                        // Top-Left Large Glow (Primary)
                                        val brush1 =
                                            Brush.radialGradient(
                                                colors =
                                                    listOf(
                                                        color1.copy(alpha = 0.8f),
                                                        color1.copy(alpha = 0.5f),
                                                        Color.Transparent,
                                                    ),
                                                center = Offset(width * 0.2f, height * 0.25f),
                                                radius = width * 1.2f,
                                            )

                                        // Bottom-Right Large Glow (Secondary)
                                        val brush2 =
                                            Brush.radialGradient(
                                                colors =
                                                    listOf(
                                                        color2.copy(alpha = 0.75f),
                                                        color2.copy(alpha = 0.45f),
                                                        Color.Transparent,
                                                    ),
                                                center = Offset(width * 0.85f, height * 0.8f),
                                                radius = width * 1.1f,
                                            )

                                        // Top-Right Glow (Tertiary)
                                        val brush3 =
                                            Brush.radialGradient(
                                                colors =
                                                    listOf(
                                                        color3.copy(alpha = 0.7f),
                                                        color3.copy(alpha = 0.4f),
                                                        Color.Transparent,
                                                    ),
                                                center = Offset(width * 0.9f, height * 0.15f),
                                                radius = width * 1.0f,
                                            )

                                        // Bottom-Left (Quaternary)
                                        val brush4 =
                                            Brush.radialGradient(
                                                colors =
                                                    listOf(
                                                        color4.copy(alpha = 0.65f),
                                                        color4.copy(alpha = 0.35f),
                                                        Color.Transparent,
                                                    ),
                                                center = Offset(width * 0.1f, height * 0.9f),
                                                radius = width * 1.0f,
                                            )

                                        // Top-Center (Quinary)
                                        val brush5 =
                                            Brush.radialGradient(
                                                colors =
                                                    listOf(
                                                        color5.copy(alpha = 0.6f),
                                                        color5.copy(alpha = 0.3f),
                                                        Color.Transparent,
                                                    ),
                                                center = Offset(width * 0.5f, height * 0.1f),
                                                radius = width * 0.9f,
                                            )

                                        // Bottom-Center (Senary)
                                        val brush6 =
                                            Brush.radialGradient(
                                                colors =
                                                    listOf(
                                                        color6.copy(alpha = 0.6f),
                                                        color6.copy(alpha = 0.3f),
                                                        Color.Transparent,
                                                    ),
                                                center = Offset(width * 0.5f, height * 0.95f),
                                                radius = width * 0.9f,
                                            )

                                        onDrawBehind {
                                            drawRect(color = baseColor)
                                            drawRect(brush = brush1)
                                            drawRect(brush = brush2)
                                            drawRect(brush = brush3)
                                            drawRect(brush = brush4)
                                            drawRect(brush = brush5)
                                            drawRect(brush = brush6)
                                        }
                                    },
                        )
                    }
                }
            }

            PlayerBackgroundStyle.GLOW_ANIMATED -> {
                AnimatedContent(
                    targetState = gradientColors,
                    transitionSpec = {
                        fadeIn(tween(1200)) togetherWith fadeOut(tween(1200))
                    },
                    label = "GlowAnimatedContent",
                ) { colors ->
                    if (colors.isNotEmpty()) {
                        val infiniteTransition = rememberInfiniteTransition(label = "GlowAnimation")

                        val progress by infiniteTransition.animateFloat(
                            initialValue = 0f,
                            targetValue = 1f,
                            animationSpec =
                                infiniteRepeatable(
                                    animation = tween(20000, easing = LinearEasing),
                                    repeatMode = RepeatMode.Restart,
                                ),
                            label = "glowProgress",
                        )

                        fun rotatedColorAt(index: Int): Color {
                            val size = colors.size
                            val idx = index.toFloat() + progress * size
                            val a = kotlin.math.floor(idx).toInt() % size
                            val b = (a + 1) % size
                            val frac = idx - kotlin.math.floor(idx)
                            return androidx.compose.ui.graphics.lerp(
                                colors.getOrElse(a) { Color.DarkGray },
                                colors.getOrElse(b) { Color.DarkGray },
                                frac,
                            )
                        }

                        fun oscillate(
                            min: Float,
                            max: Float,
                            phase: Float,
                            speed: Float = 1f,
                        ): Float {
                            // speed MUST be an integer to ensure seamless looping when progress wraps from 1f to 0f.
                            val v = kotlin.math.sin(2f * kotlin.math.PI.toFloat() * (progress * speed + phase)).toFloat()
                            return min + (max - min) * ((v + 1f) * 0.5f)
                        }

                        val color1 = rotatedColorAt(0)
                        val color2 = rotatedColorAt(1)
                        val color3 = rotatedColorAt(2)
                        val color4 = rotatedColorAt(3)
                        val color5 = rotatedColorAt(4)
                        val color6 = rotatedColorAt(5)

                        val o1x = oscillate(0.0f, 1.0f, 0.00f, 1.0f)
                        val o1y = oscillate(0.0f, 0.5f, 0.07f, 1.0f)
                        val r1 = oscillate(0.8f, 1.6f, 0.12f, 1.0f)

                        val o2x = oscillate(1.0f, 0.0f, 0.2f, 1.0f)
                        val o2y = oscillate(0.5f, 1.0f, 0.25f, 1.0f)
                        val r2 = oscillate(0.7f, 1.5f, 0.18f, 1.0f)

                        val o3x = oscillate(0.2f, 0.8f, 0.33f, 1.0f)
                        val o3y = oscillate(0.8f, 0.2f, 0.36f, 1.0f)
                        val r3 = oscillate(0.6f, 1.4f, 0.29f, 1.0f)

                        val o4x = oscillate(0.3f, 0.7f, 0.44f, 1.0f)
                        val o4y = oscillate(0.2f, 0.8f, 0.41f, 1.0f)
                        val r4 = oscillate(0.9f, 1.7f, 0.47f, 1.0f)

                        val o5x = oscillate(0.4f, 0.6f, 0.55f, 1.0f)
                        val o5y = oscillate(0.0f, 1.0f, 0.51f, 1.0f)
                        val r5 = oscillate(0.7f, 1.5f, 0.58f, 1.0f)

                        val o6x = oscillate(0.0f, 1.0f, 0.66f, 1.0f)
                        val o6y = oscillate(0.5f, 0.7f, 0.62f, 1.0f)
                        val r6 = oscillate(0.8f, 1.8f, 0.69f, 1.0f)

                        Box(
                            modifier =
                                Modifier
                                    .fillMaxSize()
                                    .drawWithCache {
                                        val width = size.width
                                        val height = size.height
                                        val baseColor = Color(0xFF050505)

                                        val brush1 =
                                            Brush.radialGradient(
                                                colors = listOf(color1.copy(alpha = 0.85f), color1.copy(alpha = 0.5f), Color.Transparent),
                                                center = Offset(width * o1x, height * o1y),
                                                radius = width * r1,
                                            )
                                        val brush2 =
                                            Brush.radialGradient(
                                                colors = listOf(color2.copy(alpha = 0.8f), color2.copy(alpha = 0.45f), Color.Transparent),
                                                center = Offset(width * o2x, height * o2y),
                                                radius = width * r2,
                                            )
                                        val brush3 =
                                            Brush.radialGradient(
                                                colors = listOf(color3.copy(alpha = 0.75f), color3.copy(alpha = 0.4f), Color.Transparent),
                                                center = Offset(width * o3x, height * o3y),
                                                radius = width * r3,
                                            )
                                        val brush4 =
                                            Brush.radialGradient(
                                                colors = listOf(color4.copy(alpha = 0.7f), color4.copy(alpha = 0.35f), Color.Transparent),
                                                center = Offset(width * o4x, height * o4y),
                                                radius = width * r4,
                                            )
                                        val brush5 =
                                            Brush.radialGradient(
                                                colors = listOf(color5.copy(alpha = 0.65f), color5.copy(alpha = 0.3f), Color.Transparent),
                                                center = Offset(width * o5x, height * o5y),
                                                radius = width * r5,
                                            )
                                        val brush6 =
                                            Brush.radialGradient(
                                                colors = listOf(color6.copy(alpha = 0.6f), color6.copy(alpha = 0.25f), Color.Transparent),
                                                center = Offset(width * o6x, height * o6y),
                                                radius = width * r6,
                                            )

                                        onDrawBehind {
                                            drawRect(color = baseColor)
                                            drawRect(brush = brush1)
                                            drawRect(brush = brush2)
                                            drawRect(brush = brush3)
                                            drawRect(brush = brush4)
                                            drawRect(brush = brush5)
                                            drawRect(brush = brush6)
                                        }
                                    },
                        )
                    }
                }
            }

            else -> {
                // DEFAULT or other modes - no background
            }
        }
    }
}

@Composable
fun AutoResizeText(
    text: String,
    style: TextStyle,
    color: Color,
    modifier: Modifier = Modifier,
) {
    var fontSizeValue by remember(text) { mutableStateOf(style.fontSize) }
    var readyToDraw by remember(text) { mutableStateOf(false) }

    Text(
        text = text,
        style = style.copy(fontSize = fontSizeValue),
        color = color,
        maxLines = 1,
        overflow = TextOverflow.Clip,
        onTextLayout = { textLayoutResult ->
            if (textLayoutResult.hasVisualOverflow && fontSizeValue.value > 10f) {
                fontSizeValue = (fontSizeValue.value * 0.9f).sp
            } else {
                readyToDraw = true
            }
        },
        modifier = modifier.drawWithContent {
            if (readyToDraw) {
                drawContent()
            }
        }
    )
}

@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
fun V10PlayerContent(
    mediaMetadata: MediaMetadata,
    playbackState: Int,
    isPlaying: Boolean,
    isLoading: Boolean,
    canSkipPrevious: Boolean,
    canSkipNext: Boolean,
    sliderPosition: Long?,
    position: Long,
    duration: Long,
    playerConnection: PlayerConnection,
    navController: NavController,
    state: BottomSheetState,
    textBackgroundColor: Color,
    textButtonColor: Color,
    iconButtonColor: Color,
    onCollapseClick: () -> Unit,
    onQueueClick: () -> Unit,
    onLyricsClick: () -> Unit,
    onSliderValueChange: (Long) -> Unit,
    onSliderValueChangeFinished: () -> Unit,
    onSleepTimerClick: () -> Unit,
    sleepTimerEnabled: Boolean,
    sleepTimerTimeLeft: Long,
    onMenuClick: () -> Unit,
    onAddToPlaylistClick: () -> Unit,
    modifier: Modifier = Modifier,
    landscape: Boolean = false,
) {
    val baseArtworkUrl = mediaMetadata.thumbnailUrl?.highRes()
    val thumbnailSwapState =
        rememberThumbnailSwapState(
            videoId = mediaMetadata.id,
            ytmUrl = baseArtworkUrl,
            lowDataMode = rememberLowDataModeActive(),
            isMusicVideo = mediaMetadata.isMusicVideo,
        )
    val artworkUrl = thumbnailSwapState.displayUrl
    val titleActions = rememberPlayerTitleActions(mediaMetadata, navController, state)
    val onTitleClick = titleActions.onTitleClick
    val onArtistClick = titleActions.onArtistClick
    val onPlayPauseClick = {
        if (playbackState == STATE_ENDED) {
            playerConnection.player.seekTo(0, 0)
            playerConnection.player.playWhenReady = true
        } else {
            playerConnection.player.togglePlayPause()
        }
    }

    val currentSong by playerConnection.currentSong.collectAsStateWithLifecycle(initialValue = null)
    val liked = currentSong?.song?.liked == true
    val onToggleLike = playerConnection::toggleLike

    // The two-tone contract: field + accent, nothing else.
    // textBackgroundColor = accent (text/icon color), textButtonColor = field (fill color)
    val accent = textBackgroundColor
    val field = textButtonColor

    if (landscape) {
        LandscapePlayerLayout(
            modifier = modifier,
            artwork = {
                EditorialDieCutArt(
                    artworkUrl = artworkUrl,
                    mediaMetadataId = mediaMetadata.id,
                    isPlaying = isPlaying,
                    onTap = onPlayPauseClick,
                    accent = accent,
                    field = field,
                    canSkipPrevious = canSkipPrevious,
                    canSkipNext = canSkipNext,
                    onSkipPrevious = playerConnection::seekToPrevious,
                    onSkipNext = playerConnection::seekToNext,
                )
            },
            controls = {
                LandscapePlayerControls(
                    playbackContent = {
                        V8TransportControls(
                            playbackState = playbackState,
                            isPlaying = isPlaying,
                            isLoading = isLoading,
                            canSkipPrevious = canSkipPrevious,
                            canSkipNext = canSkipNext,
                            foreground = accent,
                            onPreviousClick = playerConnection::seekToPrevious,
                            onPlayPauseClick = onPlayPauseClick,
                            onNextClick = playerConnection::seekToNext,
                        )
                    },
                ) {
                    V9Header(
                        textColor = accent,
                        containerColor = accent.copy(alpha = 0.16f),
                        iconColor = accent,
                        onCollapseClick = onCollapseClick,
                        onLyricsClick = onLyricsClick,
                        onQueueClick = onQueueClick,
                    )
                    PlayerTitleText(
                        title = mediaMetadata.title,
                        explicit = mediaMetadata.explicit,
                        color = accent,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.headlineSmall.copy(
                            fontFamily = FontFamily.Serif,
                            fontStyle = FontStyle.Italic,
                            fontWeight = FontWeight.Bold,
                        ),
                        modifier = Modifier.fillMaxWidth().clickable(onClick = onTitleClick),
                    )
                    ClickableArtists(
                        artists = mediaMetadata.artists,
                        onArtistClick = onArtistClick,
                        style = MaterialTheme.typography.labelLarge,
                        color = accent.copy(alpha = 0.8f),
                        modifier = Modifier.fillMaxWidth().basicMarquee(),
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        V10ToggleButton(
                            checked = liked,
                            onClick = onToggleLike,
                            accent = accent,
                            field = field,
                            iconResId = if (liked) R.drawable.favorite else R.drawable.favorite_border,
                            contentDescription = stringResource(if (liked) R.string.action_remove_like else R.string.action_like),
                        )
                        V10ToggleButton(
                            checked = false,
                            onClick = onAddToPlaylistClick,
                            accent = accent,
                            field = field,
                            iconResId = R.drawable.library_add,
                            contentDescription = stringResource(R.string.add_to_playlist),
                        )
                        IconButton(onClick = onSleepTimerClick) {
                            Icon(
                                painter = painterResource(R.drawable.bedtime),
                                contentDescription = stringResource(R.string.sleep_timer),
                                tint = accent,
                            )
                        }
                        if (sleepTimerEnabled) {
                            Text(
                                text = makeTimeString(sleepTimerTimeLeft.coerceAtLeast(0L)),
                                color = accent,
                                style = MaterialTheme.typography.labelLarge,
                            )
                        }
                        IconButton(onClick = onMenuClick) {
                            Icon(
                                painter = painterResource(R.drawable.more_vert),
                                contentDescription = stringResource(R.string.more_label),
                                tint = accent,
                            )
                        }
                    }
                    V9PlaybackProgress(
                        sliderPosition = sliderPosition,
                        position = position,
                        duration = duration,
                        isPlaying = isPlaying,
                        activeColor = accent,
                        inactiveColor = accent.copy(alpha = 0.24f),
                        textColor = accent,
                        onSliderValueChange = onSliderValueChange,
                        onSliderValueChangeFinished = onSliderValueChangeFinished,
                    )
                }
            },
        )
        return
    }

    // ========== MAIN LAYOUT (EditorialNowPlayingView) ==========
    Column(modifier = modifier.fillMaxSize()) {

        // ========== TOP BAR (No statusBarsPadding to give breathing space/hide status bar) ==========
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 20.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            EditorialCircleButton(
                onClick = onCollapseClick,
                accent = accent,
                field = field,
                size = 44.dp
            ) {
                Icon(painter = painterResource(R.drawable.expand_more), contentDescription = "Collapse", modifier = Modifier.size(26.dp))
            }
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (sleepTimerEnabled) {
                    val countdownText = makeTimeString(sleepTimerTimeLeft.coerceAtLeast(0L))
                    Box(
                        modifier = Modifier
                            .height(44.dp)
                            .clip(CircleShape)
                            .background(accent)
                            .clickable(onClick = onSleepTimerClick),
                        contentAlignment = Alignment.Center
                    ) {
                        CompositionLocalProvider(LocalContentColor provides field) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center,
                                modifier = Modifier.padding(horizontal = 16.dp)
                            ) {
                                Text(
                                    text = countdownText,
                                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Icon(
                                    painter = painterResource(R.drawable.bedtime),
                                    contentDescription = "Sleep timer",
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                } else {
                    EditorialCircleButton(
                        onClick = onSleepTimerClick,
                        accent = field,
                        field = accent,
                        size = 44.dp
                    ) {
                        Icon(painter = painterResource(R.drawable.bedtime), contentDescription = "Sleep timer", modifier = Modifier.size(22.dp))
                    }
                }

                EditorialCircleButton(
                    onClick = onLyricsClick,
                    accent = accent,
                    field = field,
                    size = 44.dp
                ) {
                    Icon(painter = painterResource(R.drawable.lyrics), contentDescription = "Lyrics", modifier = Modifier.size(22.dp))
                }
                EditorialCircleButton(
                    onClick = onMenuClick,
                    accent = accent,
                    field = field,
                    size = 44.dp
                ) {
                    Icon(painter = painterResource(R.drawable.more_vert), contentDescription = "More", modifier = Modifier.size(22.dp))
                }
            }
        }

        // ========== DIE-CUT ART ==========
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1.0f),
            contentAlignment = Alignment.Center
        ) {
            EditorialDieCutArt(
                artworkUrl = artworkUrl,
                mediaMetadataId = mediaMetadata.id,
                isPlaying = isPlaying,
                onTap = onPlayPauseClick,
                accent = accent,
                field = field,
                canSkipPrevious = canSkipPrevious,
                canSkipNext = canSkipNext,
                onSkipPrevious = { playerConnection.player.seekToPrevious() },
                onSkipNext = { playerConnection.player.seekToNext() }
            )
        }

        // ========== HEADLINE ==========
        val title = mediaMetadata.title
        val headlineBase = when {
            title.length <= 12 -> MaterialTheme.typography.displayLarge
            title.length <= 24 -> MaterialTheme.typography.displayMedium
            else -> MaterialTheme.typography.displaySmall
        }
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp)
        ) {
            Text(
                text = title,
                style = headlineBase.copy(
                    fontFamily = FontFamily.Serif,
                    fontStyle = FontStyle.Italic,
                    fontWeight = FontWeight.Bold
                ),
                color = accent,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp)
                    .clickable(
                        indication = tvFocusIndicationOrNull(),
                        interactionSource = remember { MutableInteractionSource() },
                        onClick = onTitleClick,
                    )
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 4.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .padding(horizontal = 4.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Start
            ) {
                if (mediaMetadata.explicit) {
                    Icon(
                        painter = painterResource(R.drawable.explicit),
                        contentDescription = "Explicit",
                        tint = accent.copy(alpha = 0.8f),
                        modifier = Modifier
                            .padding(end = 6.dp)
                            .size(16.dp)
                    )
                }
                ClickableArtists(
                    artists = mediaMetadata.artists,
                    onArtistClick = onArtistClick,
                    style = MaterialTheme.typography.labelLarge.copy(letterSpacing = 2.sp),
                    color = accent.copy(alpha = 0.8f),
                    modifier = Modifier.basicMarquee(
                        iterations = Int.MAX_VALUE,
                        initialDelayMillis = 2000
                    ),
                )
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // ========== CONTROL CLUSTER (asymmetric bento) ==========
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
        ) {
            // Row 1: word pill + next circle
            val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(80.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clip(RoundedCornerShape(50))
                        .background(accent)
                        .clickable(onClick = onPlayPauseClick),
                    contentAlignment = Alignment.Center
                ) {
                    CompositionLocalProvider(LocalContentColor provides field) {
                        if (isLoading && !isPlaying) {
                            LoadingIndicator(
                                modifier = Modifier.size(36.dp),
                                color = field,
                                polygons = listOf(
                                    MaterialShapes.SoftBurst,
                                    MaterialShapes.Cookie9Sided,
                                    MaterialShapes.Pill,
                                    MaterialShapes.Sunny
                                )
                            )
                        } else {
                            AnimatedContent(
                                targetState = isPlaying,
                                label = "EditorialPlayWord"
                            ) { playing ->
                                Text(
                                    text = if (playing) "PAUSE" else "PLAY",
                                    style = MaterialTheme.typography.headlineSmall.copy(
                                        fontWeight = FontWeight.Medium,
                                        letterSpacing = 3.sp
                                    )
                                )
                            }
                        }
                    }
                }
                EditorialCircleButton(
                    onClick = {
                        haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress)
                        playerConnection.seekToNext()
                    },
                    accent = accent,
                    field = field,
                    size = 80.dp
                ) {
                    Icon(painter = painterResource(R.drawable.skip_next), contentDescription = "Next", modifier = Modifier.size(34.dp))
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Row 2: previous circle + progress line with times
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                EditorialCircleButton(
                    onClick = {
                        haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress)
                        playerConnection.seekToPrevious()
                    },
                    accent = accent,
                    field = field,
                    size = 80.dp
                ) {
                    Icon(painter = painterResource(R.drawable.skip_previous), contentDescription = "Previous", modifier = Modifier.size(34.dp))
                }

                Column(modifier = Modifier.weight(1f)) {
                    var scrubPosition by remember { mutableStateOf<Float?>(null) }
                    val displayedProgress = scrubPosition?.toLong() ?: (sliderPosition ?: position)
                    val progressFraction =
                        if (duration > 0) displayedProgress.toFloat() / duration.toFloat() else 0f
                    val animatedProgress by animateFloatAsState(
                        targetValue = progressFraction,
                        animationSpec = spring(
                            dampingRatio = Spring.DampingRatioNoBouncy,
                            stiffness = Spring.StiffnessLow
                        ),
                        label = "EditorialProgress"
                    )
                    val lineStroke = Stroke(
                        width = with(LocalDensity.current) { 4.dp.toPx() },
                        cap = StrokeCap.Round
                    )

                    Box(contentAlignment = Alignment.Center) {
                        LinearWavyProgressIndicator(
                            progress = { animatedProgress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(14.dp),
                            color = accent,
                            trackColor = accent.copy(alpha = 0.35f),
                            stroke = lineStroke,
                            trackStroke = lineStroke,
                            amplitude = { if (isPlaying) 1f else 0f }
                        )
                        Slider(
                            value = scrubPosition ?: (sliderPosition ?: position).toFloat(),
                            onValueChange = { scrubPosition = it },
                            onValueChangeFinished = {
                                scrubPosition?.let { onSliderValueChange(it.toLong()) }
                                onSliderValueChangeFinished()
                                scrubPosition = null
                            },
                            valueRange = 0f..(duration.toFloat().coerceAtLeast(1f)),
                            colors = SliderDefaults.colors(
                                thumbColor = Color.Transparent,
                                activeTrackColor = Color.Transparent,
                                inactiveTrackColor = Color.Transparent
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = formatEditorialTime(displayedProgress.coerceAtLeast(0L)),
                            style = MaterialTheme.typography.labelMedium,
                            color = accent.copy(alpha = 0.8f)
                        )
                        Text(
                            text = formatEditorialTime(duration.coerceAtLeast(0L)),
                            style = MaterialTheme.typography.labelMedium,
                            color = accent.copy(alpha = 0.8f)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
        }
    }
}

// ========== HELPERS ==========

@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
private fun EditorialDieCutArt(
    artworkUrl: String?,
    mediaMetadataId: String,
    isPlaying: Boolean,
    onTap: () -> Unit,
    accent: Color,
    field: Color,
    canSkipPrevious: Boolean,
    canSkipNext: Boolean,
    onSkipPrevious: () -> Unit,
    onSkipNext: () -> Unit
) {
    val dieCuts = remember {
        listOf(
            MaterialShapes.Flower,
            MaterialShapes.Clover4Leaf,
            MaterialShapes.Puffy,
            MaterialShapes.Cookie12Sided,
            MaterialShapes.SoftBurst
        )
    }
    val targetPolygon = remember(mediaMetadataId) {
        dieCuts[abs(mediaMetadataId.hashCode()) % dieCuts.size]
    }

    var morphFrom by remember { mutableStateOf(targetPolygon) }
    var morphTo by remember { mutableStateOf(targetPolygon) }
    val morphProgress = remember { Animatable(1f) }
    LaunchedEffect(targetPolygon) {
        if (targetPolygon !== morphTo) {
            morphFrom = morphTo
            morphTo = targetPolygon
            morphProgress.snapTo(0f)
            morphProgress.animateTo(
                targetValue = 1f,
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioLowBouncy,
                    stiffness = Spring.StiffnessLow
                )
            )
        }
    }
    val morph = remember(morphFrom, morphTo) { Morph(morphFrom, morphTo) }
    val dieCutShape = remember(morph, morphProgress.value) {
        EditorialMorphShape(morph, morphProgress.value)
    }

    val artScale by animateFloatAsState(
        targetValue = if (isPlaying) 1f else 0.94f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "EditorialArtScale"
    )

    BoxWithConstraints(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        if (maxWidth < 50.dp || maxHeight < 50.dp) return@BoxWithConstraints
        val artSize = minOf(maxWidth, maxHeight) * 0.95f

        val view = androidx.compose.ui.platform.LocalView.current
        val (enableHapticFeedback) = rememberPreference(moe.rukamori.archivetune.constants.EnableHapticFeedbackKey, true)
        val coroutineScope = rememberCoroutineScope()

        // Visual feedback variables
        var skipIndicator by remember { mutableStateOf<String?>(null) } // "prev", "next", or "play_pause"
        val skipIndicatorAlpha = remember { Animatable(0f) }

        Box(
            modifier = Modifier
                .size(artSize)
                .graphicsLayer {
                    scaleX = artScale
                    scaleY = artScale
                }
                .clip(dieCutShape)
                .background(accent),
            contentAlignment = Alignment.Center
        ) {
            if (artworkUrl != null) {
                AsyncImage(
                    model = artworkUrl,
                    contentDescription = "Album Art",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            } else {
                Icon(
                    painter = painterResource(R.drawable.music_note),
                    contentDescription = null,
                    tint = field,
                    modifier = Modifier.size(artSize * 0.3f)
                )
            }
        }
    }
}

@Composable
internal fun EditorialCircleButton(
    onClick: () -> Unit,
    accent: Color,
    field: Color,
    size: Dp,
    content: @Composable () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.95f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioNoBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "CircleButtonScale"
    )
    Box(
        modifier = Modifier
            .size(size)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .clip(CircleShape)
            .background(accent)
            .clickable(
                interactionSource = interactionSource,
                indication = ripple(color = field.copy(alpha = 0.2f)),
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        CompositionLocalProvider(LocalContentColor provides field) {
            content()
        }
    }
}

@Composable
internal fun EditorialChip(
    checked: Boolean,
    onClick: () -> Unit,
    accent: Color,
    field: Color,
    content: @Composable () -> Unit
) {
    val backgroundColor by animateColorAsState(
        targetValue = if (checked) accent else Color.Transparent,
        label = "EditorialChipBg"
    )
    val contentColor = if (checked) field else accent
    Box(
        modifier = Modifier
            .size(48.dp)
            .clip(CircleShape)
            .background(backgroundColor)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        CompositionLocalProvider(LocalContentColor provides contentColor) {
            content()
        }
    }
}

@Composable
private fun V10ToggleButton(
    checked: Boolean,
    onClick: () -> Unit,
    accent: Color,
    field: Color,
    iconResId: Int,
    contentDescription: String?,
) {
    val containerColor by animateColorAsState(
        targetValue = if (checked) accent else accent.copy(alpha = 0.08f),
        label = "V10ToggleButtonBg"
    )
    val contentColor = if (checked) field else accent

    Box(
        modifier = Modifier
            .size(48.dp)
            .clip(CircleShape)
            .background(containerColor)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        CompositionLocalProvider(LocalContentColor provides contentColor) {
            Icon(
                painter = painterResource(iconResId),
                contentDescription = contentDescription,
                modifier = Modifier.size(20.dp),
            )
        }
    }
}

internal class EditorialMorphShape(
    private val morph: Morph,
    private val progress: Float
) : Shape {
    override fun createOutline(
        size: Size,
        layoutDirection: LayoutDirection,
        density: Density
    ): Outline {
        val path = morph.toPath(progress).asComposePath()
        val matrix = Matrix()
        val bounds = morph.calculateBounds()
        val boundsWidth = bounds[2] - bounds[0]
        val boundsHeight = bounds[3] - bounds[1]

        matrix.scale(size.width / boundsWidth, size.height / boundsHeight)
        matrix.translate(-bounds[0], -bounds[1])
        path.transform(matrix)
        return Outline.Generic(path)
    }
}

internal class EditorialPolygonShape(
    private val polygon: RoundedPolygon
) : Shape {
    override fun createOutline(
        size: Size,
        layoutDirection: LayoutDirection,
        density: Density
    ): Outline {
        val path = polygon.toPath().asComposePath()
        val matrix = Matrix()
        val bounds = polygon.calculateBounds()
        val boundsWidth = bounds[2] - bounds[0]
        val boundsHeight = bounds[3] - bounds[1]

        matrix.scale(size.width / boundsWidth, size.height / boundsHeight)
        matrix.translate(-bounds[0], -bounds[1])
        path.transform(matrix)
        return Outline.Generic(path)
    }
}

internal fun formatEditorialTime(durationMs: Long): String {
    val totalSeconds = durationMs / 1000
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return String.format("%d:%02d", minutes, seconds)
}
